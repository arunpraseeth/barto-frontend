package com.barto.india

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
