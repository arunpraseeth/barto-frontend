
const aboutBarto1 =
    "Barto is an indigenously crafted online marketplace that brings enthusiastic buyers and independent sellers across the country together by eliminating mediators and brokers.";

const aboutBarto2 =
    "Barto is the fastest growing online market where the buyers and sellers have access to a wide range of categories in the products to list or purchase.";

const aboutBarto3 =
    "We'd happily endorse the reasons why Barto is the application that is meticulously created for you :";

const aboutBarto4 = "ABSOLUTELY FREE !!!";

const aboutBarto5 =
    "Barto does not charge for the ads posted/listed in the site. There is no limitation for the number of ads being posted on the site.";

const aboutBarto6 =
    "Premium ads are very much affordable and starts as low as INR 20. Premium ads posted would top the search list thereby prioritizing the products on the search list. We do not claim any brokerage charges or commission charges for the products that you sell or buy.";

const aboutBarto7 = "TO INFINITY AND BEYOND";

const aboutBarto8 =
    "Nobody likes restrictions. We do not wish to limit our customer's shopping experience. Customer satisfaction is our ultimate aim. Barto allows sellers to list unlimited number of ads in this virtual marketplace.";

const aboutBarto9 = "NEGOTIATE FOR THE DEAL";

const aboutBarto10 =
    "Barto allows the customer to bargain with the buyer / seller via chat window to strike a deal.";

const aboutBarto11 =
    "“Reusing products would take a lesser toll on the environment. Buying and selling used products would be cost efficient comparatively with the new products and being an eco-friendly window to our community”. – Deepak Krishnan";

const aboutBarto12 =
    "Happy shopping a wide range of collections through Barto.";
