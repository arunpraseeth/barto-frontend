import 'package:flutter/material.dart';
import 'package:india/Common/color.dart';

class CustomTextField {
  static TextFormField customTextField({
    required TextEditingController controller,
    int? maxLength,
    TextInputType? textInputType,
    String? hintText,
    double? textSpacing,
    Widget? prefix,
    Widget? suffix,
    bool? readOnly,
    FocusNode? focusnode,
    required String? Function(String? value) validator,
  }) {
    return TextFormField(
      focusNode: focusnode,
      readOnly: readOnly ?? false,
      controller: controller,
      maxLength: maxLength,
      validator: validator,
      keyboardType: textInputType,
      style: TextStyle(
        fontSize: 20,
        fontWeight: FontWeight.w500,
        letterSpacing: textSpacing,
      ),
      decoration: InputDecoration(
        hintText: hintText,
        filled: true,
        fillColor: Colors.grey[200],
        counterText: "",
        contentPadding:
            new EdgeInsets.symmetric(vertical: 15.0, horizontal: 15.0),
        // prefix: prefix,
        prefixIcon: prefix,
        suffixIcon: suffix,
        focusedBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(7),
          borderSide: BorderSide(
            color: Colors.grey[200]!,
          ),
        ),
        enabledBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(7),
          borderSide: BorderSide(
            color: colorBlue,
          ),
        ),
      ),
    );
  }
}
