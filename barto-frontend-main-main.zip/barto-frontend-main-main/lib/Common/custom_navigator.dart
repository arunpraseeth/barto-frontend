import 'package:flutter/material.dart';
import 'package:india/Common/color.dart';

class RoundedCustomNavigatorButton {
  static Widget customContainer({
    required String boxName,
    required VoidCallback onTap,
    required BuildContext context,
  }) {
    Size size = MediaQuery.of(context).size;
    return GestureDetector(
      onTap: onTap,
      child: Container(
        width: size.width / 1.7,
        height: size.height / 16,
        decoration: BoxDecoration(
          color: colorBlue,
          borderRadius: BorderRadius.circular(40),
        ),
        child: Center(
          child: Text(
            boxName,
            style: TextStyle(
              fontSize: size.height * 0.03,
              fontWeight: FontWeight.w500,
              color: Colors.white,
            ),
          ),
        ),
      ),
    );
  }
}

class BoxCustomNavigatorButton {
  static Widget customContainer({
    required String boxName,
    required VoidCallback onTap,
    required BuildContext context,
  }) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 80, vertical: 5),
      child: InkWell(
        onTap: onTap,
        child: Padding(
          padding: const EdgeInsets.symmetric(vertical: 5),
          child: Container(
            height: 50,
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(5),
              color: colorBlue,
            ),
            child: Center(
              child: Text(
                boxName,
                style: TextStyle(
                  fontSize: 22,
                  fontWeight: FontWeight.w500,
                  color: Colors.black87,
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }
}
