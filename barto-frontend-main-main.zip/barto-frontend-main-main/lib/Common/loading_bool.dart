import 'package:flutter/material.dart';

class BoolLoader with ChangeNotifier {
  bool? _boolLoad;
  boolLoader({required bool status}) {
    _boolLoad = status;
    notifyListeners();
  }

  bool get loadingStatus => _boolLoad!;
}
