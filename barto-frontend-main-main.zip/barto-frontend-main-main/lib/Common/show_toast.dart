import 'package:flutter/material.dart';
import 'package:india/Common/color.dart';

class ShowToast {
  static showToast(
    BuildContext context, {
    required String exception,
  }) {
    final scaffold = ScaffoldMessenger.of(context);
    scaffold.showSnackBar(
      SnackBar(
        duration: Duration(milliseconds: 1000),
        content: Text(
          exception,
          style: TextStyle(
            color: Colors.white,
            fontWeight: FontWeight.bold,
          ),
        ),
        backgroundColor: colorBlue,
      ),
    );
  }
}
