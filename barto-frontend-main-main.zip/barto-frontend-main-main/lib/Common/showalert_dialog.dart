import 'package:flutter/material.dart';

class ShowAlert {
  static Future showAlertDialog(
    BuildContext context, {
    required String exception,
  }) async {
    // set up the AlertDialog
    AlertDialog alert = AlertDialog(
      content: Text(exception),
    );
    // show the dialog
    await showDialog(
      context: context,
      builder: (BuildContext context) {
        Future.delayed(Duration(seconds: 2), () {
          Navigator.of(context).pop(true);
        });
        return alert;
      },
    );
  }
}
