// To parse this JSON data, do
//
//     final categoriesForm = categoriesFormFromJson(jsonString);

// import 'package:meta/meta.dart';
import 'dart:convert';

CategoriesForm categoriesFormFromJson(String str) =>
    CategoriesForm.fromJson(json.decode(str));

String categoriesFormToJson(CategoriesForm data) => json.encode(data.toJson());

class CategoriesForm {
  CategoriesForm({
    required this.status,
    required this.response,
  });

  int status;
  Response response;

  factory CategoriesForm.fromJson(Map<String, dynamic> json) => CategoriesForm(
        status: json["status"],
        response: Response.fromJson(json["response"]),
      );

  Map<String, dynamic> toJson() => {
        "status": status,
        "response": response.toJson(),
      };
}

class Response {
  Response({
    required this.resource,
    required this.data,
    required this.type,
  });

  String resource;
  Data data;
  String type;

  factory Response.fromJson(Map<String, dynamic> json) => Response(
        resource: json["resource"],
        data: Data.fromJson(json["data"]),
        type: json["type"],
      );

  Map<String, dynamic> toJson() => {
        "resource": resource,
        "data": data.toJson(),
        "type": type,
      };
}

class Data {
  Data({
    required this.fetched,
    required this.info,
  });

  bool fetched;
  Info info;

  factory Data.fromJson(Map<String, dynamic> json) => Data(
        fetched: json["fetched"],
        info: Info.fromJson(json["info"]),
      );

  Map<String, dynamic> toJson() => {
        "fetched": fetched,
        "info": info.toJson(),
      };
}

class Info {
  Info({
    required this.form,
  });

  List<Form> form;

  factory Info.fromJson(Map<String, dynamic> json) => Info(
        form: List<Form>.from(json["form"].map((x) => Form.fromJson(x))),
      );

  Map<String, dynamic> toJson() => {
        "form": List<dynamic>.from(form.map((x) => x.toJson())),
      };
}

class Form {
  Form({
    required this.id,
    required this.name,
    required this.fields,
  });

  String id;
  String name;
  List<Field> fields;

  factory Form.fromJson(Map<String, dynamic> json) => Form(
        id: json["_id"],
        name: json["name"],
        fields: List<Field>.from(json["fields"].map((x) => Field.fromJson(x))),
      );

  Map<String, dynamic> toJson() => {
        "_id": id,
        "name": name,
        "fields": List<dynamic>.from(fields.map((x) => x.toJson())),
      };
}

class Field {
  Field({
    required this.filterable,
    required this.mandatory,
    required this.id,
    required this.name,
    required this.displayText,
    required this.type,
    required this.label,
    required this.codeGroup,
    required this.dependent,
    required this.min,
    required this.max,
  });

  bool filterable;
  bool mandatory;
  String id;
  String name;
  String displayText;
  String type;
  String label;
  CodeGroup? codeGroup;
  String dependent;
  int min;
  int max;

  factory Field.fromJson(Map<String, dynamic> json) => Field(
        filterable: json["filterable"],
        mandatory: json["mandatory"],
        id: json["_id"],
        name: json["name"],
        displayText: json["displayText"],
        type: json["type"],
        label: json["label"],
        codeGroup: json["codeGroup"] == null ? null : CodeGroup.fromJson(json["codeGroup"]),
        dependent: json["dependent"] == null ? null : json["dependent"],
        min: json["min"] == null ? null : json["min"],
        max: json["max"] == null ? null : json["max"],
      );

  Map<String, dynamic> toJson() => {
        "filterable": filterable,
        "mandatory": mandatory,
        "_id": id,
        "name": name,
        "displayText": displayText,
        "type": type,
        "label": label,
        "codeGroup": codeGroup == null ? null : codeGroup!.toJson(),
        "dependent": dependent,
        "min": min,
        "max": max,
      };
}

class CodeGroup {
  CodeGroup({
    required this.id,
    required this.name,
    required this.codeValues,
  });

  String id;
  String name;
  List<dynamic> codeValues;

  factory CodeGroup.fromJson(Map<String, dynamic> json) => CodeGroup(
        id: json["_id"],
        name: json["name"],
        codeValues: List<dynamic>.from(json["codeValues"].map((x) => x)),
      );

  Map<String, dynamic> toJson() => {
        "_id": id,
        "name": name,
        "codeValues": List<dynamic>.from(codeValues.map((x) => x)),
      };
}
