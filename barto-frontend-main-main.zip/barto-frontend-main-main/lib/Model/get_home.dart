// // To parse this JSON data, do
// //
// //     final getHome = getHomeFromJson(jsonString);

// import 'dart:convert';

// GetHome getHomeFromJson(String str) => GetHome.fromJson(json.decode(str));

// String getHomeToJson(GetHome data) => json.encode(data.toJson());

// class GetHome {
//     GetHome({
//         required this.status,
//         required this.response,
//     });

//     int status;
//     Response response;

//     factory GetHome.fromJson(Map<String, dynamic> json) => GetHome(
//         status: json["status"],
//         response: Response.fromJson(json["response"]),
//     );

//     Map<String, dynamic> toJson() => {
//         "status": status,
//         "response": response.toJson(),
//     };
// }

// class Response {
//     Response({
//         required this.resource,
//         required this.data,
//         required this.type,
//     });

//     String resource;
//     Data data;
//     String type;

//     factory Response.fromJson(Map<String, dynamic> json) => Response(
//         resource: json["resource"],
//         data: Data.fromJson(json["data"]),
//         type: json["type"],
//     );

//     Map<String, dynamic> toJson() => {
//         "resource": resource,
//         "data": data.toJson(),
//         "type": type,
//     };
// }

// class Data {
//     Data({
//         required this.fetched,
//         required this.info,
//     });

//     bool fetched;
//     Info info;

//     factory Data.fromJson(Map<String, dynamic> json) => Data(
//         fetched: json["fetched"],
//         info: Info.fromJson(json["info"]),
//     );

//     Map<String, dynamic> toJson() => {
//         "fetched": fetched,
//         "info": info.toJson(),
//     };
// }

// class Info {
//     Info({
//         required this.products,
//         required this.totalProducts,
//     });

//     List<Product> products;
//     int totalProducts;

//     factory Info.fromJson(Map<String, dynamic> json) => Info(
//         products: List<Product>.from(json["products"].map((x) => Product.fromJson(x))),
//         totalProducts: json["total_products"],
//     );

//     Map<String, dynamic> toJson() => {
//         "products": List<dynamic>.from(products.map((x) => x.toJson())),
//         "total_products": totalProducts,
//     };
// }

// class Product {
//     Product({
//         required this.id,
//         required this.productImage,
//         required this.productName,
//         required this.price,
//         required this.productLocation,
//         required this.userInfo,
//         required this.timestamp,
//         required this.featured,
//         required this.wishlist,
//     });

//     String id;
//     String productImage;
//     String productName;
//     String price;
//     ProductLocation productLocation;
//     UserInfo userInfo;
//     int timestamp;
//     bool featured;
//     bool wishlist;

//     factory Product.fromJson(Map<String, dynamic> json) => Product(
//         id: json["_id"],
//         productImage: json["product_image"],
//         productName: json["product_name"],
//         price: json["price"],
//         productLocation: ProductLocation.fromJson(json["product_location"]),
//         userInfo: UserInfo.fromJson(json["user_info"]),
//         timestamp: json["timestamp"],
//         featured: json["featured"],
//         wishlist: json["wishlist"],
//     );

//     Map<String, dynamic> toJson() => {
//         "_id": id,
//         "product_image": productImage,
//         "product_name": productName,
//         "price": price,
//         "product_location": productLocation.toJson(),
//         "user_info": userInfo.toJson(),
//         "timestamp": timestamp,
//         "featured": featured,
//         "wishlist": wishlist,
//     };
// }

// class ProductLocation {
//     ProductLocation({
//         required this.country,
//         required this.state,
//         required this.city,
//         required this.area,
//         required this.pincode,
//     });

//     String country;
//     String state;
//     String city;
//     String area;
//     String pincode;

//     factory ProductLocation.fromJson(Map<String, dynamic> json) => ProductLocation(
//         country: json["country"],
//         state: json["state"],
//         city: json["city"],
//         area: json["area"],
//         pincode: json["pincode"],
//     );

//     Map<String, dynamic> toJson() => {
//         "country": country,
//         "state": state,
//         "city": city,
//         "area": area,
//         "pincode": pincode,
//     };
// }

// class UserInfo {
//     UserInfo({
//         required this.id,
//         required this.name,
//         required this.avatar,
//         required this.userName,
//         required this.phone,
//     });

//     String id;
//     String name;
//     String avatar;
//     String userName;
//     dynamic phone;

//     factory UserInfo.fromJson(Map<String, dynamic> json) => UserInfo(
//         id: json["_id"],
//         name: json["name"],
//         avatar: json["avatar"] == null ? null : json["avatar"],
//         userName: json["user_name"],
//         phone: json["phone"],
//     );

//     Map<String, dynamic> toJson() => {
//         "_id": id,
//         "name": name,
//         "avatar": avatar == null ? null : avatar,
//         "user_name": userName,
//         "phone": phone,
//     };
// }
