import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

class StoreLocation with ChangeNotifier {
  double _lat = 0.0;
  double _long = 0.0;
  String _placename = '';
  String _areaname = '';
  String _cityname = '';
  String _districtname = '';
  String _statename = '';
  String _countryname = '';

  Future storeLocation({
    required double lat,
    required double long,
    String? placename,
    String? areaname,
    String? cityname,
    String? districtname,
    String? statename,
    String? countryname,
  }) async {
    SharedPreferences sharedPreferences = await SharedPreferences.getInstance();
    _lat = lat;
    _long = long;
    _placename = placename ?? '';
    _areaname = areaname ?? '';
    _cityname = cityname ?? '';
    _districtname = districtname ?? '';
    _statename = statename ?? '';
    _countryname = countryname ?? '';
    // print("areaname: $_areaname");
    // print("cityname: $_cityname");
    // print("districname: $_districtname");
    // print("statename: $_statename");
    // print("countryname: $_countryname");
    await sharedPreferences.setString("latitude", "$_lat");
    await sharedPreferences.setString("longitude", "$_long");
    await sharedPreferences.setString("areaname", _areaname);
    await sharedPreferences.setString("cityname", _cityname);
    await sharedPreferences.setString("districname", _districtname);
    await sharedPreferences.setString("statename", _statename);
    await sharedPreferences.setString("countryname", _countryname);
    notifyListeners();
  }

  double get latitude => _lat;
  double get longitude => _long;
  String get placename => _placename;
  String get areaname => _areaname;
  String get cityname => _cityname;
  String get districtname => _districtname;
  String get statename => _statename;
  String get countryname => _countryname;
}
