import 'package:shared_preferences/shared_preferences.dart';

class GetStoredInfo {
  static String latitude = '';
  static String longitude = '';
  static String arename = '';
  static String cityname = '';
  static String statename = '';
  static String countryname = '';
  static String myarea = '';
  static String mycity = '';
  static String authtoken = '';
  static String placename = '';
  static getStoreInfo() async {
    SharedPreferences sharedPreferences = await SharedPreferences.getInstance();
    latitude = sharedPreferences.getString("latitude") ?? "";
    longitude = sharedPreferences.getString("longitude") ?? "";
    placename = sharedPreferences.getString("placename") ?? "";
    arename = sharedPreferences.getString("areaname") ?? "";
    cityname = sharedPreferences.getString("cityname") ?? "";
    statename = sharedPreferences.getString("statename") ?? "";
    countryname = sharedPreferences.getString("countryname") ?? "";
    myarea = sharedPreferences.getString("myarea") ?? '';
    mycity = sharedPreferences.getString("mycity") ?? '';
    authtoken = sharedPreferences.getString("authtoken") ?? '';
    // print("Latitude: $latitude");
    // print("Longitude: $longitude");
    // print("Country: $countryname");
    // print("State: $statename");
    // print("City: $cityname");
    // print("Area: $arename");
  }
}
