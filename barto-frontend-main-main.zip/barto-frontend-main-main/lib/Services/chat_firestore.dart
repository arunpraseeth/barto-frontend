import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';

class ChatFirestore with ChangeNotifier {
  List _chatListFullName = [];
  List _chatListAvatar = [];
  List _chatListUserId = [];
  List _chatListUserName = [];
  String _personName = '';
  String _userName = '';
  String _personAvatar = '';
  String _personUserId = '';
  String _chatsellerId = '';
  String _secondId = '';
  String? chatroomDocId;
  Map<String, String> _mapchatroomId = {};

  // ! Create Chat Rooom
  static Future createChatRoom({
    required Map<String, dynamic> chatroomMap,
    required String chatroomId,
  }) async {
    // print("chatroom map: $chatroomMap");
    // print("chatroom map: $chatroomId");
    try {
      FirebaseFirestore.instance
          .collection('chatroom')
          .doc(chatroomId)
          .set(chatroomMap);
      // print('Chatroom created');
      return 200;
    } on FirebaseException catch (e) {
      print('Create chatroom exception :$e');
      return 400;
    }
  }

  // ! Get Chat Rooom document ID Condition 1
  // static Future getchatRoomInfo({required String chatroomId}) async {
  //   try {
  //     // print("Chatroom Id: $chatroomId");
  //     DocumentSnapshot<Map<String, dynamic>> documentSnapshot =
  //         await FirebaseFirestore.instance
  //             .collection("chatroom")
  //             .doc(chatroomId)
  //             .get();
  //     Map<String, dynamic>? chatroomInfo = documentSnapshot.data();
  //     return chatroomInfo;
  //   } on FirebaseException catch (e) {
  //     print('Get chattoom exception: $e');
  //     return 400;
  //   }
  // }

  // ! Create Messages
  static Future createMessage({
    required String chatRoomId,
    required String message,
    required String senderId,
  }) async {
    // print("chatRoomId: $chatRoomId");
    // print("message: $message");
    // print("senderId: $senderId");
    try {
      Map<String, dynamic> data = {
        'message': message,
        'senderId': senderId,
        'chatRoomId': chatRoomId,
        'timestamp': DateTime.now().millisecondsSinceEpoch,
      };
      await FirebaseFirestore.instance
          .collection('chatroom')
          .doc(chatRoomId)
          .collection('messages')
          .add(data);
      return 200;
    } on FirebaseException catch (e) {
      print('Create message exception :$e');
      return 400;
    }
  }

  // ! Get User Profile
  Future getUserProfile({required String userId}) async {
    // print("userid: $userId");
    try {
      FirebaseFirestore.instance
          .collection('users')
          .where("userId", isEqualTo: userId)
          .snapshots()
          .listen((snapshots) {
        for (var snapshotData in snapshots.docs) {
          _personName = snapshotData['name'];
          _personAvatar = snapshotData['avatar'];
          // print("Chat list person name: $_personName");
        }
      });
      notifyListeners();
      return 200;
    } on FirebaseException catch (e) {
      print('Get userprofile exception :$e');
      return 400;
    }
  }

  // ! Get Chat list
  void getChatList({required String userId}) {
    // print("myid: $userId");
    _chatListFullName.clear();
    _chatListAvatar.clear();
    _chatListUserId.clear();
    _chatListUserName.clear();
    try {
      FirebaseFirestore.instance
          .collection('chatroom')
          .where("users", arrayContains: userId)
          .snapshots()
          .listen((snapshots) {
        for (var snapshotData in snapshots.docs) {
          _chatsellerId = snapshotData["sellerId"];
          for (int i = 0; i < snapshotData["users"].length; i++) {
            if (snapshotData["users"][i] != userId) {
              // print("Second user id: ${snapshotData["users"][i]}");
              _secondId = snapshotData["users"][i];
              _mapchatroomId.addAll(
                  {snapshotData["users"][i]: snapshotData["chatroomId"]});
              // ! Check here
              FirebaseFirestore.instance
                  .collection('users')
                  .where("userId", isEqualTo: snapshotData["users"][i])
                  .snapshots()
                  .listen(
                (snapshots) {
                  for (int i = 0; i < snapshots.docs.length; i++) {
                    // print("Contains Avatar: ${snapshots.docs[i].data().containsKey("avatar")}");
                    _personName = snapshots.docs[i]['name'];
                    _userName = snapshots.docs[i]['user_name'];
                    _personAvatar = snapshots.docs[i]['avatar'];
                    _personUserId = snapshots.docs[i]['userId'];
                    // if (snapshots.docs[i].data().containsKey("avatar")) {
                    // }
                    _chatListFullName.add(_personName);
                    _chatListUserName.add(_userName);
                    _chatListUserId.add(_personUserId);
                    _chatListAvatar.add(_personAvatar);
                  }
                  // print("Chat list person name: $_chatListFullName");
                  // print("Chat list person avatar: $_chatListAvatar");
                  // print("Chat list person UserId: $_chatListUserId");
                },
              );
            }
          }
          // print('object: $_mapchatroomId');
        }
      });
      notifyListeners();
    } on FirebaseException catch (e) {
      print('Get userprofile exception :$e');
    }
  }

  String get username => _personName;
  String get avatar => _personAvatar;
  List get chatListAvatar => _chatListAvatar;
  List get chatListFullName => _chatListFullName.toSet().toList();
  List get chatListUserId => _chatListUserId.toSet().toList();
  List get chatListUserName => _chatListUserName.toSet().toList();
  Map<String, String> get mapchatroomId => _mapchatroomId;
  String get chatsellerId => _chatsellerId;
  String get secondId => _secondId;
  // List get personNameList => _personNameList;
}
