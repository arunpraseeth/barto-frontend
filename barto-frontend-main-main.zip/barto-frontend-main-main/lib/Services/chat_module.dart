import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';

class ChatModule with ChangeNotifier {
  
  Future<bool> createChatRoom({
    required String productId,
    required String senderId,
    required String secondId,
  }) async {
    try {
      List<String> users = [
        senderId,
        secondId,
      ];
      Map<String, dynamic> data = {
        'sellerid': secondId,
        'productid': productId,
        'users': users,
      };
      
      await FirebaseFirestore.instance
          .collection("chatroom")
          .doc(senderId)
          .set(data);
      return true;
    } on FirebaseException catch (e) {
      print("Chatroom exception: $e");
      return false;
    }
  }

  Future<bool> createMessage({
    required String message,
    required String senderId,
    required String secondId,
    required String productId,
  }) async {
    try {
      List<String> users = [
        senderId,
        secondId,
      ];
      Map<String, dynamic> data = {
        'message': message,
        'senderid': senderId,
        'productid': productId,
        'users': users,
        'timestamp': DateTime.now().millisecondsSinceEpoch,
      };
      await FirebaseFirestore.instance
          .collection("chat")
          .doc(productId)
          .collection("chatroom")
          .doc(senderId)
          .collection("messages")
          .add(data);
      return true;
    } on FirebaseException catch (e) {
      print("Create message exception: $e");
      return false;
    }
  }
}
