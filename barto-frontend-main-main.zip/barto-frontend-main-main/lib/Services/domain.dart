class Domain {
  // static String url = 'https://eedd-2405-201-e017-fb72-53a-a5a4-29e7-fab6.ngrok.io';
  // static String url = 'http://192.168.0.165:3003';
  static String url = 'https://api.bartoindia.com';
}
