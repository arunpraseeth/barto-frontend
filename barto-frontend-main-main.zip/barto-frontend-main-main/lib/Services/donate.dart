import 'dart:convert';
import 'dart:io';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:india/Services/domain.dart';

class Donate with ChangeNotifier {
  late int _currentpagenumber;
  List<dynamic> _topdonators = [];
  List<dynamic> _mydonationList = [];

  static Future buyDonation({
    required String authtoken,
    required String amount,
  }) async {
    try {
      String url = "${Domain.url}/client/donation";
      Map<String, String> header = {
        'authorization': authtoken.isEmpty ? "" : 'Bearer ' + authtoken
      };
      Map<String, String> body = {"amount": amount};
      var response =
          await http.post(Uri.parse(url), headers: header, body: body);
      var jsondata = json.decode(response.body);
      // print("Buy donation response: $jsondata");
      return jsondata;
    } on HttpException catch (e) {
      print("Buy donation exception: $e");
    }
  }

  static Future verifyDonation({
    required String paymentId,
    required String razororderId,
    required String razorpaymentId,
    required String paymentSignature,
    required String authtoken,
  }) async {
    try {
      String url = "${Domain.url}/client/payment/donation/verify";
      Map<String, String> header = {
        'authorization': authtoken.isEmpty ? "" : 'Bearer ' + authtoken
      };
      Map<String, dynamic> body = {
        "payment_id": paymentId,
        "razor_order_id": razororderId,
        "razor_payment_id": razorpaymentId,
        "payment_signature": paymentSignature,
      };
      var response =
          await http.post(Uri.parse(url), headers: header, body: body);
      var jsondata = json.decode(response.body);
      // print("Verify donation response: $jsondata");
      return jsondata;
    } on HttpException catch (e) {
      print("Verify donation exception: $e");
    }
  }

  Future topDonators({
    required String authtoken,
    required bool refresh,
  }) async {
    try {
      if (refresh) {
        _currentpagenumber = 1;
        _topdonators.clear();
      } else {
        _currentpagenumber++;
      }
      String url = "${Domain.url}/client/donation/$_currentpagenumber";
      Map<String, String> header = {
        'authorization': authtoken.isEmpty ? "" : 'Bearer ' + authtoken
      };
      var response = await http.get(Uri.parse(url), headers: header);
      var jsondata = json.decode(response.body);
      // print("Top donators response: $jsondata");
      if (jsondata["status"] == 200) {
        Map<String, dynamic> _response = jsondata["response"];
        Map<String, dynamic> _data = _response["data"];
        Map<String, dynamic> _info = _data["info"];
        List<dynamic> donation = [..._info["donation"]];
        if (donation.isNotEmpty) {
          for (var _donators in donation) {
            _topdonators.add(_donators);
          }
        }
        _currentpagenumber = _info["page_no"];
      }
      notifyListeners();
      return jsondata;
    } on HttpException catch (e) {
      print("Top donators exception: $e");
    }
  }

  Future myDonations({
    required String authtoken,
  }) async {
    try {
      String url = "${Domain.url}/client/donation/myDonation";
      Map<String, String> header = {
        'authorization': authtoken.isEmpty ? "" : 'Bearer ' + authtoken
      };
      var response = await http.get(Uri.parse(url), headers: header);
      var jsondata = json.decode(response.body);
      // print("My donations response: $jsondata");
      if (jsondata["status"] == 200) {
        Map<String, dynamic> _response = jsondata["response"];
        Map<String, dynamic> _data = _response["data"];
        List<dynamic> _info = _data["info"];
        _mydonationList = _info;
      }
      notifyListeners();
      return jsondata;
    } on HttpException catch (e) {
      print("My donations exception: $e");
    }
  }

  List<dynamic> get topdonators => _topdonators.toSet().toList();
  List<dynamic> get mydonationList => _mydonationList.toSet().toList();
}
