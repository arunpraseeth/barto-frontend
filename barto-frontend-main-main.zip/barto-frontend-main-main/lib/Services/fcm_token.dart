import 'package:firebase_messaging/firebase_messaging.dart';
import 'package:shared_preferences/shared_preferences.dart';

class FcmToken {
  static Future<String> getToken() async {
    var fcmToken = await FirebaseMessaging.instance.getToken();
    // print('FCM token: $fcmToken');
    SharedPreferences sharedPreferences = await SharedPreferences.getInstance();
    sharedPreferences.setString("fcmtoken", fcmToken!); 
    return fcmToken;
  }
}
