import 'dart:convert';
import 'dart:io';
import 'package:http/http.dart' as http;
import 'package:india/Services/domain.dart';

class FeedbackService {
  static Future feedbackService({
    required String authtoken,
    required String type,
    required String feedback,
  }) async {
    try {
      String url = '${Domain.url}/client/profile/Feedback';
      Map<String, String> head = {
        'authorization': authtoken.isEmpty ? "" : 'Bearer ' + authtoken
      };
      Map<String, String> locationmap = {
        "fb_types": type,
        "feedback": feedback,
      };
      var response =
          await http.post(Uri.parse(url), body: locationmap, headers: head);
      var jsonData = json.decode(response.body);
      // print("Feedback service response: ${response.body}");
      return jsonData;
    } on HttpException catch (e) {
      print("Feedback service error: $e");
    }
  }
}
