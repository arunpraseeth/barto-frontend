import 'dart:convert';
import 'dart:io';
import 'package:http/http.dart' as http;
import 'package:flutter/material.dart';
import 'package:india/Services/domain.dart';

class FilterProducts with ChangeNotifier {
  // ignore: unused_field
  int _radius = 1;
  int? _radiusfilter;
  late int _totalPage;
  late int currentpageno;
  List _productsinfoList = [];
  List _productinfoapi = [];
  List _product = [];
  late int _currentpagenumber;
  late Map<String, dynamic> nextRadius;
  Map<String, dynamic> _response = {};
  Map<String, dynamic> _data = {};
  Map<String, dynamic> _info = {};
  Map<String, dynamic> _productfilters = {};

  Future<dynamic> filterbyCategories({
    required String authtoken,
    required bool refresh,
    required String categoryId,
    required String country,
    required String state,
    required String city,
    required String area,
    required String filters,
    required String sort,
  }) async {
    try {
      if (refresh) {
        currentpageno = 1;
        _radius = 1;
        _productsinfoList.clear();
      } else {
        if (_currentpagenumber <= _totalPage) {
          currentpageno++;
          if (_info.containsKey("nextRadius")) {
            _radiusfilter = _info["nextRadius"]["radius_filter"];
            if ((_currentpagenumber == _totalPage) && (_radiusfilter != 0)) {
              currentpageno = 1;
              _radius = _radiusfilter!;
            }
          }
        }
      }
      Map<String, String> body = {
        "category_id": categoryId,
        "country": country,
        "state": state,
        "city": city,
        "area": area,
        "filteroptions": filters,
        "sortoptions": sort,
      };

      Map<String, String> head = {
        'authorization': authtoken.isEmpty ? "" : 'Bearer ' + authtoken
      };
      String url =
          "${Domain.url}/client/product/filterdata?page_no=$currentpageno";
      var response = await http.post(Uri.parse(url), body: body, headers: head);
      var jsonData = json.decode(response.body);
      // print("Get filter product by category response: $jsonData");
      if (jsonData["status"] == 200) {
        _response = jsonData["response"];
        _data = _response["data"];
        _info = _data["info"];
        _product = [..._info["products"]];
        _productinfoapi = _product;
        if (_product.isNotEmpty) {
          for (var product in _product) {
            _productsinfoList.add(product);
          }
          _totalPage = _info["page_count"];
          _currentpagenumber = _info["page_no"];
          _productfilters = _info["product_filters"];
        }
      }
      notifyListeners();
      return jsonData;
    } on HttpException catch (e) {
      print('Get filter product http exception: $e');
      return 400;
    }
  }

  clearfilterProduct() {
    // _productsinfoList.clear();
    _productinfoapi.clear();
    notifyListeners();
  }

  List<dynamic> get productlist => _productsinfoList.toSet().toList();
  List<dynamic> get productinfoapi => productinfoapi.toSet().toList();
  Map<String, dynamic> get productfilters => _productfilters;
  int get filterproducttotalPage => _totalPage;
  int get filterproductcurrentPage => currentpageno;
}
