import 'dart:convert';
import 'dart:io';
import "package:http/http.dart" as http;
import 'package:flutter/material.dart';
import 'package:india/Services/domain.dart';

class GetHome with ChangeNotifier {
  int _radius = 1;
  int? _radiusfilter;
  late int _totalPage;
  late int _currentpagenumber;
  late int currentpageno;
  List _categoryList = [];
  List _product = [];
  List _productsinfoList = [];
  late Map<String, dynamic> nextRadius;
  Map<String, dynamic> _response = {};
  Map<String, dynamic> _data = {};
  Map<String, dynamic> _info = {};

  Future getProducts({
    required String lat,
    required String long,
    required bool refresh,
    String authtoken = '',
  }) async {
    try {
      if (refresh) {
        _product.clear();
        _productsinfoList.clear();
        currentpageno = 1;
        _radius = 1;
      } else {
        if (_currentpagenumber <= _totalPage) {
          currentpageno++;
          if (_info.containsKey("nextRadius")) {
            _radiusfilter = _info["nextRadius"]["radius_filter"];
            if ((_currentpagenumber == _totalPage) && (_radiusfilter != 0)) {
              currentpageno = 1;
              _radius = _radiusfilter!;
            }
          }
        }
      }
      Map<String, String> head = {
        'authorization': authtoken.isEmpty ? "" : 'Bearer ' + authtoken
      };
      Map<String, String> locationmap = {
        "lat": lat,
        "long": long,
        "radius_filter": "$_radius",
      };
      String url = "${Domain.url}/client/home?page_no=$currentpageno";

      var response =
          await http.post(Uri.parse(url), body: locationmap, headers: head);
      var jsonData = json.decode(response.body);
      // print("Get product info: $jsonData");
      if (jsonData["status"] == 200) {
        _response = jsonData["response"];
        _data = _response["data"];
        _info = _data["info"];
        _product = [..._info["products"]];
        _totalPage = _info["page_count"];
        _currentpagenumber = _info["page_no"];
        if (_product.isNotEmpty) {
          for (var product in _product) {
            _productsinfoList.add(product);
          }
        }
      }
      notifyListeners();
      return jsonData;
    } on HttpException catch (e) {
      print('Get product info http exception: $e');
      throw 400;
    }
  }

  // clearProductsList() {
  //   _productsinfoList.clear();
  //   notifyListeners();
  // }

  Future getCategories() async {
    try {
      String url = "${Domain.url}/client/home/categories";
      var response = await http.get(Uri.parse(url));
      var jsonData = json.decode(response.body);
      // print("Get categories: $jsonData");
      if (jsonData["status"] == 200) {
        _categoryList = jsonData["response"]["data"]["info"];
      }
      notifyListeners();
      return jsonData;
    } on HttpException catch (e) {
      print('Get categories http exception: $e');
      throw 400;
    }
  }

  List get productinfoList => _productsinfoList.toSet().toList();
  List get categoryList => _categoryList;
  int get currentpagenumber => _currentpagenumber;
  int get totalPage => _totalPage;
  int get radius => _radius;
}
