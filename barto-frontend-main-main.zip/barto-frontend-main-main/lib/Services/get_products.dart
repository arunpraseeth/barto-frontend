import 'dart:convert';
import 'dart:io';
import 'package:http/http.dart' as http;
import 'package:flutter/material.dart';
import 'package:india/Services/domain.dart';

class ProductInformation with ChangeNotifier {
  Map<String, dynamic> _productinfo = {};
  Future getproductInformation(
      {required String productid, required String? authtoken}) async {
    try {
      String url = "${Domain.url}/client/product/get/$productid";
      Map<String, String> head = {
        'authorization': authtoken == null ? "" : 'Bearer ' + authtoken
      };
      var response = await http.get(Uri.parse(url), headers: head);
      var jsonData = json.decode(response.body);
      // print("Get my product information: $jsonData");
      if (jsonData["status"] == 200) {
        Map<String, dynamic> _response = jsonData["response"];
        Map<String, dynamic> _data = _response["data"];
        Map<String, dynamic> _info = _data["info"];
        _productinfo = _info["product_info"];
      }
      notifyListeners();
      return jsonData;
    } on HttpException catch (e) {
      print('Get categories http exception: $e');
      throw 400;
    }
  }

  Map<String, dynamic> get productinfo => _productinfo;
}
