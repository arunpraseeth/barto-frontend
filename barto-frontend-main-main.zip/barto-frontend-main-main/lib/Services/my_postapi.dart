import 'dart:convert';
import 'dart:io';
import 'package:http/http.dart' as http;
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:india/Services/domain.dart';

class MyPostApi with ChangeNotifier {
  List _nonpaidproductinfo = [];
  List _paidproductinfo = [];
  Future nonpaid({required String? authtoken}) async {
    try {
      String url = "${Domain.url}/client/product/getNonPaid";
      Map<String, String> head = {
        'authorization': authtoken == null ? "" : 'Bearer ' + authtoken
      };
      var response = await http.get(Uri.parse(url), headers: head);
      var jsonData = json.decode(response.body);
      // print("Non paid ads: $jsonData");
      if (jsonData["status"] == 200) {
        Map<String, dynamic> _response = jsonData["response"];
        Map<String, dynamic> _data = _response["data"];
        _nonpaidproductinfo = _data["info"];
      }
      notifyListeners();
      return jsonData;
    } on HttpException catch (e) {
      print('Non paid products http exception: $e');
      throw 400;
    }
  }

  Future paid({required String? authtoken}) async {
    try {
      String url = "${Domain.url}/client/product/getPaid";
      Map<String, String> head = {
        'authorization': authtoken == null ? "" : 'Bearer ' + authtoken
      };
      var response = await http.get(Uri.parse(url), headers: head);
      var jsonData = json.decode(response.body);
      // print("Paid ads: $jsonData");
      if (jsonData["status"] == 200) {
        _paidproductinfo = jsonData["response"]["data"]["info"];
      }
      return jsonData;
    } on HttpException catch (e) {
      print('Paid products http exception: $e');
      throw 400;
    }
  }

  Future editPost({
    required String authtoken,
    required String productid,
    required Map<String, String> bodyMap,
    List<XFile>? images,
  }) async {
    try {
      String url = '${Domain.url}/client/product/update/$productid';

      //create multipart request for POST or PATCH method
      var request = http.MultipartRequest("PUT", Uri.parse(url));

      //Header
      Map<String, String> head = {'authorization': 'Bearer ' + authtoken};

      //Adding headers to request
      request.headers.addAll(head);

      Map<String, String> body = bodyMap;

      //Adding dictionaries to request
      request.fields.addAll(body);

      if (images != null) {
        for (int i = 0; i < images.length; i++) {
          var pic = await http.MultipartFile.fromPath(
              "product_image", images[i].path);
          request.files.add(pic);
        }
      }

      //Send request
      var response = await request.send();

      //Get the response from the server
      var responseData = await response.stream.toBytes();
      var responseImage = String.fromCharCodes(responseData);
      // print('Edit Product upload response: $responseImage');
      var jsonData = json.decode(responseImage);
      // if (jsonData["status"] == 200 &&
      //     jsonData["response"]["data"]["fetched"] == true) {

      // }
      notifyListeners();
      return jsonData;
    } on HttpException catch (e) {
      print('Edit Product upload exception: $e');
      return 400;
    }
  }

  List get nonpaidproductinfo => _nonpaidproductinfo.toSet().toList();
  List get paidproductinfo => _paidproductinfo.toSet().toList();
}
