import 'dart:convert';
import 'dart:io';
import 'package:http/http.dart' as http;
import 'package:flutter/material.dart';
import 'package:india/Services/domain.dart';

class NotificationApi with ChangeNotifier {
  List<dynamic> _notifications = [];
  Future getnotificationapi({required String authtoken}) async {
    try {
      _notifications.clear();
      String url = "${Domain.url}/client/notification";

      Map<String, String> head = {'authorization': 'Bearer ' + authtoken};
      var response = await http.get(Uri.parse(url), headers: head);
      var jsonData = json.decode(response.body);
      // print("Notification list response: $jsonData");
      if (jsonData["status"] == 200) {
        Map<String, dynamic> _response = jsonData["response"];
        Map<String, dynamic> _data = _response["data"];
        if (_data["info"] != null) {
          Map<String, dynamic> _info = _data["info"];
          _notifications = _info["notifications"];
        } else {
          _notifications = [];
        }
      }
      notifyListeners();
      return jsonData;
    } on HttpException catch (e) {
      print('Notification list exception: $e');
      return 400;
    }
  }

  static Future deletenotificationapi({
    required String index,
    required String authtoken,
  }) async {
    try {
      String url = "${Domain.url}/client/notification/delete";
      Map<String, dynamic> body = {
        "index": index,
      };
      Map<String, String> head = {'authorization': 'Bearer ' + authtoken};
      var response = await http.post(Uri.parse(url), body: body, headers: head);
      var jsonData = json.decode(response.body);
      // print("Delete notification list response: $jsonData");
      return jsonData;
    } on HttpException catch (e) {
      print('Notification list exception: $e');
      return 400;
    }
  }

  List<dynamic> get notificationList => _notifications;
}
