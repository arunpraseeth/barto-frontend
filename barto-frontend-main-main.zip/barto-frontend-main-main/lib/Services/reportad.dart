import 'dart:convert';
import 'dart:io';
import 'package:http/http.dart' as http;
import 'package:india/Services/domain.dart';

class ReportAd {
  static Future reportad({
    required String productid,
    required String report,
    required String authtoken,
  }) async {
    try {
      String url = "${Domain.url}/client/product/report?product_id=$productid";
      Map<String, dynamic> body = {
        "report": report,
      };
      Map<String, String> head = {'authorization': 'Bearer ' + authtoken};
      var response = await http.post(Uri.parse(url), body: body, headers: head);
      var jsonData = json.decode(response.body);
      // print("Report Ad response: $jsonData");
      return jsonData;
    } on HttpException catch (e) {
      print('Report Ad http exception: $e');
      return 400;
    }
  }
}
