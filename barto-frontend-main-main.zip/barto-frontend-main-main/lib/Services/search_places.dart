import 'dart:convert';
import 'dart:io';
import 'package:flutter_dotenv/flutter_dotenv.dart';
import 'package:http/http.dart' as http;
import 'package:flutter/material.dart';
import 'package:india/Model/location.dart';
import 'package:provider/provider.dart';
import 'package:shared_preferences/shared_preferences.dart';

class SearchPlaces with ChangeNotifier {
  // List _placename = [];
  // List _placeLatLong = [];
  List _placefeatures = [];
  String placename = '';
  String _myarea = '';
  String _mycity = '';
  String _mystate = '';
  String _mycountry = '';

  // Forwad geocoding
  Future searchPlaces({
    required String placeName,
  }) async {
    try {
      // _placename.clear();
      // _placeLatLong.clear();
      String apiKey = dotenv.get('PUBLICAPIKEY');
      String url =
          'https://api.mapbox.com/geocoding/v5/mapbox.places/$placeName.json?country=IN&access_token=$apiKey';
      var response = await http.get(Uri.parse(url));
      var jsonData = json.decode(response.body);
      // print("Search places: $jsonData");
      _placefeatures = jsonData["features"];
      notifyListeners();
    } on HttpException catch (e) {
      print('Search product  http exception: $e');
      return 400;
    }
  }

  // Reverse geocoding
  Future myLocation({
    required double longitude,
    required double latitude,
    required BuildContext providercontext,
  }) async {
    SharedPreferences sharedPreferences = await SharedPreferences.getInstance();
    try {
      String apiKey = dotenv.get('PUBLICAPIKEY');
      String url =
          'https://api.mapbox.com/geocoding/v5/mapbox.places/$longitude,$latitude.json?country=IN&access_token=$apiKey';

      var response = await http.get(Uri.parse(url));
      var jsonData = json.decode(response.body);
      // print("My location: $jsonData");
      List feature = jsonData["features"];
      if (feature.isNotEmpty) {
        List context = feature[0]["context"];
        if (context.isNotEmpty) {
          await sharedPreferences.remove("areaname");
          await sharedPreferences.remove("myarea");
          await sharedPreferences.remove("cityname");
          await sharedPreferences.remove("mycity");
          await sharedPreferences.remove("statename");
          await sharedPreferences.remove("countryname");
          placename = feature[0]["place_name"];
          if (context.length == 6) {
            _myarea = context[1]["text"];
            _mycity = context[2]["text"];
            _mystate = context[4]["text"];
            _mycountry = context[5]["text"];
            Provider.of<StoreLocation>(providercontext, listen: false)
                .storeLocation(
              lat: latitude,
              long: longitude,
              placename: placename,
              areaname: _myarea,
              cityname: _mycity,
              statename: _mystate,
              countryname: _mycountry,
            );
          } else if (context.length == 5) {
            _myarea = context[0]["text"];
            _mycity = context[1]["text"];
            _mystate = context[3]["text"];
            _mycountry = context[4]["text"];
            Provider.of<StoreLocation>(providercontext, listen: false)
                .storeLocation(
              lat: latitude,
              long: longitude,
              placename: placename,
              areaname: _myarea,
              cityname: _mycity,
              statename: _mystate,
              countryname: _mycountry,
            );
          } else if (context.length == 4) {
            _myarea = context[0]["text"];
            _mycity = context[1]["text"];
            _mystate = context[2]["text"];
            _mycountry = context[3]["text"];
            Provider.of<StoreLocation>(providercontext, listen: false)
                .storeLocation(
              lat: latitude,
              long: longitude,
              placename: placename,
              areaname: _myarea,
              cityname: _mycity,
              statename: _mystate,
              countryname: _mycountry,
            );
          } else if (context.length == 3) {
            _mycity = context[0]["text"];
            _mystate = context[1]["text"];
            _mycountry = context[2]["text"];
            Provider.of<StoreLocation>(providercontext, listen: false)
                .storeLocation(
              lat: latitude,
              long: longitude,
              placename: placename,
              cityname: _mycity,
              statename: _mystate,
              countryname: _mycountry,
            );
          } else {
            Provider.of<StoreLocation>(providercontext, listen: false)
                .storeLocation(
              lat: latitude,
              long: longitude,
              placename: placename,
            );
          }
        }
      }

      await sharedPreferences.setString("latitude", "$latitude");
      await sharedPreferences.setString("longitude", "$longitude");
      await sharedPreferences.setString("placename", placename);
      await sharedPreferences.setString("areaname", _myarea);
      await sharedPreferences.setString('myarea', _myarea);
      await sharedPreferences.setString("cityname", _mycity);
      await sharedPreferences.setString('mycity', _mycity);
      await sharedPreferences.setString("statename", _mystate);
      await sharedPreferences.setString("countryname", _mycountry);

      // print(feature[2]["text"]); /* Area*/
      // print(feature[3]["text"]); /* City*/
      // print(feature[4]["text"]); /* State*/
      // print(feature[5]["text"]); /* Country*/
      notifyListeners();
      return feature;
    } on HttpException catch (e) {
      print('Search product  http exception: $e');
      return 400;
    }
  }

  clearPlaceName() {
    _placefeatures.clear();
    notifyListeners();
  }

  // List get placename => _placename;
  // List get placelatlong => _placeLatLong;
  List get placefeatures => _placefeatures;
  String get myArea => _myarea;
  String get myCity => _mycity;
  String get myState => _mystate;
  String get myCountry => _mycountry;
}
