import 'dart:io';
import 'dart:convert';
import 'package:http/http.dart' as http;
import 'package:flutter/material.dart';
import 'package:india/Services/domain.dart';

class SearchProduct with ChangeNotifier {
  late int currentpageno;
  late int _totalPage;
  late int _currentpagenumber;
  int _radius = 1;
  int? _radiusfilter;
  late Map<String, dynamic> nextRadius;
  Map<String, dynamic> _response = {};
  Map<String, dynamic> _data = {};
  Map<String, dynamic> _info = {};
  List _searchproductsList = [];
  late List _productsinfoList = [];

  Future<dynamic> searchproduct({
    String? name,
    required String authtoken,
    required String categoryId,
    required String latitude,
    required String longitude,
    bool refresh = false,
  }) async {
    try {
      if (refresh) {
        _productsinfoList.clear();
        // _searchproductsList.clear();
        currentpageno = 1;
        _radius = 1;
      } else {
        if (_currentpagenumber <= _totalPage) {
          currentpageno++;
          // print("Current page: $currentpageno");
          // print("Current page return: $_currentpagenumber");
          // print("Total page: $_totalPage");
          if (_info.containsKey("nextRadius")) {
            _radiusfilter = _info["nextRadius"]["radius_filter"];
            // print("Radius filter: ${_info["nextRadius"]}");
            if ((_currentpagenumber == _totalPage) && (_radiusfilter != 0)) {
              currentpageno = 1;
              _radius = _radiusfilter!;
              // print("Radius: $_radius");
              // print("Current page: $currentpageno");
            }
          }
        }
      }

      // print("Product name: $name");
      // print("Radius filter main: $_radius");
      // print("current page main: $currentpageno");

      Map<String, String> data = {
        "category": categoryId,
        "lat": latitude,
        "long": longitude,
        "radius_filter": "$_radius",
      };

      // print("authtoken: $authtoken");

      String url =
          '${Domain.url}/client/product/search/?page_no=$currentpageno&product_name=$name';

      Map<String, String> head = {
        'authorization': authtoken.isEmpty ? "" : 'Bearer ' + authtoken
      };
      var response = await http.post(Uri.parse(url), body: data, headers: head);
      var jsonData = json.decode(response.body);
      // print("Search product response: $jsonData");
      if (jsonData["status"] == 200) {
        _response = jsonData["response"];
        _data = _response["data"];
        _info = _data["info"];
        _searchproductsList = [..._info["products"]];
        _totalPage = _info["page_count"];
        _currentpagenumber = _info["page_no"];
        if (_searchproductsList.isNotEmpty) {
          for (var product in _searchproductsList) {
            _productsinfoList.add(product);
          }
        }
      }
      notifyListeners();
      return jsonData;
    } on HttpException catch (e) {
      print('Search product  http exception: $e');
      return 400;
    }
  }

  clearSearch() {
    // _searchproductsList.clear();
    _productsinfoList.clear();
    notifyListeners();
  }

  List get searchproductsList => [..._productsinfoList].toSet().toList();
}
