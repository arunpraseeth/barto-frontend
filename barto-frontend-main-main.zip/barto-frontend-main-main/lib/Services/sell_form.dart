import 'dart:convert';
import 'dart:io';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:image_picker/image_picker.dart';
import 'package:india/Services/domain.dart';
// import 'package:india/dynamic_input/dynamic_input1.dart';

class SellForm with ChangeNotifier {
  List _categoryList = [];
  List _categoryFormList = [];
  String? _productid;
  List _plans = [];
  late String _paymentid;
  late String _amount;
  late String _razorOrderId;
  // ServiceResult? _serviceResult;
  List<String> _dropdownListValues = [];
  Future<dynamic> getCategory() async {
    try {
      String url = "${Domain.url}/client/home/categories";
      var response = await http.get(Uri.parse(url));
      var jsonData = json.decode(response.body);
      // print("Get category response: $jsonData");
      if (jsonData["status"] == 200) {
        Map<String, dynamic> _response = jsonData["response"];
        Map<String, dynamic> _data = _response["data"];
        _categoryList = _data["info"];
      }
      notifyListeners();
      return jsonData;
    } on HttpException catch (e) {
      print('Get category http exception: $e');
      return 400;
    }
  }

  Future<dynamic> getCategoryForm({required String categoryId}) async {
    // Future<ServiceResult> getCategoryForm({required String categoryId}) async {
    try {
      // print("categoryid: $categoryId");
      String url = "${Domain.url}/client/product/getForm/$categoryId";
      var response = await http.get(Uri.parse(url));
      Map<String, dynamic> jsonData = json.decode(response.body);
      // debugPrint("Get category form response: $jsonData");
      List<dynamic> _formdata = jsonData["response"]["data"]["info"]["form"];
      // ServiceResult result = ServiceResult.fromJson(jsonData);
      // return result;
      if (jsonData["status"] == 200 && _formdata.isNotEmpty) {
        _categoryFormList =
            jsonData["response"]["data"]["info"]["form"][0]["fields"];
        _dropdownListValues.clear();
        for (int i = 0; i < _categoryFormList.length; i++) {
          if (_categoryFormList[i]["type"] == "dropdown") {
            // print(_categoryFormList[i]["name"]);
            for (int j = 0;
                j < _categoryFormList[i]["codeGroup"]["codeValues"].length;
                j++) {
              // log(_categoryFormList[i]["codeGroup"]["codeValues"][j]["name"]);
              // print(
              //     "${_categoryFormList[i]["codeGroup"]["name"]}:${_categoryFormList[i]["codeGroup"]["codeValues"][j]["name"]}");
              _dropdownListValues.add(
                  _categoryFormList[i]["codeGroup"]["codeValues"][j]["name"]);
            }
          }
        }
        // print(_dropdownListValues);
        notifyListeners();
      } else if (jsonData["status"] == 200 && _formdata.isEmpty) {
        _categoryFormList = jsonData["response"]["data"]["info"]["form"];
        notifyListeners();
      }
      return jsonData;
    } on HttpException catch (e) {
      print('Get category form http exception: $e');
      throw Exception("Server Error !");
    }
  }

  Future<dynamic> uploadProduct({
    required String? authtoken,
    required String? categoryId,
    required String? productName,
    required String? productDescription,
    required String? price,
    required Map? dynamicMap,
    required List<XFile>? images,
    required String countryname,
    required String statename,
    required String cityname,
    required String areaname,
    required String latitude,
    required String longitude,
  }) async {
    try {
      print("Images length: ${images!.length}");
      Map<String, String> location = {
        "country": countryname,
        "state": statename,
        "city": cityname,
        "area": areaname,
        "lat": latitude,
        "long": longitude,
      };
      String locationencoded = json.encode(location);
      String dynamicMapencoded = json.encode(dynamicMap);
      String url = '${Domain.url}/client/product/add';

      //create multipart request for POST or PATCH method
      var request = http.MultipartRequest("POST", Uri.parse(url));

      Map<String, String> data = {
        "category_id": categoryId!,
        "product_name": productName!,
        "product_description": productDescription!,
        "price": price!,
        "product_location": locationencoded,
        "product_details": dynamicMapencoded,
      };
      for (int i = 0; i < images.length; i++) {
        var pic =
            await http.MultipartFile.fromPath("product_image", images[i].path);
        request.files.add(pic);
      }

      // //Header
      Map<String, String> head = {'authorization': 'Bearer ' + authtoken!};

      //Adding headers to request
      request.headers.addAll(head);

      //Adding dictionaries to request
      request.fields.addAll(data);

      //Send request
      var response = await request.send();

      //Get the response from the server
      var responseData = await response.stream.toBytes();
      var responseImage = String.fromCharCodes(responseData);
      var jsonData = json.decode(responseImage);
      // print('Product upload response: $jsonData');
      if (jsonData["status"] == 200) {
        Map<String, dynamic> _response = jsonData["response"];
        Map<String, dynamic> _data = _response["data"];
        Map<String, dynamic> _info = _data["info"];
        if (_data["fetched"] == true) {
          _productid = _info["product_id"];
        }
      }
      notifyListeners();
      return jsonData;
    } on HttpException catch (e) {
      print('Product upload http exception: $e');
      return 400;
    }
  }

  Future getplans(
      {required String productid, required String authtoken}) async {
    try {
      String url = '${Domain.url}/client/plan/getPlan';
      Map<String, String> head = {'authorization': 'Bearer ' + authtoken};
      var response = await http.get(Uri.parse(url), headers: head);
      Map<String, dynamic> jsonData = json.decode(response.body);
      // print("Get plans response: $jsonData");
      if (jsonData["status"] == 200) {
        Map<String, dynamic> _response = jsonData["response"];
        Map<String, dynamic> _data = _response["data"];
        _plans = _data["info"];
      }
      notifyListeners();
      return jsonData;
    } on HttpException catch (e) {
      print("Get plans exception: $e");
      return 400;
    }
  }

  Future buyplans({
    required String productid,
    required String authtoken,
    required String planId,
  }) async {
    try {
      String url = '${Domain.url}/client/subscription/buyPlan';
      Map<String, String> head = {'authorization': 'Bearer ' + authtoken};
      Map<String, String> body = {
        "product_id": productid,
        "plan_id": planId,
      };
      var response = await http.post(Uri.parse(url), body: body, headers: head);
      Map<String, dynamic> jsonData = json.decode(response.body);
      // print("Buy plans response: $jsonData");
      if (jsonData["status"] == 200) {
        Map<String, dynamic> _response = jsonData["response"];
        Map<String, dynamic> _data = _response["data"];
        Map<String, dynamic> _info = _data["info"];
        Map<String, dynamic> _orderDetails = _info["order_details"];
        _paymentid = _orderDetails["payment_id"];
        _amount = "${_orderDetails["amount"]}";
        _razorOrderId = _orderDetails["razor_order_id"];
      }
      notifyListeners();
      return jsonData;
    } on HttpException catch (e) {
      print("Buy plans exception: $e");
      return 400;
    }
  }

  // ServiceResult? get serviceResult => _serviceResult;
  List get categoryList => _categoryList;
  List get categoryFormList => _categoryFormList;
  List<String> get dropdownListValues => _dropdownListValues;
  String? get productId => _productid;
  List get plans => _plans;
  String get paymentid => _paymentid;
  String get amountid => _amount;
  String get razorOrderId => _razorOrderId;
}
