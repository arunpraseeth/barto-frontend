import 'dart:io';
import 'dart:convert';
import 'package:http/http.dart' as http;
import 'package:flutter/material.dart';
import 'package:india/Services/domain.dart';

class SellerDetails with ChangeNotifier {
  Map<String, dynamic> _sellerdetail = {};
  late bool _boolfollow;

  Future getsellerDetails({
    required String username,
    required String? authtoken,
  }) async {
    try {
      String url = '${Domain.url}/client/profile/view-seller/$username';
      Map<String, String> head = {
        'authorization': authtoken == null ? "" : 'Bearer ' + authtoken
      };
      var response = await http.get(Uri.parse(url), headers: head);
      Map<String, dynamic> jsonData = await json.decode(response.body);
      // print("Get seller details: $jsonData");
      if (jsonData["status"] == 200) {
        Map<String, dynamic> _response = jsonData["response"];
        Map<String, dynamic> _data = _response["data"];
        Map<String, dynamic> _info = _data["info"];
        Map<String, dynamic> _sellerFollow = _info["profile"];
        _sellerdetail = _info;
        _boolfollow = _sellerFollow["isFollowing"];
      }
      notifyListeners();
      return jsonData;
    } on HttpException catch (e) {
      print('Get seller details exception: $e');
      return 400;
    }
  }

  Future followUnFollow({
    required String username,
    required String followstatus,
    required String? authtoken,
  }) async {
    try {
      String url = '${Domain.url}/client/profile/follow-user';
      Map<String, String> head = {
        'authorization': authtoken == null ? "" : 'Bearer ' + authtoken
      };
      Map<String, String> data = {
        "user_name": username,
        "follow_status": followstatus,
      };
      var response = await http.post(Uri.parse(url), body: data, headers: head);
      Map<String, dynamic> jsonData = await json.decode(response.body);
      // print("Follow: $jsonData");
      // if (jsonData["status"] == 200) {
      // _boolfollow = jsonData["response"]["data"]["info"];
      // }
      return jsonData;
    } on HttpException catch (e) {
      print('Follow exception: $e');
      return 400;
    }
  }

  static Future blockuser({
    required String username,
    required String? authtoken,
  }) async {
    try {
      String url = '${Domain.url}/client/profile/blockOrUnblock';
      Map<String, String> head = {
        'authorization': authtoken == null ? "" : 'Bearer ' + authtoken
      };
      Map<String, String> data = {
        "user_name": username,
        "block_status": "Block",
      };
      var response = await http.post(Uri.parse(url), body: data, headers: head);
      Map<String, dynamic> jsonData = await json.decode(response.body);
      // print("Block: $jsonData");
      // if (jsonData["status"] == 200) {
      //   _sellerdetail = jsonData["response"]["data"]["info"];
      // }
      return jsonData;
    } on HttpException catch (e) {
      print('Block exception: $e');
      return 400;
    }
  }

  followUser() {
    _boolfollow = !_boolfollow;
    notifyListeners();
  }

  Map<String, dynamic> get sellerDetail => _sellerdetail;
  bool get followOrUnfollow => _boolfollow;
}
