import 'dart:convert';
import 'dart:io';
import 'package:http/http.dart' as http;
import 'package:india/Services/domain.dart';

class SendPaymentId {
  static Future sendpaymentid({
    required String paymentId,
    required String razororderId,
    required String razorpaymentId,
    required String paymentSignature,
    required String authtoken,
  }) async {
    try {
      String url = "${Domain.url}/client/payment/verify";
      Map<String, dynamic> body = {
        "payment_id": paymentId,
        "razor_order_id": razororderId,
        "razor_payment_id": razorpaymentId,
        "payment_signature": paymentSignature,
      };
      // print("Body: $body");
      Map<String, String> head = {'authorization': 'Bearer ' + authtoken};
      // if (refresh == true) {
      var response = await http.post(Uri.parse(url), body: body, headers: head);
      var jsonData = json.decode(response.body);
      // print("Send payment id: $jsonData");
      return jsonData;
    } on HttpException catch (e) {
      print('Send payment exception: $e');
      return 400;
    }
  }
}
