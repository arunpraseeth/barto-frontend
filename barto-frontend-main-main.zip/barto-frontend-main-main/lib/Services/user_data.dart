import 'dart:convert';
import 'dart:io';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:india/Services/domain.dart';

class UserData with ChangeNotifier {
  String _fullname = '';
  String _username = '';
  String _email = '';
  String _gender = '';
  String _phone = '';
  String _avatar = '';
  String _dob = '';
  String _userId = '';
  String _authtoken = '';
  bool? _phoneprivacy;
  List _followinglist = [];
  List _followerslist = [];
  List _blockedUsers = [];

  // Verify number
  static Future<int> verifyNumber({required String phonenumber}) async {
    try {
      String url = "${Domain.url}/client/auth/login/sendotp";
      Map data = {
        "phone": "91$phonenumber",
      };
      var response = await http.post(Uri.parse(url), body: data);
      var jsonData = json.decode(response.body);
      // print("Send OTP response: $jsonData");
      return jsonData['status'];
    } on HttpException catch (e) {
      print('Verify number http exception: $e');
      return 400;
    }
  }

  // Verify OTP
  static Future<dynamic> verifyOTP({
    required String otp,
    required String phonenumber,
    required String fcmToken,
  }) async {
    try {
      String url = "${Domain.url}/client/auth/login/app/verifyotp";
      Map data = {
        "phone": "91$phonenumber",
        "otp": otp,
        "fcm": fcmToken,
      };
      var response = await http.post(Uri.parse(url), body: data);
      var jsonData = json.decode(response.body);
      // print("Verify OTP response: $jsonData");
      return jsonData;
    } on HttpException catch (e) {
      print('Verify OTP http exception: $e');
      return 400;
    }
  }

  // Create new user
  static Future<dynamic> createUser({
    required String authtoken,
    required String name,
    required String gender,
    required String dob,
    required String userName,
    required String email,
    required String privacy,
  }) async {
    try {
      String url = '${Domain.url}/client/profile/AddProfile';
      Map<String, String> data = {
        "name": name,
        "gender": gender,
        "dob": dob,
        "user_name": userName.toLowerCase(),
        "email": email.toLowerCase(),
        "privacy[phone]": privacy,
      };
      var response = await http.post(Uri.parse(url),
          body: data, headers: {'authorization': 'Bearer ' + authtoken});
      var jsonData = json.decode(response.body);
      // print("Create user response: $jsonData");
      return jsonData;
    } on HttpException catch (e) {
      print('Create user http exception: $e');
      return 400;
    }
  }

  // Upload user image
  static Future<dynamic> setPicture({
    required String authtoken,
    required File image,
  }) async {
    try {
      String url = '${Domain.url}/client/profile/avatar';

      //create multipart request for POST or PATCH method
      var request = http.MultipartRequest("POST", Uri.parse(url));

      //create multipart using filepath, string or bytes
      var pic = await http.MultipartFile.fromPath("avatar", image.path);

      //Header
      Map<String, String> head = {'authorization': 'Bearer ' + authtoken};

      // var request = http.MultipartRequest(url, head);

      //Adding headers to request
      request.headers.addAll(head);

      //add files to request
      request.files.add(pic);

      //Send request
      var response = await request.send();

      //Get the response from the server
      var responseData = await response.stream.toBytes();
      var responseImage = String.fromCharCodes(responseData);
      var jsonData = json.decode(responseImage);
      // print('Image upload response: $jsonData');
      return jsonData;
    } on HttpException catch (e) {
      print('Set picture http exception: $e');
      return 400;
    }
  }

  // Get user data
  Future<dynamic> getUserData({
    required String authtoken,
  }) async {
    try {
      String url = "${Domain.url}/client/profile/getMyProfile";
      var response = await http.get(Uri.parse(url),
          headers: {'authorization': 'Bearer ' + authtoken});
      var jsonData = json.decode(response.body);
      // print("User Data response: $jsonData");
      if (jsonData["status"] == 200) {
        Map<String, dynamic> _response = jsonData["response"];
        Map<String, dynamic> _data = _response["data"];
        Map<String, dynamic> _info = _data["info"];
        var data = _info["profile"];
        _fullname = data["name"] ?? '';
        _username = data["user_name"] ?? '';
        _email = data["email"] ?? '';
        _gender = data["gender"] ?? '';
        _phone = data["phone"] ?? '';
        _avatar = data["avatar"] ?? '';
        _dob = data["dob"] ?? '';
        _userId = data["userId"] ?? '';
        _phoneprivacy = data["privacy"]["phone"];
      }
      _authtoken = authtoken;
      notifyListeners();
      return jsonData;
    } on HttpException catch (e) {
      print('Get my profile http exception: $e');
      return 400;
    }
  }

  // Update users
  static Future<dynamic> updateUser({
    required String authtoken,
    required String name,
    required String gender,
    required String dob,
    required String userName,
    required String email,
    required String privacy,
  }) async {
    try {
      String url = '${Domain.url}/client/profile/updateProfile';
      Map<String, String> data = {
        "name": name,
        "gender": gender,
        "dob": dob,
        "user_name": userName.toLowerCase(),
        "email": email.toLowerCase(),
        "privacy[phone]": privacy,
      };
      var response = await http.put(Uri.parse(url),
          body: data, headers: {'authorization': 'Bearer ' + authtoken});
      var jsonData = json.decode(response.body);
      // print("Update user response: $jsonData");
      return jsonData;
    } on HttpException catch (e) {
      print('Update my profile http exception: $e');
      return 400;
    }
  }

  // Following information
  Future following({
    required String authtoken,
    required String? userprofilename,
  }) async {
    try {
      String url = '${Domain.url}/client/profile/followingOrFollwers';
      Map<String, String> data = {
        "user_name": userprofilename!,
        "list_profiles": "Following",
      };
      var response = await http.post(Uri.parse(url),
          body: data, headers: {'authorization': 'Bearer ' + authtoken});
      var jsonData = json.decode(response.body);
      // print("Following list response: $jsonData");
      if (jsonData["status"] == 200) {
        Map<String, dynamic> _response = jsonData["response"];
        Map<String, dynamic> _data = _response["data"];
        Map<String, dynamic> _info = _data["info"];
        _followinglist = _info["user_profile"];
      }
      notifyListeners();
      return jsonData;
    } on HttpException catch (e) {
      print('Following list http exception: $e');
      return 400;
    }
  }

  // Followers information
  Future followers({
    required String authtoken,
    required String? userprofilename,
  }) async {
    try {
      String url = '${Domain.url}/client/profile/followingOrFollwers';
      Map<String, String> data = {
        "user_name": userprofilename!,
        "list_profiles": "Followers",
      };
      var response = await http.post(Uri.parse(url),
          body: data, headers: {'authorization': 'Bearer ' + authtoken});
      var jsonData = json.decode(response.body);
      // print("Following list response: $jsonData");
      if (jsonData["status"] == 200) {
        Map<String, dynamic> _response = jsonData["response"];
        Map<String, dynamic> _data = _response["data"];
        Map<String, dynamic> _info = _data["info"];
        _followerslist = _info["user_profile"];
      }
      notifyListeners();
      return jsonData;
    } on HttpException catch (e) {
      print('Following list http exception: $e');
      return 400;
    }
  }

  // Unfollow users
  static Future unfollow({
    required String authtoken,
    required String? userprofilename,
  }) async {
    try {
      String url = '${Domain.url}/client/profile/follow-user';
      Map<String, String> data = {
        "user_name": userprofilename!,
        "follow_status": "UnFollow",
      };
      var response = await http.post(Uri.parse(url),
          body: data, headers: {'authorization': 'Bearer ' + authtoken});
      var jsonData = json.decode(response.body);
      // print("Unfollow response: $jsonData");
      // if (jsonData["status"] == 200) {
      //   _followerslist = jsonData["response"]["data"]["info"]["user_profile"];
      // }
      return jsonData;
    } on HttpException catch (e) {
      print('Unfollow http exception: $e');
      return 400;
    }
  }

  // Logout
  static Future logout(
      {required String fcmToken, required String authtoken}) async {
    try {
      String url = '${Domain.url}/client/auth/logout/app';
      Map<String, String> data = {"fcm": fcmToken};
      var response = await http.put(Uri.parse(url),
          body: data, headers: {'authorization': 'Bearer ' + authtoken});
      var jsonData = json.decode(response.body);
      // print("Logout response: $jsonData");
      return jsonData;
    } on HttpException catch (e) {
      print('Logout exceptio: $e');
    }
  }

  // Get Blocked Users
  Future<dynamic> blockedUsers({required String authtoken}) async {
    try {
      String url = '${Domain.url}/client/profile/blocked_users';
      var response = await http.get(Uri.parse(url),
          headers: {'authorization': 'Bearer ' + authtoken});
      var jsonData = json.decode(response.body);
      // print("Blocked users response: $jsonData");
      if (jsonData["status"] == 200) {
        Map<String, dynamic> _response = jsonData["response"];
        Map<String, dynamic> _data = _response["data"];
        Map<String, dynamic> _info = _data["info"];
        _blockedUsers = _info["blocked_users"];
      }
      notifyListeners();
      return jsonData;
    } on HttpException catch (e) {
      print('Blocked users exception: $e');
    }
  }

  // Unblock users
  static Future<dynamic> unblockUsers({
    required String authtoken,
    required String userName,
  }) async {
    try {
      String url = '${Domain.url}/client/profile/blockOrUnblock';
      Map<String, String> body = {
        "user_name": userName,
        "block_status": "UnBlock"
      };
      var response = await http.post(Uri.parse(url),
          body: body, headers: {'authorization': 'Bearer ' + authtoken});
      var jsonData = json.decode(response.body);
      // print("Unblock users response: $jsonData");
      return jsonData;
    } on HttpException catch (e) {
      print('Unblock users exception: $e');
    }
  }

  String get fullname => _fullname;
  String get username => _username;
  String get email => _email;
  String get gender => _gender;
  String get phone => _phone;
  String get avatar => _avatar;
  String get dob => _dob;
  String get userId => _userId;
  String get authtoken => _authtoken;
  bool? get phoneprivacy => _phoneprivacy;
  List get followinglist => _followinglist;
  List get followerslist => _followerslist;
  List get blockedUsersList => _blockedUsers;
}
