import 'dart:convert';
import 'dart:io';
import 'package:http/http.dart' as http;
import 'package:flutter/material.dart';
import 'package:india/Services/domain.dart';

class Wishlist with ChangeNotifier {
  Map<String, dynamic> _products = {};

  Future<String?> addWishslist({
    required String productid,
    required String authtoken,
  }) async {
    String? message;
    try {
      String url = "${Domain.url}/client/wishlist/add/$productid";
      Map<String, String> head = {'authorization': 'Bearer ' + authtoken};
      var response = await http.post(Uri.parse(url), headers: head);
      Map jsonData = await json.decode(response.body);
      // print("Add Wishlist response: $jsonData");
      if (jsonData["status"] == 200) {
        Map<String, dynamic> _response = jsonData["response"];
        Map<String, dynamic> _data = _response["data"];
        Map<String, dynamic> _info = _data["info"];
        message = _info["message"];
      }
      return message;
    } on HttpException catch (e) {
      print('Add Wishist exception: $e');
      return "Kindly try again later";
    }
  }

  Future<String?> removeWishslist({
    required String productid,
    required String authtoken,
  }) async {
    String? message;
    try {
      String url = "${Domain.url}/client/wishlist/remove/$productid";
      Map<String, String> head = {'authorization': 'Bearer ' + authtoken};
      var response = await http.delete(Uri.parse(url), headers: head);
      Map jsonData = await json.decode(response.body);
      // print("Remove Wishlist response: $jsonData");
      if (jsonData["status"] == 200) {
        Map<String, dynamic> _response = jsonData["response"];
        Map<String, dynamic> _data = _response["data"];
        Map<String, dynamic> _info = _data["info"];
        message = _info["message"];
      }
      return message;
    } on HttpException catch (e) {
      print('Remove Wishist exception: $e');
      return "Kindly try again later";
    }
  }

  Future<dynamic> getWishslist({required String authtoken}) async {
    try {
      String url = "${Domain.url}/client/wishlist/get";
      Map<String, String> head = {'authorization': 'Bearer ' + authtoken};
      var response = await http.get(Uri.parse(url), headers: head);
      Map jsonData = await json.decode(response.body);
      // print("Get Wishlist response: $jsonData");
      if (jsonData["status"] == 200) {
        Map<String, dynamic> _response = jsonData["response"];
        Map<String, dynamic> _data = _response["data"];
        Map<String, dynamic> _info = _data["info"];
        _products = _info["wishlist"];
      }
      notifyListeners();
      return jsonData;
    } on HttpException catch (e) {
      print('Get Wishist exception: $e');
      return "Kindly try again later";
    }
  }

  Map<String, dynamic> get wishlistproducts => _products;
}
