     // Flexible(
                              //   flex: 1,
                              //   fit: FlexFit.loose,
                              //   child:
                              // ),


// Container(
//                             height: 200,
//                             child: FloatingSearchBar(
//                               backdropColor: Color(0xFFF9F9F9),
//                               openAxisAlignment: 0,
//                               axisAlignment: 0,
//                               scrollPadding:
//                                   EdgeInsets.only(top: 8, bottom: 20),
//                               elevation: 1,
//                               hint: "Search...",
//                               onQueryChanged: (querry) {
//                                 print("Querry: $querry");
//                               },
//                               width: MediaQuery.of(context).size.width / 1.1,
//                               transitionCurve: Curves.easeInOut,
//                               transitionDuration: Duration(milliseconds: 300),
//                               debounceDelay: Duration(milliseconds: 300),
//                               actions: [
//                                 FloatingSearchBarAction(
//                                   showIfOpened: false,
//                                   child: CircularButton(
//                                     icon: Icon(Icons.search),
//                                     onPressed: () {},
//                                   ),
//                                 ),
//                                 FloatingSearchBarAction.searchToClear(
//                                   showIfClosed: false,
//                                 ),
//                               ],
//                               builder: (context, transition) {
//                                 return Container(
//                                   height: 300,
//                                   color: Colors.black,
//                                 );

//                                 // Material(
//                                 //   color: Colors.white,
//                                 //   child: Container(
//                                 //       // height: 400,
//                                 //       // color: Colors.white,
//                                 //       // child: Column(
//                                 //       //   children: [
//                                 //       //     ListTile(title: Text("Home")),
//                                 //       //     ListTile(title: Text("Home")),
//                                 //       //   ],
//                                 //       // ),
//                                 //       ),
//                                 // );
//                               },
//                             ),
//                           ),