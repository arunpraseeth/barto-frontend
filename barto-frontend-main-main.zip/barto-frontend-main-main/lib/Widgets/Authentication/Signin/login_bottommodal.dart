import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:india/Common/color.dart';
import 'package:india/Common/custom_Textfield.dart';
import 'package:india/Common/custom_navigator.dart';
import 'package:india/Common/loading_bool.dart';
import 'package:india/Common/loading_widget.dart';
import 'package:india/Common/showalert_dialog.dart';
import 'package:india/Services/user_data.dart';
import 'package:india/Widgets/Authentication/Signin/otp_verification.dart';
import 'package:provider/provider.dart';
import 'package:url_launcher/url_launcher.dart';

class LoginModalSheet {
  final _key = GlobalKey<FormState>();
  TextEditingController numberController = TextEditingController();
  FocusNode focusNode = FocusNode();

  bottomModalSheet({required BuildContext context}) {
    Size size = MediaQuery.of(context).size;
    return showModalBottomSheet(
      isScrollControlled: true,
      backgroundColor: Colors.white,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(
          top: Radius.circular(20),
        ),
      ),
      context: context,
      builder: (context) {
        return StatefulBuilder(
          builder: (buildercontext, builderState) {
            return Provider.of<BoolLoader>(context).loadingStatus
                ? LoadingWidget()
                : Padding(
                    padding: MediaQuery.of(context).viewInsets,
                    child: SingleChildScrollView(
                      child: Container(
                        height: size.height / 1.1,
                        decoration: BoxDecoration(
                          borderRadius: BorderRadius.vertical(
                            top: Radius.circular(20),
                          ),
                          gradient: LinearGradient(
                            colors: [
                              const Color(0xFF30BFFD),
                              const Color(0xFFc2e7f8),
                            ],
                            begin: const FractionalOffset(0.0, .0),
                            end: const FractionalOffset(0.0, 1.0),
                          ),
                        ),
                        child: Stack(
                          children: [
                            Padding(
                              padding: const EdgeInsets.all(8.0),
                              child: Align(
                                alignment: Alignment.topLeft,
                                child: IconButton(
                                  onPressed: () {
                                    Navigator.pop(context);
                                  },
                                  icon: Icon(
                                    Icons.close,
                                    size: 30,
                                  ),
                                ),
                              ),
                            ),
                            Center(
                              child: GestureDetector(
                                onTap: () {
                                  focusNode.unfocus();
                                },
                                child: Container(
                                  margin: EdgeInsets.symmetric(horizontal: 20),
                                  child: Container(
                                    // width: size.width / 1.3,
                                    height: size.height / 1.6,
                                    decoration: BoxDecoration(
                                      borderRadius: BorderRadius.circular(10),
                                      color: Colors.white,
                                      boxShadow: [
                                        BoxShadow(
                                          color: Colors.grey.withOpacity(0.3),
                                          spreadRadius: 0.7,
                                          blurRadius: 2,
                                          offset: Offset(0,
                                              0), // changes position of shadow
                                        ),
                                      ],
                                    ),
                                    child: Column(
                                      children: [
                                        SizedBox(height: size.height * 0.06),
                                        SvgPicture.asset(
                                          'assets/logo/logo.svg',
                                          height: size.height / 7,
                                        ),
                                        SizedBox(height: size.height * 0.04),
                                        Text(
                                          'Enter your phone number',
                                          style: TextStyle(
                                              fontSize: 20,
                                              fontWeight: FontWeight.w700),
                                        ),
                                        SizedBox(height: size.height * 0.04),
                                        Form(
                                          key: _key,
                                          child: Padding(
                                            padding: const EdgeInsets.symmetric(
                                                horizontal: 30),
                                            child:
                                                CustomTextField.customTextField(
                                              focusnode: focusNode,
                                              controller: numberController,
                                              maxLength: 10,
                                              textInputType:
                                                  TextInputType.number,
                                              textSpacing: 3,
                                              validator: (value) {
                                                if (value!.length < 10) {
                                                  return 'Kindly enter a valid mobile number';
                                                }
                                              },
                                              prefix: Padding(
                                                padding: const EdgeInsets.only(
                                                    top: 11.5, left: 20),
                                                child: Text(
                                                  '+91 ',
                                                  style: TextStyle(
                                                    color: colorBlue,
                                                    fontSize: 20,
                                                    fontWeight: FontWeight.bold,
                                                  ),
                                                ),
                                              ),
                                            ),
                                          ),
                                        ),
                                        SizedBox(height: size.height * 0.04),
                                        RoundedCustomNavigatorButton
                                            .customContainer(
                                          boxName: 'Send OTP',
                                          context: context,
                                          onTap: () {
                                            if (_key.currentState!.validate()) {
                                              Provider.of<BoolLoader>(context,
                                                      listen: false)
                                                  .boolLoader(status: true);
                                              UserData.verifyNumber(
                                                      phonenumber:
                                                          numberController.text)
                                                  .then((value) {
                                                Provider.of<BoolLoader>(context,
                                                        listen: false)
                                                    .boolLoader(status: false);
                                                if (value == 200) {
                                                  Navigator.push(
                                                    context,
                                                    MaterialPageRoute(
                                                      builder: (_) =>
                                                          OtpVerification(
                                                        phoneNumber:
                                                            numberController
                                                                .text,
                                                      ),
                                                    ),
                                                  );
                                                } else {
                                                  ShowAlert.showAlertDialog(
                                                      context,
                                                      exception:
                                                          "Kindly try again later");
                                                  Future.delayed(
                                                      Duration(seconds: 1), () {
                                                    Navigator.pop(context);
                                                  });
                                                }
                                              });
                                            }
                                          },
                                        ),
                                        SizedBox(height: size.height * 0.025),
                                        Row(
                                          mainAxisAlignment:
                                              MainAxisAlignment.center,
                                          children: [
                                            Text(
                                              'I agree the',
                                              style: TextStyle(
                                                fontSize: 12,
                                                color: Colors.black,
                                              ),
                                            ),
                                            InkWell(
                                              onTap: () {
                                                launchUrl();
                                              },
                                              child: Text(
                                                ' Terms & Conditions',
                                                style: TextStyle(
                                                  fontSize: 12,
                                                  color: colorBlue,
                                                  fontWeight: FontWeight.w500,
                                                ),
                                              ),
                                            ),
                                          ],
                                        ),
                                        SizedBox(height: size.height * 0.06),
                                      ],
                                    ),
                                  ),
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                  );
          },
        );
      },
    );
  }

  void launchUrl() async {
    const url = "https://bartoindia.com/Termsandconditions";
    if (await canLaunch(url))
      await launch(url);
    else
      throw "Could not launch $url";
  }
}
