import 'dart:async';
import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:india/Common/color.dart';
import 'package:india/Common/custom_Textfield.dart';
import 'package:india/Common/custom_navigator.dart';
import 'package:india/Common/loading_widget.dart';
import 'package:india/Common/showalert_dialog.dart';
import 'package:india/Model/location.dart';
import 'package:india/Model/shared_pref.dart';
import 'package:india/Services/chat_firestore.dart';
import 'package:india/Services/fcm_token.dart';
import 'package:india/Services/get_home.dart';
import 'package:india/Services/my_postapi.dart';
import 'package:india/Services/sell_form.dart';
import 'package:india/Services/user_data.dart';
import 'package:india/Widgets/Authentication/Signup/create_user.dart';
import 'package:india/Widgets/Screens/bottom_navbar.dart';
import 'package:provider/provider.dart';
import 'package:shared_preferences/shared_preferences.dart';

// ignore: must_be_immutable
class OtpVerification extends StatefulWidget {
  String? phoneNumber;

  OtpVerification({this.phoneNumber});

  @override
  State<OtpVerification> createState() => _OtpVerificationState();
}

class _OtpVerificationState extends State<OtpVerification> {
  final _key = GlobalKey<FormState>();
  TextEditingController numberController = TextEditingController();
  TextEditingController otpController = TextEditingController();
  bool _loading = false;
  String? fcmToken;
  String? countryId;
  String? stateId;
  String? cityId;
  String? areaId;
  String? areaname;
  bool onpressed = false;
  String? countDown;
  int timercount = 10;
  bool otpTimer = false;

  getfcmtoken() async {
    fcmToken = await FcmToken.getToken();
  }

  @override
  void initState() {
    getfcmtoken();
    GetStoredInfo.getStoreInfo();
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    Size size = MediaQuery.of(context).size;
    numberController.text = this.widget.phoneNumber ?? '';
    String latitude = Provider.of<StoreLocation>(context).latitude.toString();
    String longitude = Provider.of<StoreLocation>(context).longitude.toString();
    return Scaffold(
      body: _loading
          ? LoadingWidget()
          : Container(
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  colors: [
                    const Color(0xFF30BFFD),
                    const Color(0xFFc2e7f8),
                  ],
                  begin: const FractionalOffset(0.0, .0),
                  end: const FractionalOffset(0.0, 1.0),
                ),
              ),
              child: Center(
                child: Container(
                  margin: EdgeInsets.symmetric(horizontal: 20),
                  child: Container(
                    // width: size.width / 1.3,
                    // height: size.height / 1.6,
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(10),
                      color: Colors.white,
                      boxShadow: [
                        BoxShadow(
                          color: Colors.grey.withOpacity(0.3),
                          spreadRadius: 0.7,
                          blurRadius: 2,
                          offset: Offset(0, 0), // changes position of shadow
                        ),
                      ],
                    ),
                    child: SingleChildScrollView(
                      child: Column(
                        children: [
                          SizedBox(height: size.height * 0.06),
                          SvgPicture.asset(
                            'assets/logo/logo.svg',
                            height: size.height / 7,
                          ),
                          SizedBox(height: size.height * 0.04),
                          Text(
                            'Enter your phone number',
                            style: TextStyle(
                                fontSize: 20, fontWeight: FontWeight.w700),
                          ),
                          SizedBox(height: size.height * 0.04),
                          Padding(
                            padding: const EdgeInsets.symmetric(horizontal: 30),
                            child: CustomTextField.customTextField(
                              readOnly: true,
                              controller: numberController,
                              maxLength: 10,
                              textInputType: TextInputType.number,
                              textSpacing: 3,
                              validator: (value) {
                                if (value!.length < 10) {
                                  return 'Kindly enter a valid mobile number';
                                }
                              },
                              prefix: Padding(
                                padding:
                                    const EdgeInsets.only(top: 11.5, left: 20),
                                child: Text(
                                  '+91 ',
                                  style: TextStyle(
                                    color: colorBlue,
                                    fontSize: 20,
                                    fontWeight: FontWeight.bold,
                                  ),
                                ),
                              ),
                            ),
                          ),
                          SizedBox(height: size.height * 0.02),
                          Padding(
                            padding: const EdgeInsets.symmetric(horizontal: 30),
                            child: Form(
                              key: _key,
                              child: CustomTextField.customTextField(
                                controller: otpController,
                                maxLength: 4,
                                textInputType: TextInputType.number,
                                textSpacing: 3,
                                hintText: 'Enter OTP',
                                validator: (value) {
                                  if (value!.length < 4) {
                                    return 'Kindly enter a valid OTP';
                                  }
                                },
                                suffix: otpTimer
                                    ? Padding(
                                        padding: const EdgeInsets.only(
                                            right: 8, top: 15),
                                        child: Text(
                                          "Expires in $timercount",
                                          style: TextStyle(
                                            fontSize: 16.0,
                                            fontWeight: FontWeight.bold,
                                            color: colorBlue,
                                          ),
                                        ),
                                      )
                                    : TextButton(
                                        onPressed: () {
                                          setState(() {
                                            otpTimer = true;
                                            UserData.verifyNumber(
                                                phonenumber:
                                                    numberController.text);
                                          });
                                          Timer.periodic(Duration(seconds: 1),
                                              (timer) {
                                            if (timercount != 0) {
                                              setState(() {
                                                timercount--;
                                              });
                                            } else if (timercount == 0) {
                                              timer.cancel();
                                              setState(() {
                                                timercount = 10;
                                                otpTimer = false;
                                              });
                                            }
                                          });
                                        },
                                        child: Text(
                                          "Resend",
                                          style: TextStyle(
                                            fontSize: 16.0,
                                            fontWeight: FontWeight.bold,
                                          ),
                                        ),
                                      ),
                              ),
                            ),
                          ),
                          SizedBox(height: size.height * 0.04),
                          RoundedCustomNavigatorButton.customContainer(
                            boxName: 'Verify',
                            context: context,
                            onTap: () {
                              if (_key.currentState!.validate()) {
                                setState(() {
                                  _loading = true;
                                });
                                UserData.verifyOTP(
                                  phonenumber: numberController.text,
                                  otp: otpController.text,
                                  fcmToken: fcmToken!,
                                ).then((value) async {
                                  setState(() {
                                    _loading = false;
                                  });
                                  int _status = value["status"];
                                  if (_status == 200) {
                                    Map<String, dynamic> _response =
                                        value["response"];
                                    Map<String, dynamic> _data =
                                        _response["data"];
                                    Map<String, dynamic> _info = _data["info"];
                                    if (_info.containsKey("message")) {
                                      String _message = _info["message"];
                                      ShowAlert.showAlertDialog(context,
                                          exception: _message);
                                    } else {
                                      Map<String, dynamic> _profile =
                                          _info["profile"];
                                      String _userstatus =
                                          _profile["user_status"];
                                      if (_userstatus == "Active") {
                                        Provider.of<SellForm>(this.context,
                                                listen: false)
                                            .getCategory();
                                        Map<String, dynamic> _accessToken =
                                            _info["access_token"];
                                        String authToken =
                                            _accessToken["token"];
                                        SharedPreferences sharedPreferences =
                                            await SharedPreferences
                                                .getInstance();
                                        sharedPreferences.setString(
                                            "phonenumber",
                                            numberController.text);
                                        sharedPreferences.setString(
                                            "authtoken", authToken);
                                        Provider.of<MyPostApi>(this.context,
                                                listen: false)
                                            .nonpaid(authtoken: authToken);
                                        Provider.of<MyPostApi>(this.context,
                                                listen: false)
                                            .paid(authtoken: authToken);
                                        filterbasedonLocation(
                                          authToken: authToken,
                                          latitude: latitude,
                                          longitude: longitude,
                                        );
                                        Provider.of<UserData>(this.context,
                                                listen: false)
                                            .getUserData(authtoken: authToken)
                                            .then((userDatavalue) {
                                          if (userDatavalue["status"] == 200) {
                                            Map<String, dynamic> _userResponse =
                                                userDatavalue["response"];
                                            Map<String, dynamic> _userData =
                                                _userResponse["data"];
                                            Map<String, dynamic> _userInfo =
                                                _userData["info"];
                                            Map<String, dynamic> _userProfile =
                                                _userInfo["profile"];
                                            String _userId =
                                                _userProfile["userId"];
                                            Provider.of<ChatFirestore>(
                                                    this.context,
                                                    listen: false)
                                                .getChatList(
                                              userId: _userId,
                                            );
                                            Navigator.pushAndRemoveUntil(
                                              this.context,
                                              MaterialPageRoute(
                                                builder: (_) =>
                                                    CustomBottomNavBar(
                                                  chooseIndex: 0,
                                                ),
                                              ),
                                              (route) => false,
                                            );
                                          }
                                        });
                                      } else if (_userstatus ==
                                          "UnRegistered") {
                                        Map<String, dynamic> _accessToken =
                                            _info["access_token"];
                                        String authToken =
                                            _accessToken["token"];
                                        Navigator.pushAndRemoveUntil(
                                          this.context,
                                          MaterialPageRoute(
                                            builder: (_) => CreateUser(
                                              sourcepage: 1,
                                              authtoken: authToken,
                                            ),
                                          ),
                                          (route) => false,
                                        );
                                      }
                                    }
                                  } else if (_status == 500) {
                                    Map<String, dynamic> _error =
                                        value["error"];
                                    String _message = _error["message"];
                                    ShowAlert.showAlertDialog(context,
                                        exception: _message);
                                  }
                                });
                              }
                            },
                          ),
                          SizedBox(height: size.height * 0.06),
                        ],
                      ),
                    ),
                  ),
                ),
              ),
            ),
    );
  }

  filterbasedonLocation({
    required String authToken,
    required String latitude,
    required String longitude,
  }) {
    Provider.of<GetHome>(this.context, listen: false).getProducts(
      authtoken: authToken,
      refresh: true,
      lat: latitude == "0.0" ? GetStoredInfo.latitude : latitude,
      long: longitude == "0.0" ? GetStoredInfo.longitude : longitude,
    );
  }
}
