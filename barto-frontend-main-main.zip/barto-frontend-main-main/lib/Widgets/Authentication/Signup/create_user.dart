import 'dart:io';
import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_svg/svg.dart';
import 'package:image_cropper/image_cropper.dart';
import 'package:image_picker/image_picker.dart';
import 'package:india/Common/color.dart';
import 'package:india/Common/custom_Textfield.dart';
import 'package:india/Common/custom_navigator.dart';
import 'package:india/Common/loading_widget.dart';
import 'package:india/Common/show_toast.dart';
import 'package:india/Services/domain.dart';
import 'package:india/Services/sell_form.dart';
import 'package:india/Services/user_data.dart';
import 'package:india/Widgets/Screens/bottom_navbar.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:provider/provider.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:intl/intl.dart';

// ignore: must_be_immutable
class CreateUser extends StatefulWidget {
  String? authtoken;
  String? fullname;
  String? username;
  String? email;
  String? dob;
  String? gender;
  bool? privacy;
  int? sourcepage;
  CreateUser({
    required this.authtoken,
    this.fullname,
    this.username,
    this.email,
    this.dob,
    this.gender,
    this.privacy,
    required this.sourcepage,
  });

  @override
  _CreateUserState createState() => _CreateUserState();
}

class _CreateUserState extends State<CreateUser> {
  final _key = GlobalKey<FormState>();
  TextEditingController nameController = TextEditingController();
  TextEditingController userNameController = TextEditingController();
  TextEditingController emailController = TextEditingController();
  String? dateOfBirth;
  String selectedGender = '';
  bool loading = false;
  File? croppedFile;
  ImagePicker _picker = ImagePicker();
  File? _image;
  PickedFile? image;
  String? fcmToken;
  bool privacy = false;
  String? phoneprivacy;
  bool _loading = false;
  DateTime? pickedDate;
  int? age = 0;
  convertDate() {
    DateTime tempDate = new DateFormat("dd-MM-yyyy").parse(widget.dob!);
    age = DateTime.now().year - tempDate.year;
  }

  @override
  void initState() {
    // FcmToken.getToken();
    nameController.text = widget.fullname ?? '';
    userNameController.text = widget.username ?? '';
    emailController.text = widget.email ?? '';
    dateOfBirth = widget.dob;
    selectedGender = widget.gender ?? '';
    privacy = widget.privacy ?? false;
    // ignore: unnecessary_statements
    widget.sourcepage == 2 ? convertDate() : null;
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    Size size = MediaQuery.of(context).size;
    return Scaffold(
      backgroundColor: Colors.white,
      body: _loading
          ? LoadingWidget()
          : SafeArea(
              child: Container(
                child: SingleChildScrollView(
                  child: Stack(
                    children: [
                      Form(
                        key: _key,
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          mainAxisSize: MainAxisSize.max,
                          children: [
                            SizedBox(height: size.height * 0.08),
                            Center(
                              child: Text(
                                'Enter your details',
                                style: TextStyle(
                                  fontSize: size.height * 0.03,
                                  color: Colors.black,
                                  fontWeight: FontWeight.bold,
                                ),
                              ),
                            ),
                            SizedBox(height: size.height * 0.02),
                            Center(
                              child: GestureDetector(
                                onTap: () {
                                  showImageSource(context);
                                },
                                child: Stack(
                                  children: [
                                    CircleAvatar(
                                      backgroundColor: Colors.grey[200],
                                      radius: 65,
                                      child: ClipOval(
                                        child: AspectRatio(
                                          aspectRatio: 1 / 1,
                                          child: widget.sourcepage == 1
                                              ? SizedBox(
                                                  child: (_image != null)
                                                      ? Image.file(_image!,
                                                          fit: BoxFit.cover)
                                                      : Icon(
                                                          Icons.person,
                                                          color: Colors.white,
                                                          size: 100,
                                                        ),
                                                )
                                              : SizedBox(
                                                  child: (_image != null)
                                                      ? Image.file(
                                                          _image!,
                                                          fit: BoxFit.cover,
                                                        )
                                                      : Padding(
                                                          padding:
                                                              const EdgeInsets
                                                                  .all(15.0),
                                                          child:
                                                              CachedNetworkImage(
                                                            fit: BoxFit.cover,
                                                            imageUrl:
                                                                "${Domain.url}${Provider.of<UserData>(context).avatar}",
                                                            placeholder: (context,
                                                                    url) =>
                                                                new CircularProgressIndicator(),
                                                            errorWidget: (context,
                                                                    url,
                                                                    error) =>
                                                                new Icon(Icons
                                                                    .error),
                                                          ),
                                                        ),
                                                ),
                                        ),
                                      ),
                                    ),
                                    Positioned(
                                      bottom: 10,
                                      right: 5,
                                      child: Container(
                                        width: 26,
                                        height: 26,
                                        decoration: BoxDecoration(
                                          color: Colors.white,
                                          shape: BoxShape.circle,
                                        ),
                                        child: Icon(
                                          Icons.camera_alt,
                                          size: 20,
                                          color: Colors.black,
                                        ),
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                            ),
                            SizedBox(height: size.height * 0.03),
                            Padding(
                              padding:
                                  const EdgeInsets.symmetric(horizontal: 30),
                              child: CustomTextField.customTextField(
                                controller: nameController,
                                textInputType: TextInputType.name,
                                hintText: 'Full Name',
                                validator: (value) {
                                  if (value!.length < 3) {
                                    return 'Kindly enter a valid name';
                                  }
                                },
                              ),
                            ),
                            SizedBox(height: size.height * 0.02),
                            Padding(
                              padding:
                                  const EdgeInsets.symmetric(horizontal: 30),
                              child: CustomTextField.customTextField(
                                readOnly: widget.sourcepage == 1 ? false : true,
                                controller: userNameController,
                                textInputType: TextInputType.name,
                                hintText: 'Username',
                                validator: (value) {
                                  if (value!.length < 3) {
                                    return 'Kindly enter a valid username';
                                  }
                                },
                              ),
                            ),
                            SizedBox(height: size.height * 0.02),
                            Padding(
                              padding:
                                  const EdgeInsets.symmetric(horizontal: 30),
                              child: CustomTextField.customTextField(
                                controller: emailController,
                                textInputType: TextInputType.emailAddress,
                                hintText: 'Email',
                                validator: (value) {
                                  if (!RegExp(
                                          r"^[a-zA-Z0-9.a-zA-Z0-9.!#$%&'*+-/=?^_`{|}~]+@[a-zA-Z0-9]+\.[a-zA-Z]+")
                                      .hasMatch(emailController.text)) {
                                    return 'Kindly enter a valid email';
                                  }
                                },
                              ),
                            ),
                            SizedBox(height: size.height * 0.02),
                            customContainer(
                              context,
                              child: Padding(
                                padding:
                                    const EdgeInsets.only(left: 15, top: 14),
                                child: Text(
                                  '${(dateOfBirth.runtimeType == Null || dateOfBirth!.isEmpty) ? 'Date of Birth' : dateOfBirth}',
                                  style: dateOfBirth.runtimeType == Null
                                      ? TextStyle(
                                          fontSize: 20,
                                          fontWeight: FontWeight.w600,
                                          color: Colors.grey[700],
                                        )
                                      : TextStyle(
                                          fontSize: 20,
                                          color: Colors.black,
                                          fontWeight: FontWeight.w500,
                                        ),
                                ),
                              ),
                              onTap: () {
                                _selectDate();
                              },
                            ),
                            SizedBox(height: size.height * 0.02),
                            Padding(
                              padding:
                                  const EdgeInsets.symmetric(horizontal: 30),
                              child: Text(
                                'Gender:',
                                style: TextStyle(
                                  fontSize: 20,
                                  color: Colors.black,
                                  fontWeight: FontWeight.w500,
                                ),
                              ),
                            ),
                            SizedBox(height: size.height * 0.02),
                            Row(
                              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                              children: [
                                GestureDetector(
                                  onTap: () {
                                    setState(() {
                                      selectedGender = 'Male';
                                    });
                                  },
                                  child: Column(
                                    mainAxisAlignment: MainAxisAlignment.center,
                                    children: [
                                      Container(
                                        width: 40,
                                        height: 40,
                                        color: Colors.transparent,
                                        child: SvgPicture.asset(
                                          'assets/sex/male.svg',
                                          color: selectedGender == 'Male'
                                              ? colorBlue
                                              : Colors.black,
                                        ),
                                      ),
                                      SizedBox(height: 10),
                                      Text('Male'),
                                    ],
                                  ),
                                ),
                                InkWell(
                                  onTap: () {
                                    setState(() {
                                      selectedGender = 'Female';
                                    });
                                  },
                                  child: Column(
                                    mainAxisAlignment: MainAxisAlignment.center,
                                    children: [
                                      Container(
                                        width: 40,
                                        height: 40,
                                        color: Colors.transparent,
                                        child: SvgPicture.asset(
                                          'assets/sex/female.svg',
                                          color: selectedGender == 'Female'
                                              ? colorBlue
                                              : Colors.black,
                                        ),
                                      ),
                                      SizedBox(height: 10),
                                      Text('Female'),
                                    ],
                                  ),
                                ),
                                InkWell(
                                  onTap: () {
                                    setState(() {
                                      selectedGender = 'Transgender';
                                    });
                                  },
                                  child: Column(
                                    mainAxisAlignment: MainAxisAlignment.center,
                                    children: [
                                      Container(
                                        width: 40,
                                        height: 40,
                                        color: Colors.transparent,
                                        child: SvgPicture.asset(
                                          'assets/sex/transgender.svg',
                                          color: selectedGender == 'Transgender'
                                              ? colorBlue
                                              : Colors.black,
                                        ),
                                      ),
                                      SizedBox(height: 10),
                                      Text('Transgender'),
                                    ],
                                  ),
                                ),
                              ],
                            ),
                            SizedBox(height: size.height * 0.02),
                            Padding(
                              padding:
                                  const EdgeInsets.symmetric(horizontal: 20),
                              child: Row(
                                children: [
                                  Checkbox(
                                    value: privacy,
                                    onChanged: (value) {
                                      setState(() {
                                        privacy = value!;
                                      });
                                    },
                                  ),
                                  TextButton(
                                    onPressed: () {
                                      setState(() {
                                        privacy = !privacy;
                                      });
                                    },
                                    child: Text(
                                      'Make your number private',
                                      style: TextStyle(
                                        color: Colors.black,
                                      ),
                                    ),
                                  )
                                ],
                              ),
                            ),
                            SizedBox(height: size.height * 0.04),
                            widget.sourcepage == 1
                                ? Center(
                                    child: RoundedCustomNavigatorButton
                                        .customContainer(
                                      boxName: 'Submit',
                                      onTap: () {
                                        if (_key.currentState!.validate() &&
                                            dateOfBirth != null &&
                                            selectedGender.isNotEmpty) {
                                          if (age! < 13) {
                                            ShowToast.showToast(
                                              context,
                                              exception:
                                                  'You should be atleast 13 years.',
                                            );
                                          } else {
                                            setState(() {
                                              _loading = true;
                                            });
                                            UserData.createUser(
                                              authtoken: widget.authtoken!,
                                              name: nameController.text.trim(),
                                              gender: (selectedGender == 'Male')
                                                  ? "Male"
                                                  : (selectedGender == 'Female')
                                                      ? "Female"
                                                      : "Transgender",
                                              dob: dateOfBirth!,
                                              userName: userNameController.text
                                                  .trim()
                                                  .trimLeft()
                                                  .toLowerCase(),
                                              email:
                                                  emailController.text.trim(),
                                              privacy: privacy == true
                                                  ? "true"
                                                  : "false",
                                            ).then((value) async {
                                              setState(() {
                                                _loading = false;
                                              });
                                              SharedPreferences
                                                  sharedPreferences =
                                                  await SharedPreferences
                                                      .getInstance();
                                              setState(() {
                                                _loading = false;
                                              });
                                              if (value["status"] == 200) {
                                                Provider.of<SellForm>(context,
                                                        listen: false)
                                                    .getCategory();
                                                sharedPreferences.setString(
                                                    'authtoken',
                                                    widget.authtoken!);
                                                Provider.of<UserData>(context,
                                                        listen: false)
                                                    .getUserData(
                                                        authtoken:
                                                            widget.authtoken!);
                                                Navigator.pushAndRemoveUntil(
                                                  context,
                                                  MaterialPageRoute(
                                                    builder: (_) =>
                                                        CustomBottomNavBar(
                                                      chooseIndex: 0,
                                                    ),
                                                  ),
                                                  (route) => false,
                                                );
                                              } else if (value["status"] ==
                                                      409 &&
                                                  value["error"]
                                                          ["description"] ==
                                                      "user_name already exists") {
                                                ShowToast.showToast(context,
                                                    exception:
                                                        'Username already exists');
                                              } else if (value["status"] ==
                                                      409 &&
                                                  value["error"]
                                                          ["description"] ==
                                                      "email already exists") {
                                                ShowToast.showToast(context,
                                                    exception:
                                                        'Email already exists');
                                              } else {
                                                ShowToast.showToast(context,
                                                    exception:
                                                        'Something went wrong, try again.');
                                              }
                                            });
                                          }
                                        } else {
                                          ShowToast.showToast(context,
                                              exception:
                                                  'Kindly fill all the details mentioned.');
                                        }
                                      },
                                      context: context,
                                    ),
                                  )
                                : Center(
                                    child: RoundedCustomNavigatorButton
                                        .customContainer(
                                      boxName: 'Submit',
                                      context: context,
                                      onTap: () {
                                        if (age! < 13) {
                                          ShowToast.showToast(
                                            context,
                                            exception:
                                                'You should be atleast 13 years.',
                                          );
                                        } else {
                                          setState(() {
                                            _loading = true;
                                          });
                                          UserData.updateUser(
                                            authtoken: widget.authtoken!,
                                            name: nameController.text.trim(),
                                            gender: selectedGender,
                                            dob: dateOfBirth!,
                                            userName:
                                                userNameController.text.trim(),
                                            email: emailController.text.trim(),
                                            privacy: privacy == true
                                                ? "true"
                                                : "false",
                                          ).then((value) {
                                            if (value["status"] == 200) {
                                              Provider.of<UserData>(context,
                                                      listen: false)
                                                  .getUserData(
                                                      authtoken:
                                                          widget.authtoken!);
                                            }
                                            Navigator.pushAndRemoveUntil(
                                              context,
                                              MaterialPageRoute(
                                                builder: (_) =>
                                                    CustomBottomNavBar(
                                                  chooseIndex: 4,
                                                ),
                                              ),
                                              (route) => false,
                                            );
                                            setState(() {
                                              _loading = false;
                                            });
                                          });
                                        }
                                      },
                                    ),
                                  ),
                            SizedBox(height: size.height * 0.07),
                            //Country Name
                          ],
                        ),
                      ),
                      //Loading widget
                      loading ? LoadingWidget() : Container(),
                    ],
                  ),
                ),
              ),
            ),
    );
  }

  Future<ImageSource?> showImageSource(BuildContext context) {
    if (Platform.isAndroid) {
      return showModalBottomSheet(
        context: context,
        builder: (context) {
          return Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              ListTile(
                leading: Icon(
                  Icons.camera_alt,
                  color: Colors.black,
                ),
                title: Text('Camera'),
                onTap: () {
                  _cameraImage();
                  // print('Image file path: ${croppedFile?.path ?? 'Nothing'}');
                  Navigator.pop(context);
                },
              ),
              ListTile(
                leading: Icon(
                  Icons.image,
                  color: Colors.black,
                ),
                title: Text('Gallery'),
                onTap: () {
                  _galleryImage();
                  // print('Image file path: ${croppedFile?.path ?? 'Nothing'}');
                  Navigator.pop(context);
                },
              ),
            ],
          );
        },
      );
    } else {
      return showCupertinoModalPopup(
        context: context,
        builder: (context) {
          return CupertinoActionSheet(
            actions: [
              CupertinoActionSheetAction(
                onPressed: () {
                  _cameraImage();
                  // print('Image file path: ${croppedFile?.path ?? 'Nothing'}');
                  Navigator.pop(context);
                },
                child: Text('Camera'),
              ),
              CupertinoActionSheetAction(
                onPressed: () async {
                  _galleryImage();
                  // print('Image file path: ${croppedFile?.path ?? 'Nothing'}');
                  Navigator.pop(context);
                },
                child: Text('Gallery'),
              ),
            ],
          );
        },
      );
    }
  }

  Future _cameraImage() async {
    var cameraStatus = await Permission.camera.status;
    // print(cameraStatus);
    if (cameraStatus.isGranted) {
      // ignore: deprecated_member_use
      image = await _picker.getImage(
        source: ImageSource.camera,
        imageQuality: 100,
        maxHeight: 1000,
        maxWidth: 1000,
      );
      croppedFile = await ImageCropper.cropImage(sourcePath: image?.path ?? '');
      if (croppedFile != null) {
        setState(() {
          _image = File(croppedFile!.path);
          // print('Image file path: $_image');
          UserData.setPicture(
            authtoken: widget.authtoken!,
            image: _image!,
          ).then((value) {
            if (value["status"] != 200) {
              ShowToast.showToast(
                context,
                exception: 'Image not uploaded, kindly try again later.',
              );
            }
          });
        });
        // Provider.of<SetPicture>(context, listen: false)
        //     .setPicture(authtoken: _authToken!, image: _image!);
      }
    } else if (cameraStatus.isDenied) {
      Permission.camera.request();
    } else {
      await openAppSettings();
    }
    return croppedFile;
  }

  Future _galleryImage() async {
    // var galleryStatus = await Permission.storage.status;
    var galleryStatus = await Permission.photos.status;
    if (galleryStatus.isGranted) {
      // ignore: deprecated_member_use
      image = await _picker.getImage(
        source: ImageSource.gallery,
        imageQuality: 100,
        maxHeight: 1000,
        maxWidth: 1000,
      );
      croppedFile = await ImageCropper.cropImage(sourcePath: image?.path ?? '');
      if (croppedFile != null) {
        setState(() {
          _image = File(croppedFile!.path);
          // print('Image file path: $_image');
          UserData.setPicture(
            authtoken: widget.authtoken!,
            image: _image!,
          ).then((value) {
            if (value["status"] != 200) {
              ShowToast.showToast(
                context,
                exception: 'Image not uploaded, kindly try again later.',
              );
            }
          });
        });
        // Provider.of<SetPicture>(context, listen: false)
        //     .setPicture(authtoken: _authToken!, image: _image!);
      }
    } else if (galleryStatus.isDenied) {
      Permission.storage.request();
    } else {
      await openAppSettings();
    }
    return croppedFile;
  }

  Padding customContainer(
    BuildContext context, {
    required VoidCallback onTap,
    required Widget? child,
  }) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 30),
      child: InkWell(
        onTap: onTap,
        child: Container(
          width: double.infinity,
          height: 55,
          decoration: BoxDecoration(
            color: Colors.grey[200],
            border: Border.all(
              color: colorBlue,
            ),
            borderRadius: BorderRadius.circular(7),
          ),
          child: child,
        ),
      ),
    );
  }

  //Select Date
  _selectDate() async {
    pickedDate = await showModalBottomSheet<DateTime>(
      context: context,
      builder: (context) {
        DateTime? _selectedDate;
        return Container(
          height: 250,
          child: Column(
            children: <Widget>[
              Container(
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: <Widget>[
                    CupertinoButton(
                      child: Text('Cancel'),
                      onPressed: () {
                        Navigator.of(context).pop();
                      },
                    ),
                    CupertinoButton(
                      child: Text('Done'),
                      onPressed: () {
                        setState(() {
                          int? _day = _selectedDate?.day == null
                              ? DateTime.now().day
                              : _selectedDate?.day;
                          int? _month = _selectedDate?.month == null
                              ? DateTime.now().month
                              : _selectedDate?.month;
                          int? _year = _selectedDate?.year == null
                              ? DateTime.now().year
                              : _selectedDate?.year;
                          String _dobDay =
                              _day! < 10 ? '0$_day' : _day.toString();
                          String _dobMonth =
                              _month! < 10 ? '0$_month' : _month.toString();
                          String dobYear = _year.toString();
                          String selectedDOB = '$_dobDay-$_dobMonth-$dobYear';

                          dateOfBirth = _selectedDate?.day == null
                              ? "${DateTime.now().day}-${DateTime.now().month}-${DateTime.now().year}"
                              : selectedDOB;
                          age = DateTime.now().year - _year!;
                        });
                        Navigator.of(context).pop();
                      },
                    ),
                  ],
                ),
              ),
              Divider(
                height: 0,
                thickness: 1,
              ),
              Expanded(
                child: Container(
                  child: CupertinoDatePicker(
                    mode: CupertinoDatePickerMode.date,
                    onDateTimeChanged: (DateTime dateTime) {
                      setState(() {
                        _selectedDate = dateTime;
                      });
                    },
                    maximumDate: DateTime.now(),
                    initialDateTime: DateTime.now().subtract(Duration(days: 1)),
                  ),
                ),
              ),
            ],
          ),
        );
      },
    );
  }
}
