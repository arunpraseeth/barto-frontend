import 'package:flutter/material.dart';
import 'package:india/Common/color.dart';
import 'package:india/Widgets/Screens/My%20Posts/non_paid.dart';
import 'package:india/Widgets/Screens/My%20Posts/paid.dart';

// ignore: must_be_immutable
class MyPost extends StatefulWidget {
  @override
  State<MyPost> createState() => _MyPostState();
}

class _MyPostState extends State<MyPost> with SingleTickerProviderStateMixin {
  late TabController tabController;

  @override
  void initState() {
    tabController = TabController(length: 2, vsync: this);
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
        centerTitle: true,
        elevation: 2,
        backgroundColor: Color(0xFFF9F9F9),
        title: Text("My Post"),
        leading: Container(),
      ),
      body: Container(
        child: Padding(
          padding: const EdgeInsets.only(top: 5),
          child: Column(
            children: [
              TabBar(
                controller: tabController,
                indicatorColor: colorBlue,
                tabs: [
                  Tab(
                    child: Text(
                      'Free Ads',
                      style: TextStyle(
                        fontSize: 20,
                        color: Colors.black,
                      ),
                    ),
                  ),
                  Tab(
                    child: Text(
                      'Paid Ads',
                      style: TextStyle(
                        fontSize: 20,
                        color: Colors.black,
                      ),
                    ),
                  ),
                ],
              ),
              Expanded(
                child: Padding(
                  padding: const EdgeInsets.only(top: 20),
                  child: Container(
                    height: MediaQuery.of(context).size.height,
                    child: TabBarView(
                      controller: tabController,
                      children: [
                        NonPaidAds(),
                        PaidAds(),
                      ],
                    ),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
