import 'dart:io';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:image_cropper/image_cropper.dart';
import 'package:image_picker/image_picker.dart';
import 'package:india/Common/color.dart';
import 'package:india/Common/custom_navigator.dart';
import 'package:india/Common/loading_bool.dart';
import 'package:india/Common/loading_widget.dart';
import 'package:india/Common/show_toast.dart';
import 'package:india/Services/get_products.dart';
import 'package:india/Services/my_postapi.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:provider/provider.dart';
import 'package:shared_preferences/shared_preferences.dart';

// ignore: must_be_immutable
class EditProduct extends StatefulWidget {
  String productid;
  EditProduct({required this.productid});
  @override
  State<EditProduct> createState() => _EditProductState();
}

class _EditProductState extends State<EditProduct> {
  String? authToken;
  int activeIndex = 0;
  FocusNode _focusNode = FocusNode();
  final List<XFile> imageList = [];
  final ImagePicker _picker = ImagePicker();
  File? croppedFile;
  XFile? image;
  XFile? _image;
  TextEditingController _productName = TextEditingController();
  TextEditingController _productdescription = TextEditingController();
  TextEditingController _productPrice = TextEditingController();

  Future<String> getAuthToken() async {
    SharedPreferences sharedPreferences = await SharedPreferences.getInstance();
    authToken = sharedPreferences.getString("authtoken");
    print('Auth token: $authToken');
    return authToken ?? '';
  }

  @override
  void initState() {
    getAuthToken();
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    Map<String, dynamic> productinfo =
        Provider.of<ProductInformation>(context).productinfo;
    // var _timestamp = productinfo["timestamp"];
    // DateTime datetime = new DateTime.fromMillisecondsSinceEpoch(_timestamp);
    // int year = datetime.year;
    // int month = datetime.month;
    // int day = datetime.day;
    // String dateposted = "$day-$month-$year";
    _productName.text = productinfo["product_name"];
    _productdescription.text = productinfo["product_description"];
    _productPrice.text =
        productinfo["price"].replaceAll(new RegExp(r'[^\w\s]+'), '');
    List serverImage = productinfo["product_image"];
    return Scaffold(
      appBar: AppBar(
        centerTitle: true,
        title: Text("Edit post"),
        backgroundColor: Color(0xFFF9F9F9),
        elevation: 2,
      ),
      body: Provider.of<BoolLoader>(context).loadingStatus
          ? LoadingWidget()
          : GestureDetector(
              onTap: () {
                _focusNode.unfocus();
              },
              child: SingleChildScrollView(
                child: Container(
                  margin: EdgeInsets.symmetric(horizontal: 0),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      SizedBox(height: 30),
                      Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          SizedBox(height: 15),
                          Padding(
                            padding: const EdgeInsets.symmetric(horizontal: 20),
                            child: Text(
                              "Product Name",
                              style: TextStyle(fontSize: 20),
                            ),
                          ),
                          Padding(
                            padding: const EdgeInsets.only(
                                left: 17, right: 20, top: 5),
                            child: Container(
                              height: 65,
                              child: Card(
                                child: Center(
                                  child: TextFormField(
                                    keyboardType: TextInputType.name,
                                    style: TextStyle(
                                      fontSize: 20,
                                    ),
                                    controller: _productName,
                                    maxLength: 15,
                                    decoration: InputDecoration(
                                      counterText: "",
                                      contentPadding: EdgeInsets.only(left: 15),
                                      border: InputBorder.none,
                                    ),
                                    validator: (value) {
                                      if (value!.length < 3) {
                                        return "Kindly fill product name";
                                      }
                                    },
                                  ),
                                ),
                              ),
                            ),
                          ),
                          SizedBox(height: 15),
                          // Product Price
                          Padding(
                            padding: const EdgeInsets.symmetric(horizontal: 20),
                            child: Text(
                              "Product Price",
                              style: TextStyle(fontSize: 20),
                            ),
                          ),
                          // Product Price
                          Padding(
                            padding: const EdgeInsets.only(
                                left: 17, right: 20, top: 5),
                            child: Container(
                              height: 65,
                              child: Card(
                                child: Center(
                                  child: TextFormField(
                                    keyboardType:
                                        TextInputType.numberWithOptions(
                                            signed: true),
                                    inputFormatters: [
                                      FilteringTextInputFormatter.digitsOnly,
                                    ],
                                    style: TextStyle(
                                      fontSize: 20,
                                    ),
                                    controller: _productPrice,
                                    decoration: InputDecoration(
                                      contentPadding: EdgeInsets.only(left: 15),
                                      prefixText: "₹ ",
                                      border: InputBorder.none,
                                    ),
                                    validator: (value) {
                                      if (value!.isEmpty) {
                                        return "Kindly fill product price";
                                      }
                                    },
                                  ),
                                ),
                              ),
                            ),
                          ),
                          SizedBox(height: 15),
                          // Product Description
                          Padding(
                            padding: const EdgeInsets.symmetric(horizontal: 20),
                            child: Text(
                              "Product Description",
                              style: TextStyle(fontSize: 20),
                            ),
                          ),
                          // Product Description
                          Padding(
                            padding: const EdgeInsets.only(
                                left: 17, right: 20, top: 5),
                            child: Container(
                              height: 65,
                              child: Card(
                                child: Center(
                                  child: TextFormField(
                                    focusNode: _focusNode,
                                    style: TextStyle(
                                      fontSize: 20,
                                    ),
                                    controller: _productdescription,
                                    keyboardType: TextInputType.multiline,
                                    maxLines: null,
                                    decoration: InputDecoration(
                                      contentPadding: EdgeInsets.only(left: 15),
                                      border: InputBorder.none,
                                    ),
                                    validator: (value) {
                                      if (value!.length < 4) {
                                        return "Kindly enter product description";
                                      }
                                    },
                                    onEditingComplete: () {
                                      // print("edit");
                                      _focusNode.unfocus();
                                    },
                                  ),
                                ),
                              ),
                            ),
                          ),
                        ],
                      ),
                      SizedBox(height: 15),
                      // Product Image
                      serverImage.length < 3
                          ? Column(
                              children: [
                                Padding(
                                  padding: const EdgeInsets.symmetric(
                                      horizontal: 20),
                                  child: Row(
                                    children: [
                                      Text(
                                        "Update image ",
                                        style: TextStyle(fontSize: 20),
                                      ),
                                      Text(
                                        "(max ${3 - serverImage.length})  ",
                                        style: TextStyle(
                                            fontSize: 15, color: Colors.grey),
                                      ),
                                      InkWell(
                                        onTap: () {
                                          if (serverImage.length != 3 &&
                                              imageList.length <
                                                  (3 - serverImage.length)) {
                                            showImageSource(
                                              context,
                                              serverImage: serverImage,
                                            );
                                          }
                                        },
                                        child: Container(
                                          width: 20,
                                          height: 20,
                                          decoration: BoxDecoration(
                                            borderRadius:
                                                BorderRadius.circular(50),
                                            color: Color(0xFFDBDBDB),
                                          ),
                                          child: Align(
                                            alignment: Alignment.center,
                                            child: Icon(
                                              Icons.add,
                                              color: colorBlue,
                                              size: 20,
                                            ),
                                          ),
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                                imageList.isEmpty
                                    ? Container()
                                    : Padding(
                                        padding: const EdgeInsets.only(
                                            left: 17, top: 15),
                                        child: Stack(
                                          children: [
                                            GridView.builder(
                                              shrinkWrap: true,
                                              physics: ScrollPhysics(),
                                              itemCount: imageList.length,
                                              gridDelegate:
                                                  SliverGridDelegateWithFixedCrossAxisCount(
                                                      crossAxisCount: 3),
                                              itemBuilder: (gridviewcontext, index) {
                                                return Padding(
                                                  padding: const EdgeInsets
                                                      .symmetric(horizontal: 4),
                                                  child: Stack(
                                                    children: [
                                                      Container(
                                                        color:
                                                            Color(0xFFDBDBDB),
                                                        child: Align(
                                                          alignment:
                                                              Alignment.center,
                                                          child: Image.file(
                                                            File(
                                                                imageList[index]
                                                                    .path),
                                                            fit: BoxFit.contain,
                                                          ),
                                                        ),
                                                      ),
                                                      Align(
                                                        alignment:
                                                            Alignment.topRight,
                                                        child:
                                                            Transform.translate(
                                                          offset:
                                                              Offset(20, -14),
                                                          child: IconButton(
                                                            onPressed: () {
                                                              // print(index);
                                                              setState(() {
                                                                imageList
                                                                    .removeAt(
                                                                        index);
                                                              });
                                                            },
                                                            icon: Icon(
                                                              Icons.cancel,
                                                              color: colorBlue,
                                                            ),
                                                          ),
                                                        ),
                                                      ),
                                                    ],
                                                  ),
                                                );
                                              },
                                            ),
                                          ],
                                        ),
                                      ),
                              ],
                            )
                          : Container(),
                      SizedBox(height: 30),
                    ],
                  ),
                ),
              ),
            ),
      bottomNavigationBar: BoxCustomNavigatorButton.customContainer(
        boxName: "Submit",
        onTap: () {
          if (imageList.length <= (3 - serverImage.length)) {
            Provider.of<BoolLoader>(context, listen: false)
                .boolLoader(status: true);
            Provider.of<MyPostApi>(context, listen: false)
                .editPost(
              authtoken: authToken ?? '',
              productid: widget.productid,
              bodyMap: {
                "product_name": _productName.text.trim(),
                "price": _productPrice.text.trim(),
                "product_description": _productdescription.text.trim(),
              },
              images: imageList,
            )
                .then((value) {
              Provider.of<BoolLoader>(context, listen: false)
                  .boolLoader(status: false);
              if (value["status"] == 200) {
                Navigator.pop(context);
              } else {
                ShowToast.showToast(context,
                    exception: "Kindly try again later");
              }
            });
          } else {
            ShowToast.showToast(context,
                exception: "Select only ${3 - serverImage.length} images");
          }
        },
        context: context,
      ),
    );
  }

  Future<ImageSource?> showImageSource(BuildContext context,
      {required List serverImage}) {
    if (Platform.isAndroid) {
      return showModalBottomSheet(
        context: context,
        builder: (context) {
          return Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              ListTile(
                leading: Icon(
                  Icons.camera_alt,
                  color: Colors.black,
                ),
                title: Text('Camera'),
                onTap: () {
                  _cameraImage();
                  // print('Image file path: ${croppedFile?.path ?? 'Nothing'}');
                  Navigator.pop(context);
                },
              ),
              ListTile(
                leading: Icon(
                  Icons.image,
                  color: Colors.black,
                ),
                title: Text('Gallery'),
                onTap: () {
                  selectImage(
                    serverImage: serverImage,
                  );
                  // print('Image file path: ${croppedFile?.path ?? 'Nothing'}');
                  Navigator.pop(context);
                },
              ),
            ],
          );
        },
      );
    } else {
      return showCupertinoModalPopup(
        context: context,
        builder: (context) {
          return CupertinoActionSheet(
            actions: [
              CupertinoActionSheetAction(
                onPressed: () {
                  _cameraImage();
                  // print('Image file path: ${croppedFile?.path ?? 'Nothing'}');
                  Navigator.pop(context);
                },
                child: Text('Camera'),
              ),
              CupertinoActionSheetAction(
                onPressed: () async {
                  selectImage(
                    serverImage: serverImage,
                  );
                  // print('Image file path: ${croppedFile?.path ?? 'Nothing'}');
                  Navigator.pop(context);
                },
                child: Text('Gallery'),
              ),
            ],
          );
        },
      );
    }
  }

  void selectImage({required List serverImage}) async {
    var galleryStatus = await Permission.storage.status;
    if (galleryStatus.isGranted) {
      final List<XFile>? _selectedImages = await _picker.pickMultiImage(
        imageQuality: 100,
        maxHeight: 1000,
        maxWidth: 1000,
      );
      // print(_selectedImages?.length ?? 0);
      if (_selectedImages!.isNotEmpty) {
        // for (int i = 0; i < (3 - serverImage.length); i++) {
        for (int i = 0; i < _selectedImages.length; i++) {
          croppedFile =
              await ImageCropper.cropImage(sourcePath: _selectedImages[i].path);
          if (croppedFile != null) {
            setState(() {
              final bytes = croppedFile!.readAsBytesSync().lengthInBytes;
              final kb = bytes / 1024;
              // ignore: unused_local_variable
              final mb = kb / 1024;
              // print("mb: $mb");
              _image = XFile(croppedFile!.path);
              imageList.add(_image!);
              // print('Image file path: $_image');
            });
          }
        }
      }
      // print("Image list: ${imageList.length}");
    } else {
      ShowToast.showToast(context,
          exception: "Kindly enable permission to upload image");
      galleryStatus = await Permission.storage.request();
      if (galleryStatus.isGranted) {
        final List<XFile>? _selectedImages = await _picker.pickMultiImage(
          imageQuality: 100,
          maxHeight: 1000,
          maxWidth: 1000,
        );
        // print(_selectedImages?.length ?? 0);
        if (_selectedImages!.isNotEmpty) {
          for (int i = 0; i < _selectedImages.length; i++) {
            croppedFile = await ImageCropper.cropImage(
                sourcePath: _selectedImages[i].path);
            if (croppedFile != null) {
              setState(() {
                _image = XFile(croppedFile!.path);
                imageList.add(_image!);
                // print('Image file path: $_image');
              });
            }
          }
        }
        // print("Image list: ${imageList.length}");
      }
    }
  }

  void _cameraImage() async {
    var cameraStatus = await Permission.camera.status;
    // print(cameraStatus);
    if (cameraStatus.isGranted) {
      image = await _picker.pickImage(
        source: ImageSource.camera,
        imageQuality: 85,
        // maxHeight: 1000,
        // maxWidth: 1000,
      );
      croppedFile = await ImageCropper.cropImage(sourcePath: image?.path ?? '');
      if (croppedFile != null) {
        setState(() {
          _image = XFile(croppedFile!.path);
          imageList.add(_image!);
          // print("size: ${croppedFile!.readAsBytesSync().lengthInBytes}");
          // print('Image file path: $_image');
        });
      }
    } else if (cameraStatus.isDenied) {
      cameraStatus = await Permission.camera.request();
      if (cameraStatus.isGranted) {
        image = await _picker.pickImage(
          source: ImageSource.camera,
          imageQuality: 85,
          // maxHeight: 1000,
          // maxWidth: 1000,
        );
        croppedFile =
            await ImageCropper.cropImage(sourcePath: image?.path ?? '');
        if (croppedFile != null) {
          setState(() {
            _image = XFile(croppedFile!.path);
            imageList.add(_image!);
            // print('Image file path: $_image');
          });
          // Provider.of<SetPicture>(context, listen: false)
          //     .setPicture(authtoken: _authToken!, image: _image!);
        }
      } else {
        await openAppSettings();
      }
    } else {
      await openAppSettings();
    }
  }
}
