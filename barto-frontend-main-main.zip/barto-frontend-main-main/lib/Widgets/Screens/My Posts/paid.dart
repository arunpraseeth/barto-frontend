import 'dart:developer';
import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/cupertino.dart';
import "package:flutter/material.dart";
import 'package:flutter_svg/flutter_svg.dart';
import 'package:india/Common/loading_bool.dart';
import 'package:india/Common/loading_widget.dart';
import 'package:india/Common/showalert_dialog.dart';
import 'package:india/Model/location.dart';
import 'package:india/Model/shared_pref.dart';
import 'package:india/Services/domain.dart';
import 'package:india/Services/donate.dart';
import 'package:india/Services/get_home.dart';
import 'package:india/Services/get_products.dart';
import 'package:india/Services/my_postapi.dart';
import 'package:india/Services/user_data.dart';
import 'package:india/Widgets/Screens/My%20Posts/my_product.dart';
import 'package:india/Widgets/Screens/specific_product.dart';
import 'package:provider/provider.dart';
import 'package:razorpay_flutter/razorpay_flutter.dart';

// ignore: must_be_immutable
class PaidAds extends StatefulWidget {
  @override
  State<PaidAds> createState() => _PaidAdsState();
}

class _PaidAdsState extends State<PaidAds> {
  Razorpay razorpay = Razorpay();
  late String paymentSuccessId;
  late String paymentSignature = '';
  late String razorOrderID;
  late String paymentId;
  TextEditingController donateController = TextEditingController();

  @override
  void initState() {
    GetStoredInfo.getStoreInfo();
    razorpay.on(Razorpay.EVENT_PAYMENT_SUCCESS, handlerPaymentSuccess);
    razorpay.on(Razorpay.EVENT_PAYMENT_ERROR, handlerPaymentError);
    razorpay.on(Razorpay.EVENT_EXTERNAL_WALLET, handlerPaymentWallet);
    super.initState();
  }

  Future openCheckout({
    required String razorOrderID,
    required int amount,
  }) async {
    var options = {
      // Test key
      "amount": "${amount * 100}",
      'key': 'rzp_test_J2JHEtiAsG6guq',
      'name': 'Barto India',
      "order_id": razorOrderID,
      'description': "Donation",
      'timeout': 120,
      'prefill': {
        'contact': "+919751044998",
        'email': "barto.deepak@gmail.com",
      },
    };
    try {
      razorpay.open(options);
      return 200;
    } catch (e) {
      log('Razorpay error: $e');
      return 400;
    }
  }

  void handlerPaymentSuccess(PaymentSuccessResponse successResponse) {
    paymentSuccessId = successResponse.paymentId ?? '';
    paymentSignature = successResponse.signature ?? '';
    // print('Razorpay PaymentID: ${successResponse.paymentId}');
    // print('Razorpay OrderID: ${successResponse.orderId}');
    // print('Razorpay Signature: ${successResponse.signature}');
    Donate.verifyDonation(
      authtoken: GetStoredInfo.authtoken,
      paymentId: paymentId,
      razororderId: razorOrderID,
      razorpaymentId: paymentSuccessId,
      paymentSignature: paymentSignature,
    );
    Navigator.pop(this.context);
  }

  void handlerPaymentError(PaymentFailureResponse failureResponse) {
    print('FailureResponse code: ${failureResponse.code.toString()}');
    print('FailureResponse message: ${failureResponse.message}');
    Navigator.pop(context);
    ShowAlert.showAlertDialog(
      context,
      exception: "Kindly try again later.",
    );
  }

  void handlerPaymentWallet(ExternalWalletResponse walletResponse) {
    print('External wallet name: ${walletResponse.walletName}');
  }

  @override
  Widget build(BuildContext context) {
    Size size = MediaQuery.of(context).size;
    String authtoken = Provider.of<UserData>(context).authtoken;
    bool _loading = Provider.of<BoolLoader>(context).loadingStatus;
    List _paidproductinfo = Provider.of<MyPostApi>(context).paidproductinfo;
    String latitude = Provider.of<StoreLocation>(context).latitude.toString();
    String longitude = Provider.of<StoreLocation>(context).longitude.toString();
    return _loading
        ? LoadingWidget()
        : Scaffold(
            backgroundColor: Colors.white,
            body: Container(
              margin: EdgeInsets.only(top: 10),
              child: _paidproductinfo.isEmpty
                  ? Center(
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Padding(
                            padding: const EdgeInsets.symmetric(horizontal: 15),
                            child: SvgPicture.asset(
                              "assets/placeholders/notlisted.svg",
                              height: 250,
                            ),
                          ),
                          SizedBox(height: 20),
                          Text(
                            "You haven't posted any!",
                            style: TextStyle(
                              fontSize: 18,
                            ),
                          ),
                        ],
                      ),
                    )
                  : GridView.builder(
                      itemCount: _paidproductinfo.length,
                      padding: EdgeInsets.all(3),
                      gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                        childAspectRatio: size.width < 500 ? 0.85 : 1.1,
                        crossAxisCount: 2,
                      ),
                      itemBuilder: (BuildContext gridviewcontext, int index) {
                        Map<String, dynamic> _productLocation =
                            _paidproductinfo[index]["product_location"];
                        String areaname = _productLocation["area"];
                        String cityname = _productLocation["city"];
                        String statename = _productLocation["state"];
                        String countryname = _productLocation["country"];
                        return InkWell(
                          onTap: () {
                            Provider.of<BoolLoader>(this.context, listen: false)
                                .boolLoader(status: true);
                            Provider.of<ProductInformation>(this.context,
                                    listen: false)
                                .getproductInformation(
                              authtoken: authtoken,
                              productid: _paidproductinfo[index]["_id"],
                            )
                                .then(
                              (value) {
                                if (value["status"] == 200) {
                                  Navigator.push(
                                    this.context,
                                    MaterialPageRoute(
                                      builder: (_) => SpecificProduct(),
                                    ),
                                  ).then(
                                    (value) {
                                      if (value == "specificProduct" ||
                                          value == "Searchpage") {
                                        WidgetsBinding.instance
                                            ?.addPostFrameCallback(
                                          (duration) {
                                            // Provider.of<GetHome>(context,
                                            //         listen: false)
                                            //     .clearProductsList();
                                            Provider.of<GetHome>(context,
                                                    listen: false)
                                                .getProducts(
                                              refresh: true,
                                              authtoken: authtoken,
                                              lat: latitude == "0.0"
                                                  ? GetStoredInfo.latitude
                                                  : latitude,
                                              long: longitude == "0.0"
                                                  ? GetStoredInfo.longitude
                                                  : longitude,
                                            );
                                          },
                                        );
                                      }
                                    },
                                  );
                                }
                                Provider.of<BoolLoader>(this.context,
                                        listen: false)
                                    .boolLoader(status: false);
                              },
                            );
                          },
                          child: Stack(
                            children: [
                              Padding(
                                padding: const EdgeInsets.all(8.0),
                                child: Container(
                                  decoration: BoxDecoration(
                                    borderRadius: BorderRadius.circular(10),
                                    color: Colors.white,
                                    boxShadow: [
                                      BoxShadow(
                                        color: Colors.grey.withOpacity(0.3),
                                        spreadRadius: 0.7,
                                        blurRadius: 2,
                                        offset: Offset(
                                            0, 0), // changes position of shadow
                                      ),
                                    ],
                                  ),
                                  child: Stack(
                                    children: [
                                      Align(
                                        alignment: Alignment.topRight,
                                        child: PopupMenuButton(
                                          icon: Icon(Icons.more_vert),
                                          onSelected: (value) {
                                            switch (value) {
                                              // Edit product
                                              case 1:
                                                Provider.of<ProductInformation>(
                                                        context,
                                                        listen: false)
                                                    .getproductInformation(
                                                  productid:
                                                      _paidproductinfo[index]
                                                          ["_id"],
                                                  authtoken: authtoken,
                                                )
                                                    .then((value) {
                                                  if (value["status"] == 200) {
                                                    Provider.of<BoolLoader>(
                                                            context,
                                                            listen: false)
                                                        .boolLoader(
                                                            status: false);
                                                    Navigator.push(
                                                      context,
                                                      MaterialPageRoute(
                                                        builder: (_) =>
                                                            EditProduct(
                                                          productid:
                                                              _paidproductinfo[
                                                                  index]["_id"],
                                                        ),
                                                      ),
                                                    );
                                                  }
                                                });
                                                break;
                                              // Convert product status to sold
                                              case 2:
                                                changeProductStatus(
                                                  context,
                                                  authtoken: authtoken,
                                                  index: index,
                                                  paidproductinfo:
                                                      _paidproductinfo,
                                                  latitude: latitude,
                                                  longitude: longitude,
                                                );
                                                break;
                                              //Delete product
                                              case 3:
                                                showDelete(
                                                  context,
                                                  index: index,
                                                  authtoken: authtoken,
                                                  paidproductinfo:
                                                      _paidproductinfo,
                                                  latitude: latitude,
                                                  longitude: longitude,
                                                );
                                                break;
                                              case 4:
                                                showAlertDialog(
                                                  context,
                                                  size,
                                                  authtoken: authtoken,
                                                );
                                                break;
                                            }
                                          },
                                          itemBuilder: (context) => [
                                            PopupMenuItem(
                                              value: 1,
                                              child: Text(
                                                "Edit",
                                                style: TextStyle(
                                                  fontWeight: FontWeight.w500,
                                                  fontSize: 16,
                                                ),
                                              ),
                                            ),
                                            PopupMenuItem(
                                              value: 2,
                                              child: Text(
                                                "Sold",
                                                style: TextStyle(
                                                  fontWeight: FontWeight.w500,
                                                  fontSize: 16,
                                                ),
                                              ),
                                            ),
                                            PopupMenuItem(
                                              value: 3,
                                              child: Text(
                                                "Delete",
                                                style: TextStyle(
                                                  fontWeight: FontWeight.w500,
                                                  fontSize: 16,
                                                ),
                                              ),
                                            ),
                                            PopupMenuItem(
                                              value: 4,
                                              child: Text(
                                                "Support us",
                                                style: TextStyle(
                                                  fontWeight: FontWeight.w500,
                                                  fontSize: 16,
                                                ),
                                              ),
                                            ),
                                          ],
                                        ),
                                      ),
                                      Center(
                                        child: Column(
                                          mainAxisAlignment:
                                              MainAxisAlignment.center,
                                          children: [
                                            // Product image
                                            _paidproductinfo[index]
                                                        ["product_image"] ==
                                                    null
                                                ? Icon(
                                                    Icons.person,
                                                    size: 50,
                                                    color: Colors.grey,
                                                  )
                                                : CachedNetworkImage(
                                                    fit: BoxFit.cover,
                                                    height: 100,
                                                    imageUrl:
                                                        "${Domain.url}${_paidproductinfo[index]["product_image"]}",
                                                    placeholder:
                                                        (context, url) => Icon(
                                                      Icons.image,
                                                      size: 50,
                                                      color: Colors.grey,
                                                    ),
                                                    errorWidget: (context, url,
                                                            error) =>
                                                        new Icon(Icons.error),
                                                  ),
                                            SizedBox(
                                                height: size.height * 0.01),
                                            //Product name
                                            Text(
                                              _paidproductinfo[index]
                                                  ["product_name"],
                                              style: TextStyle(
                                                fontSize: size.width * 0.043,
                                                fontWeight: FontWeight.w600,
                                              ),
                                            ),
                                            SizedBox(
                                                height: size.height * 0.01),
                                            // Product price
                                            Text(
                                              _paidproductinfo[index]["price"],
                                              style: TextStyle(
                                                fontSize: size.width * 0.038,
                                              ),
                                            ),
                                            SizedBox(
                                                height: size.height * 0.01),
                                            Row(
                                              mainAxisAlignment:
                                                  MainAxisAlignment.center,
                                              children: [
                                                SizedBox(width: 10),
                                                Icon(
                                                  Icons.location_on,
                                                  size: size.width * 0.032,
                                                ),
                                                Flexible(
                                                  child: Container(
                                                    child: Padding(
                                                      padding:
                                                          const EdgeInsets.only(
                                                              right: 10),
                                                      child: Text(
                                                        (areaname.isEmpty &&
                                                                cityname
                                                                    .isEmpty &&
                                                                statename
                                                                    .isEmpty)
                                                            ? countryname
                                                            : (areaname.isEmpty &&
                                                                    cityname
                                                                        .isEmpty)
                                                                ? "$statename, $countryname"
                                                                : (areaname
                                                                        .isEmpty)
                                                                    ? "$cityname, $statename"
                                                                    : "$areaname, $cityname",
                                                        maxLines: 1,
                                                        overflow: TextOverflow
                                                            .ellipsis,
                                                        softWrap: false,
                                                        style: TextStyle(
                                                          fontSize: size.width *
                                                              0.033,
                                                        ),
                                                      ),
                                                    ),
                                                  ),
                                                ),
                                              ],
                                            ),
                                          ],
                                        ),
                                      ),
                                      _paidproductinfo[index]["status"] ==
                                              "Sold"
                                          ? Container(
                                              color:
                                                  Colors.white.withOpacity(0.5),
                                              child: Align(
                                                alignment:
                                                    Alignment.bottomCenter,
                                                child: Container(
                                                  width: double.infinity,
                                                  height: 30,
                                                  decoration: BoxDecoration(
                                                    borderRadius:
                                                        BorderRadius.circular(
                                                            10),
                                                    color: Colors.white,
                                                  ),
                                                  child: Center(
                                                    child: Text(
                                                      "Sold",
                                                      style: TextStyle(
                                                        fontSize: 20,
                                                        color: Colors.red,
                                                        fontWeight:
                                                            FontWeight.w400,
                                                      ),
                                                    ),
                                                  ),
                                                ),
                                              ),
                                            )
                                          : Container(),
                                    ],
                                  ),
                                ),
                              ),
                            ],
                          ),
                        );
                      },
                    ),
            ),
          );
  }

  // Donate Us
  Future showAlertDialog(
    BuildContext context,
    Size size, {
    required String authtoken,
  }) async {
    // set up the AlertDialog
    AlertDialog alert = AlertDialog(
      content: Container(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Text(
              "Show us your love by donating us!",
              style: TextStyle(
                fontSize: size.height * 0.018,
              ),
            ),
            SizedBox(height: 10),
            Row(
              mainAxisSize: MainAxisSize.min,
              mainAxisAlignment: MainAxisAlignment.center,
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [
                Container(
                  width: size.width * 0.2,
                  height: size.height * 0.05,
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(5),
                    border: Border.all(
                      width: 0.7,
                    ),
                  ),
                  child: TextFormField(
                    controller: donateController,
                    style: TextStyle(fontSize: size.height * 0.02),
                    keyboardType: TextInputType.number,
                    decoration: InputDecoration(
                      prefixText: "₹ ",
                      prefixStyle: TextStyle(
                        fontSize: size.height * 0.02,
                        color: Colors.grey,
                      ),
                      border: InputBorder.none,
                      contentPadding: EdgeInsets.only(left: 10, bottom: 5),
                    ),
                  ),
                ),
                SizedBox(width: 20),
                TextButton(
                  onPressed: () {
                    Donate.buyDonation(
                      authtoken: authtoken,
                      amount: donateController.text.trim(),
                    ).then((value) {
                      if (value["status"] == 200) {
                        Map<String, dynamic> _response = value["response"];
                        Map<String, dynamic> _data = _response["data"];
                        Map<String, dynamic> _info = _data["info"];
                        Map<String, dynamic> _orderDetails =
                            _info["order_details"];
                        String _paymentId = _orderDetails["payment_id"];
                        String _razorOrderId = _orderDetails["razor_order_id"];
                        setState(() {
                          razorOrderID = _razorOrderId;
                          paymentId = _paymentId;
                        });
                        openCheckout(
                          razorOrderID: _razorOrderId,
                          amount: int.parse(donateController.text.trim()),
                        );
                      }
                    });
                  },
                  child: Text(
                    "Donate",
                    style: TextStyle(
                      fontSize: size.height * 0.02,
                    ),
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
    // show the dialog
    await showDialog(
      context: context,
      builder: (BuildContext context) {
        return alert;
      },
    );
  }

  //Change post status
  void changeProductStatus(
    BuildContext context, {
    required int index,
    required String authtoken,
    required List paidproductinfo,
    required String latitude,
    required String longitude,
  }) {
    showDialog(
      context: context,
      builder: (context) => CupertinoAlertDialog(
        // title: Text("Delete?"),
        content: Text(
          "Are you sure you want to change to sold?",
          style: TextStyle(fontSize: 18),
        ),
        actions: <Widget>[
          CupertinoDialogAction(
              isDefaultAction: true,
              onPressed: () {
                Navigator.pop(context);
              },
              child: Text("Cancel")),
          CupertinoDialogAction(
              textStyle: TextStyle(color: Colors.red),
              isDefaultAction: true,
              onPressed: () async {
                Provider.of<BoolLoader>(context, listen: false)
                    .boolLoader(status: true);
                Provider.of<MyPostApi>(context, listen: false).editPost(
                  authtoken: authtoken,
                  productid: paidproductinfo[index]["_id"],
                  bodyMap: {"status": "Sold"},
                ).then((value) {
                  if (value["status"] == 200) {
                    // Provider.of<GetHome>(this.context, listen: false)
                    //     .clearProductsList();
                    filterbasedonLocation(
                      authtoken: authtoken,
                      latitude: latitude,
                      longitude: longitude,
                    );
                    Provider.of<MyPostApi>(this.context, listen: false)
                        .nonpaid(authtoken: authtoken)
                        .then(
                          (value) => Provider.of<BoolLoader>(this.context,
                                  listen: false)
                              .boolLoader(status: false),
                        );
                  }
                });
                Navigator.pop(context);
              },
              child: Text("Sold")),
        ],
      ),
    );
  }

  // Delete post
  void showDelete(
    BuildContext context, {
    required int index,
    required String authtoken,
    required List paidproductinfo,
    required String latitude,
    required String longitude,
  }) {
    showDialog(
      context: context,
      builder: (context) => CupertinoAlertDialog(
        // title: Text("Delete?"),
        content: Text(
          "Are you sure you want to delete?",
          style: TextStyle(fontSize: 18),
        ),
        actions: <Widget>[
          CupertinoDialogAction(
              isDefaultAction: true,
              onPressed: () {
                Navigator.pop(context);
              },
              child: Text("Cancel")),
          CupertinoDialogAction(
              textStyle: TextStyle(color: Colors.red),
              isDefaultAction: true,
              onPressed: () async {
                Provider.of<BoolLoader>(context, listen: false)
                    .boolLoader(status: true);
                Provider.of<MyPostApi>(context, listen: false).editPost(
                  authtoken: authtoken,
                  productid: paidproductinfo[index]["_id"],
                  bodyMap: {"status": "Terminated"},
                ).then((value) {
                  if (value["status"] == 200) {
                    // Provider.of<GetHome>(this.context, listen: false)
                    //     .clearProductsList();
                    filterbasedonLocation(
                      authtoken: authtoken,
                      latitude: latitude,
                      longitude: longitude,
                    );
                    Provider.of<MyPostApi>(this.context, listen: false)
                        .paid(authtoken: authtoken)
                        .then(
                          (value) => Provider.of<BoolLoader>(this.context,
                                  listen: false)
                              .boolLoader(status: false),
                        );
                  } else {
                    Provider.of<BoolLoader>(this.context, listen: false)
                        .boolLoader(status: false);
                  }
                });
                Navigator.pop(context);
              },
              child: Text("Delete")),
        ],
      ),
    );
  }

  filterbasedonLocation({
    required String authtoken,
    required String latitude,
    required String longitude,
  }) {
    Provider.of<GetHome>(this.context, listen: false).getProducts(
      authtoken: authtoken,
      lat: latitude == "0.0" ? GetStoredInfo.latitude : latitude,
      long: longitude == "0.0" ? GetStoredInfo.longitude : longitude,
      refresh: true,
    );
  }
}
