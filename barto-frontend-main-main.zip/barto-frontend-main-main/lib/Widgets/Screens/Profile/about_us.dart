import 'package:flutter/material.dart';
import 'package:india/Common/about_barto.dart';

class AboutUs extends StatelessWidget {
  const AboutUs({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        centerTitle: true,
        title: Text("About Us"),
        backgroundColor: Color(0xFFF9F9F9),
        elevation: 2,
      ),
      body: Container(
        margin: EdgeInsets.symmetric(vertical: 10, horizontal: 15),
        child: SingleChildScrollView(
          child: Column(
            children: [
              textBarto(text: aboutBarto1),
              SizedBox(height: 15),
              textBarto(text: aboutBarto2),
              SizedBox(height: 15),
              textBarto(text: aboutBarto3),
              SizedBox(height: 15),
              textBarto(text: aboutBarto4),
              SizedBox(height: 5),
              textBarto(text: aboutBarto5),
              SizedBox(height: 15),
              textBarto(text: aboutBarto6),
              SizedBox(height: 15),
              textBarto(text: aboutBarto7),
              SizedBox(height: 5),
              textBarto(text: aboutBarto8),
              SizedBox(height: 15),
              textBarto(text: aboutBarto9),
              SizedBox(height: 5),
              textBarto(text: aboutBarto10),
              SizedBox(height: 15),
              textBarto(text: aboutBarto11),
              SizedBox(height: 15),
              textBarto(text: aboutBarto12),
              SizedBox(height: 20),
            ],
          ),
        ),
      ),
    );
  }

  Widget textBarto({required String text}) {
    return Text(
      text,
      style: TextStyle(
        fontSize: 18,
      ),
      textAlign: TextAlign.justify,
    );
  }
}
