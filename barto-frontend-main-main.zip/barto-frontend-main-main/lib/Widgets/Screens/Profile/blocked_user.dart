import 'dart:io';
import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:india/Common/color.dart';
import 'package:india/Common/loading_widget.dart';
import 'package:india/Model/location.dart';
import 'package:india/Model/shared_pref.dart';
import 'package:india/Services/domain.dart';
import 'package:india/Services/get_home.dart';
import 'package:india/Services/user_data.dart';
import 'package:india/Widgets/Screens/bottom_navbar.dart';
import 'package:provider/provider.dart';
import 'package:shared_preferences/shared_preferences.dart';

// ignore: must_be_immutable
class BlockedUsers extends StatefulWidget {
  String authtoken;
  int routeNumber;
  BlockedUsers({required this.authtoken, required this.routeNumber});

  @override
  State<BlockedUsers> createState() => _BlockedUsersState();
}

class _BlockedUsersState extends State<BlockedUsers> {
  bool _loading = false;
  String? authToken;

  Future<String> getAuthToken() async {
    SharedPreferences sharedPreferences = await SharedPreferences.getInstance();
    authToken = sharedPreferences.getString("authtoken");
    return authToken ?? '';
  }

  @override
  void initState() {
    getAuthToken();
    GetStoredInfo.getStoreInfo();
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    Size size = MediaQuery.of(context).size;
    List blockeduserList = Provider.of<UserData>(context).blockedUsersList;
    String latitude = Provider.of<StoreLocation>(context).latitude.toString();
    String longitude = Provider.of<StoreLocation>(context).longitude.toString();
    return widget.routeNumber == 0
        ? WillPopScope(
            onWillPop: () async => false,
            child: Scaffold(
              appBar: AppBar(
                centerTitle: true,
                backgroundColor: Color(0xFFF9F9F9),
                elevation: 2,
                title: Text("Blocked Users"),
                leading: IconButton(
                  onPressed: () {
                    Navigator.pushAndRemoveUntil(
                      context,
                      MaterialPageRoute(
                        builder: (_) => CustomBottomNavBar(chooseIndex: 1),
                      ),
                      (route) => false,
                    );
                  },
                  icon: Icon(
                    Platform.isAndroid
                        ? Icons.arrow_back
                        : Icons.arrow_back_ios,
                  ),
                ),
              ),
              backgroundColor: Colors.white,
              body: body(
                blockeduserList,
                size,
                latitude: latitude,
                longitude: longitude,
              ),
            ),
          )
        : Scaffold(
            appBar: AppBar(
              centerTitle: true,
              backgroundColor: Color(0xFFF9F9F9),
              elevation: 2,
              title: Text("Blocked Users"),
            ),
            backgroundColor: Colors.white,
            body: body(
              blockeduserList,
              size,
              latitude: latitude,
              longitude: longitude,
            ),
          );
  }

  Container body(
    List<dynamic> blockeduserList,
    Size size, {
    required String latitude,
    required String longitude,
  }) {
    return Container(
      child: _loading
          ? LoadingWidget()
          : Container(
              margin: EdgeInsets.only(top: 10),
              child: blockeduserList.length < 1
                  ? Center(
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Padding(
                            padding: const EdgeInsets.symmetric(horizontal: 15),
                            child: SvgPicture.asset(
                              "assets/placeholders/blockedusers.svg",
                              height: 250,
                            ),
                          ),
                          SizedBox(height: 20),
                          Text(
                            "No blocked users.",
                            style: TextStyle(
                              fontSize: 18,
                            ),
                          ),
                        ],
                      ),
                    )
                  : ListView.builder(
                      itemCount: blockeduserList.length,
                      itemBuilder: (listviewcontext, index) {
                        return Padding(
                          padding: const EdgeInsets.symmetric(horizontal: 10),
                          child: Column(
                            children: [
                              SizedBox(height: 10),
                              Row(
                                mainAxisAlignment:
                                    MainAxisAlignment.spaceBetween,
                                children: [
                                  InkWell(
                                    onTap: () {
                                      setState(() {
                                        _loading = true;
                                      });
                                    },
                                    child: Row(
                                      children: [
                                        CircleAvatar(
                                          maxRadius: 30,
                                          backgroundColor: Colors.grey[200],
                                          child: blockeduserList[index]
                                                      ["avatar"]
                                                  .isEmpty
                                              ? Icon(
                                                  Icons.person,
                                                  color: Colors.indigo[900],
                                                  size: 40,
                                                )
                                              : ClipOval(
                                                  child: SizedBox(
                                                    child: AspectRatio(
                                                      aspectRatio: 1 / 1,
                                                      child: CachedNetworkImage(
                                                        fit: BoxFit.cover,
                                                        imageUrl:
                                                            "${Domain.url}${blockeduserList[index]["avatar"]}",
                                                        placeholder: (context,
                                                                url) =>
                                                            new CircularProgressIndicator(),
                                                        errorWidget: (context,
                                                                url, error) =>
                                                            new Icon(
                                                                Icons.error),
                                                      ),
                                                    ),
                                                  ),
                                                ),
                                        ),
                                        SizedBox(width: 20),
                                        Text.rich(
                                          TextSpan(
                                            children: [
                                              TextSpan(
                                                text: blockeduserList[index]
                                                    ["name"],
                                                style: TextStyle(
                                                  fontSize: 18,
                                                  fontWeight: FontWeight.bold,
                                                ),
                                              ),
                                              TextSpan(
                                                text:
                                                    '\n@${blockeduserList[index]["user_name"]}',
                                                style: TextStyle(
                                                  fontSize: 16,
                                                  fontWeight: FontWeight.w500,
                                                ),
                                              ),
                                            ],
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                  SizedBox(width: 10),
                                  InkWell(
                                    onTap: () {
                                      setState(() {
                                        _loading = true;
                                      });
                                      UserData.unblockUsers(
                                        authtoken: widget.authtoken,
                                        userName:
                                            "${blockeduserList[index]["user_name"]}",
                                      ).then((value) {
                                        if (value["status"] == 200) {
                                          setState(() {
                                            _loading = false;
                                          });
                                          blockeduserList.removeAt(index);
                                          // Provider.of<GetHome>(this.context,listen: false).clearProductsList();
                                          Provider.of<UserData>(this.context,
                                                  listen: false)
                                              .blockedUsers(
                                                  authtoken: authToken ?? '');
                                          // ! Change location areaname

                                          Provider.of<GetHome>(this.context,
                                                  listen: false)
                                              .getProducts(
                                            authtoken: authToken ?? '',
                                            refresh: true,
                                            lat: latitude == "0.0"
                                                ? GetStoredInfo.latitude
                                                : latitude,
                                            long: longitude == "0.0"
                                                ? GetStoredInfo.longitude
                                                : longitude,
                                          );
                                        } else {
                                          setState(() {
                                            _loading = false;
                                          });
                                        }
                                      });
                                    },
                                    child: Container(
                                      // width: size.width * 0.23,
                                      height: size.height * 0.037,
                                      decoration: BoxDecoration(
                                        color: colorBlue,
                                        borderRadius: BorderRadius.circular(5),
                                      ),
                                      child: Padding(
                                        padding: const EdgeInsets.symmetric(
                                            horizontal: 15),
                                        child: Center(
                                            child: Text(
                                          "Unblock",
                                          style: TextStyle(
                                            fontSize: 16,
                                            fontWeight: FontWeight.w500,
                                          ),
                                        )),
                                      ),
                                    ),
                                  )
                                ],
                              ),
                              SizedBox(height: 10),
                              Divider(thickness: 1),
                            ],
                          ),
                        );
                      },
                    ),
            ),
    );
  }
}
