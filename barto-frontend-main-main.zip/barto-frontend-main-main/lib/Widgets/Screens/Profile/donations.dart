import 'package:flutter/material.dart';
import 'package:india/Common/loading_bool.dart';
import 'package:india/Common/loading_widget.dart';
import 'package:india/Services/donate.dart';
import 'package:india/Widgets/Screens/Profile/my_donations.dart';
import 'package:india/Widgets/Screens/Profile/top_donators.dart';
import 'package:provider/provider.dart';

class Donations extends StatelessWidget {
  final String authtoken;
  const Donations({Key? key, required this.authtoken}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    Size size = MediaQuery.of(context).size;
    bool _loading = Provider.of<BoolLoader>(context).loadingStatus;
    return Scaffold(
      appBar: AppBar(
        centerTitle: true,
        title: Text("My Network"),
        backgroundColor: Color(0xFFF9F9F9),
        elevation: 2,
      ),
      body: _loading
          ? LoadingWidget()
          : ListView(
              children: [
                Container(
                  margin: EdgeInsets.symmetric(horizontal: 10, vertical: 10),
                  height: size.height * 0.06,
                  decoration: BoxDecoration(
                    boxShadow: [
                      BoxShadow(
                        color: Colors.grey.withOpacity(0.3),
                        spreadRadius: 0.7,
                        blurRadius: 2,
                        offset: Offset(0, 0), // changes position of shadow
                      ),
                    ],
                    color: Colors.white,
                    borderRadius: BorderRadius.circular(5),
                  ),
                  child: Center(
                    child: ListTile(
                      onTap: () {
                        Provider.of<BoolLoader>(context, listen: false)
                            .boolLoader(status: true);
                        Provider.of<Donate>(context, listen: false)
                            .myDonations(authtoken: authtoken)
                            .then((value) {
                          Provider.of<BoolLoader>(context, listen: false)
                              .boolLoader(status: false);
                          if (value["status"] == 200) {
                            Navigator.push(
                              context,
                              MaterialPageRoute(
                                builder: (_) => MyDonations(),
                              ),
                            );
                          }
                        });
                      },
                      title: Text(
                        "My donations",
                        style: TextStyle(fontSize: 18),
                      ),
                      trailing: Icon(Icons.arrow_right),
                    ),
                  ),
                ),
                Container(
                  margin: EdgeInsets.symmetric(horizontal: 10),
                  height: size.height * 0.06,
                  decoration: BoxDecoration(
                    boxShadow: [
                      BoxShadow(
                        color: Colors.grey.withOpacity(0.3),
                        spreadRadius: 0.7,
                        blurRadius: 2,
                        offset: Offset(0, 0), // changes position of shadow
                      ),
                    ],
                    color: Colors.white,
                    borderRadius: BorderRadius.circular(5),
                  ),
                  child: Center(
                    child: ListTile(
                      onTap: () {
                        Provider.of<BoolLoader>(context, listen: false)
                            .boolLoader(status: true);
                        Provider.of<Donate>(context, listen: false)
                            .topDonators(
                          refresh: true,
                          authtoken: authtoken,
                        )
                            .then((value) {
                          if (value["status"] == 200) {
                            Navigator.push(
                              context,
                              MaterialPageRoute(
                                builder: (_) => TopDonators(),
                              ),
                            );
                            Provider.of<BoolLoader>(context, listen: false)
                                .boolLoader(status: false);
                          } else {
                            Provider.of<BoolLoader>(context, listen: false)
                                .boolLoader(status: false);
                          }
                        });
                      },
                      title: Text(
                        "Top donators",
                        style: TextStyle(fontSize: 18),
                      ),
                      trailing: Icon(Icons.arrow_right),
                    ),
                  ),
                ),
              ],
            ),
    );
  }
}
