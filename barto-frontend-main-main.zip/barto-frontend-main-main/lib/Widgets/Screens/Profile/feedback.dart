import 'package:flutter/material.dart';
import 'package:india/Common/custom_navigator.dart';
import 'package:india/Common/loading_bool.dart';
import 'package:india/Common/loading_widget.dart';
import 'package:india/Common/show_toast.dart';
import 'package:india/Services/feedback_complaint.dart';
import 'package:india/Services/user_data.dart';
import 'package:india/Widgets/Screens/bottom_navbar.dart';
import 'package:provider/provider.dart';

// ignore: must_be_immutable
class FeedbackComplaint extends StatelessWidget {
  FocusNode _textFocusNode = FocusNode();
  TextEditingController _textController = TextEditingController();
  @override
  Widget build(BuildContext context) {
    Size size = MediaQuery.of(context).size;
    String authtoken = Provider.of<UserData>(context).authtoken;
    bool _loading = Provider.of<BoolLoader>(context).loadingStatus;
    int groupValue = Provider.of<FeedbackProvider>(context).groupValue;
    return Scaffold(
      appBar: AppBar(
        centerTitle: true,
        title: Text("Write to us"),
        backgroundColor: Color(0xFFF9F9F9),
        elevation: 2,
      ),
      backgroundColor: Colors.white,
      body: _loading
          ? LoadingWidget()
          : SingleChildScrollView(
              child: InkWell(
                onTap: () {
                  _textFocusNode.unfocus();
                },
                splashColor: Colors.transparent,
                child: Container(
                  margin: EdgeInsets.only(top: 20),
                  padding: EdgeInsets.symmetric(horizontal: 20),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        "You wish to:",
                        style: TextStyle(
                          fontSize: size.height * 0.02,
                        ),
                      ),
                      SizedBox(height: 20),
                      InkWell(
                        onTap: () {
                          Provider.of<FeedbackProvider>(context, listen: false)
                              .feedbackProvider(value: 1);
                        },
                        child: radiotypes(
                          size,
                          value: 1,
                          groupValue: groupValue,
                          textType: "Suggest",
                          onChanged: (int? value) {
                            Provider.of<FeedbackProvider>(context,
                                    listen: false)
                                .feedbackProvider(value: value!);
                          },
                        ),
                      ),
                      SizedBox(height: 20),
                      InkWell(
                        onTap: () {
                          Provider.of<FeedbackProvider>(context, listen: false)
                              .feedbackProvider(value: 2);
                        },
                        child: radiotypes(
                          size,
                          value: 2,
                          groupValue: groupValue,
                          textType: "Complaint",
                          onChanged: (int? value) {
                            Provider.of<FeedbackProvider>(context,
                                    listen: false)
                                .feedbackProvider(value: value!);
                          },
                        ),
                      ),
                      SizedBox(height: 20),
                      InkWell(
                        onTap: () {
                          Provider.of<FeedbackProvider>(context, listen: false)
                              .feedbackProvider(value: 3);
                        },
                        child: radiotypes(
                          size,
                          value: 3,
                          groupValue: groupValue,
                          textType: "Feedback",
                          onChanged: (int? value) {
                            Provider.of<FeedbackProvider>(context,
                                    listen: false)
                                .feedbackProvider(value: value!);
                          },
                        ),
                      ),
                      SizedBox(height: 20),
                      Container(
                        // width: size.width / 1,
                        // height: 200,
                        child: TextFormField(
                          focusNode: _textFocusNode,
                          maxLines: 9,
                          keyboardType: TextInputType.multiline,
                          controller: _textController,
                          style: TextStyle(
                            fontSize: size.height * 0.02,
                          ),
                          decoration: InputDecoration(
                            fillColor: Colors.white,
                            contentPadding: const EdgeInsets.symmetric(
                              vertical: 15.0,
                              horizontal: 15.0,
                            ),
                            focusedBorder: OutlineInputBorder(
                              borderRadius: BorderRadius.circular(5.0),
                              borderSide: BorderSide(
                                color: Colors.black,
                                width: 0.7,
                              ),
                            ),
                            enabledBorder: OutlineInputBorder(
                              borderRadius: BorderRadius.circular(5.0),
                              borderSide: BorderSide(
                                color: Colors.black,
                                width: 0.7,
                              ),
                            ),
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ),
      bottomNavigationBar: BottomAppBar(
        color: Colors.white,
        elevation: 0,
        child: BoxCustomNavigatorButton.customContainer(
          boxName: "Submit",
          onTap: () {
            if (groupValue != 0) {
              Provider.of<BoolLoader>(context, listen: false)
                  .boolLoader(status: true);
              FeedbackService.feedbackService(
                authtoken: authtoken,
                type: groupValue == 1
                    ? "Suggestions"
                    : groupValue == 2
                        ? "Complaints"
                        : "Feedback",
                feedback: _textController.text.trim(),
              ).then(
                (value) {
                  Provider.of<BoolLoader>(context, listen: false)
                      .boolLoader(status: false);
                  if (value["status"] == 200) {
                    Navigator.pushAndRemoveUntil(
                      context,
                      MaterialPageRoute(
                        builder: (_) => CustomBottomNavBar(chooseIndex: 4),
                      ),
                      (route) => false,
                    );
                  } else {
                    ShowToast.showToast(
                      context,
                      exception: "Something went wrong, try again later",
                    );
                  }
                },
              );
            }
          },
          context: context,
        ),
      ),
    );
  }

  Row radiotypes(
    Size size, {
    required int value,
    required int groupValue,
    required void Function(int?) onChanged,
    required String textType,
  }) {
    return Row(
      children: [
        Radio(
          value: value,
          groupValue: groupValue,
          onChanged: onChanged,
        ),
        Text(
          textType,
          style: TextStyle(
            fontSize: size.height * 0.02,
          ),
        ),
      ],
    );
  }
}

class FeedbackProvider with ChangeNotifier {
  int _groupValue = 0;
  feedbackProvider({required int value}) {
    _groupValue = value;
    notifyListeners();
  }

  int get groupValue => _groupValue;
}
