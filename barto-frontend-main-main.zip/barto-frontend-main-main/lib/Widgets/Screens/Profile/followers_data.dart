import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:india/Common/loading_bool.dart';
import 'package:india/Common/loading_widget.dart';
import 'package:india/Common/show_toast.dart';
import 'package:india/Services/domain.dart';
import 'package:india/Services/seller_details.dart';
import 'package:india/Services/user_data.dart';
import 'package:india/Widgets/Screens/seller_profile.dart';
import 'package:provider/provider.dart';

// ignore: must_be_immutable
class Followers extends StatelessWidget {
  String authtoken;
  Followers({required this.authtoken});

  @override
  Widget build(BuildContext context) {
    bool _loading = Provider.of<BoolLoader>(context).loadingStatus;
    late List followersList = Provider.of<UserData>(context).followerslist;
    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
        centerTitle: true,
        backgroundColor: Color(0xFFF9F9F9),
        elevation: 2,
        title: Text("Followers"),
      ),
      body: _loading
          ? LoadingWidget()
          : followersList.isEmpty
              ? Container(
                  child: Center(
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Padding(
                          padding: const EdgeInsets.symmetric(horizontal: 15),
                          child: SvgPicture.asset(
                            "assets/placeholders/nofollowers.svg",
                            height: 300,
                          ),
                        ),
                        Text(
                          "You don't have any followers.",
                          style: TextStyle(
                            fontSize: 18,
                          ),
                        ),
                      ],
                    ),
                  ),
                )
              : Container(
                  margin: EdgeInsets.only(top: 10),
                  child: ListView.builder(
                    itemCount: followersList.length,
                    itemBuilder: (listviewcontext, index) {
                      return Padding(
                        padding: const EdgeInsets.symmetric(horizontal: 10),
                        child: Column(
                          children: [
                            SizedBox(height: 10),
                            Row(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              children: [
                                InkWell(
                                  onTap: () {
                                    Provider.of<BoolLoader>(context,
                                            listen: false)
                                        .boolLoader(status: true);
                                    Provider.of<SellerDetails>(context,
                                            listen: false)
                                        .getsellerDetails(
                                      authtoken: authtoken,
                                      username: followersList[index]
                                          ["user_name"],
                                    )
                                        .then((value) {
                                      if (value["status"] == 200) {
                                        Navigator.push(
                                          context,
                                          MaterialPageRoute(
                                            builder: (_) => SellerProfile(),
                                          ),
                                        );
                                        Provider.of<BoolLoader>(context,
                                                listen: false)
                                            .boolLoader(status: false);
                                      } else {
                                        Provider.of<BoolLoader>(context,
                                                listen: false)
                                            .boolLoader(status: false);
                                        ShowToast.showToast(context,
                                            exception:
                                                "Kindly try again later");
                                      }
                                    });
                                  },
                                  child: Row(
                                    children: [
                                      CircleAvatar(
                                        maxRadius: 30,
                                        backgroundColor: Colors.grey[200],
                                        child: followersList[index]["avatar"] ==
                                                null
                                            ? Icon(
                                                Icons.person,
                                                color: Colors.indigo[900],
                                                size: 40,
                                              )
                                            : ClipOval(
                                                child: SizedBox(
                                                  child: AspectRatio(
                                                    aspectRatio: 1 / 1,
                                                    child: CachedNetworkImage(
                                                      fit: BoxFit.cover,
                                                      imageUrl:
                                                          "${Domain.url}${followersList[index]["avatar"]}",
                                                      placeholder: (context,
                                                              url) =>
                                                          new CircularProgressIndicator(),
                                                      errorWidget: (context,
                                                              url, error) =>
                                                          new Icon(Icons.error),
                                                    ),
                                                  ),
                                                ),
                                              ),
                                      ),
                                      SizedBox(width: 20),
                                      Text.rich(
                                        TextSpan(
                                          children: [
                                            TextSpan(
                                              text: followersList[index]
                                                  ["name"],
                                              style: TextStyle(
                                                fontSize: 20,
                                                fontWeight: FontWeight.bold,
                                              ),
                                            ),
                                            TextSpan(
                                              text:
                                                  '\n@${followersList[index]["user_name"]}',
                                              style: TextStyle(
                                                fontSize: 18,
                                                fontWeight: FontWeight.w500,
                                              ),
                                            ),
                                          ],
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                                SizedBox(width: 10),
                              ],
                            ),
                            SizedBox(height: 10),
                            Divider(thickness: 1),
                          ],
                        ),
                      );
                    },
                  ),
                ),
    );
  }
}
