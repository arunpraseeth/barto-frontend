import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:india/Common/color.dart';
import 'package:india/Common/loading_bool.dart';
import 'package:india/Common/loading_widget.dart';
import 'package:india/Common/show_toast.dart';
import 'package:india/Services/domain.dart';
import 'package:india/Services/seller_details.dart';
import 'package:india/Services/user_data.dart';
import 'package:india/Widgets/Screens/seller_profile.dart';
import 'package:provider/provider.dart';

// ignore: must_be_immutable
class FollowingMembers extends StatefulWidget {
  String authtoken;
  FollowingMembers({required this.authtoken});

  @override
  State<FollowingMembers> createState() => _FollowingMembersState();
}

class _FollowingMembersState extends State<FollowingMembers> {
  @override
  Widget build(BuildContext context) {
    Size size = MediaQuery.of(context).size;
    bool _loading = Provider.of<BoolLoader>(context).loadingStatus;
    late List followingList = Provider.of<UserData>(context).followinglist;
    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
        centerTitle: true,
        backgroundColor: Color(0xFFF9F9F9),
        elevation: 2,
        title: Text("Following"),
      ),
      body: _loading
          ? LoadingWidget()
          : followingList.isEmpty
              ? Container(
                  child: Center(
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Padding(
                          padding: const EdgeInsets.symmetric(horizontal: 15),
                          child: SvgPicture.asset(
                            "assets/placeholders/nofollowing.svg",
                            height: 170,
                          ),
                        ),
                        SizedBox(height: 20),
                        Text(
                          "You are not following anyone.",
                          style: TextStyle(
                            fontSize: 18,
                          ),
                        ),
                      ],
                    ),
                  ),
                )
              : Container(
                  margin: EdgeInsets.only(top: 10),
                  child: ListView.builder(
                    itemCount: followingList.length,
                    itemBuilder: (listviewcontext, index) {
                      return Padding(
                        padding: const EdgeInsets.symmetric(horizontal: 10),
                        child: Column(
                          children: [
                            SizedBox(height: 10),
                            Row(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              children: [
                                InkWell(
                                  onTap: () {
                                    Provider.of<BoolLoader>(context,
                                            listen: false)
                                        .boolLoader(status: true);
                                    Provider.of<SellerDetails>(context,
                                            listen: false)
                                        .getsellerDetails(
                                      authtoken: widget.authtoken,
                                      username: followingList[index]
                                          ["user_name"],
                                    )
                                        .then((value) {
                                      Provider.of<BoolLoader>(context,
                                              listen: false)
                                          .boolLoader(status: false);
                                      if (value["status"] == 200) {
                                        Navigator.push(
                                          this.context,
                                          MaterialPageRoute(
                                            builder: (_) => SellerProfile(),
                                          ),
                                        );
                                      } else {
                                        ShowToast.showToast(context,
                                            exception:
                                                "Kindly try again later");
                                      }
                                    });
                                  },
                                  child: Row(
                                    children: [
                                      CircleAvatar(
                                        maxRadius: 30,
                                        backgroundColor: Colors.grey[200],
                                        child: followingList[index]["avatar"] ==
                                                null
                                            ? Icon(
                                                Icons.person,
                                                color: Colors.indigo[900],
                                                size: 40,
                                              )
                                            : ClipOval(
                                                child: SizedBox(
                                                  child: AspectRatio(
                                                    aspectRatio: 1 / 1,
                                                    child: CachedNetworkImage(
                                                      fit: BoxFit.cover,
                                                      imageUrl:
                                                          "${Domain.url}${followingList[index]["avatar"]}",
                                                      placeholder: (context,
                                                              url) =>
                                                          new CircularProgressIndicator(),
                                                      errorWidget: (context,
                                                              url, error) =>
                                                          new Icon(Icons.error),
                                                    ),
                                                  ),
                                                ),
                                              ),
                                      ),
                                      SizedBox(width: 20),
                                      Text.rich(
                                        TextSpan(
                                          children: [
                                            // Full Name
                                            TextSpan(
                                              text: followingList[index]
                                                  ["name"],
                                              style: TextStyle(
                                                fontSize: 18,
                                                // fontSize: size.width * 0.040,
                                                fontWeight: FontWeight.bold,
                                              ),
                                            ),
                                            // User Name
                                            TextSpan(
                                              text:
                                                  '\n@${followingList[index]["user_name"]}',
                                              style: TextStyle(
                                                fontSize: 16,
                                                fontWeight: FontWeight.w500,
                                              ),
                                            ),
                                          ],
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                                SizedBox(width: 10),
                                InkWell(
                                  onTap: () {
                                    UserData.unfollow(
                                      authtoken: widget.authtoken,
                                      userprofilename: followingList[index]
                                          ["user_name"],
                                    ).then((value) {
                                      if (value["status"] == 200) {
                                        setState(() {
                                          followingList.removeAt(index);
                                        });
                                      }
                                    });
                                  },
                                  child: Container(
                                    // width: size.width * 0.23,
                                    height: size.height * 0.037,
                                    decoration: BoxDecoration(
                                      color: colorBlue,
                                      borderRadius: BorderRadius.circular(5),
                                    ),
                                    child: Padding(
                                      padding: const EdgeInsets.symmetric(
                                          horizontal: 15),
                                      child: Center(
                                          child: Text(
                                        "Unfollow",
                                        style: TextStyle(
                                          fontSize: 16,
                                          fontWeight: FontWeight.w500,
                                        ),
                                      )),
                                    ),
                                  ),
                                )
                              ],
                            ),
                            SizedBox(height: 10),
                            Divider(thickness: 1),
                          ],
                        ),
                      );
                    },
                  ),
                ),
    );
  }
}
