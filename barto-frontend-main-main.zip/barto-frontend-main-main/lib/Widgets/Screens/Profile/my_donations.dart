import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:india/Services/donate.dart';
import 'package:provider/provider.dart';

class MyDonations extends StatelessWidget {
  const MyDonations({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    Size size = MediaQuery.of(context).size;
    List<dynamic> _myDonationList = Provider.of<Donate>(context).mydonationList;
    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
        centerTitle: true,
        title: Text("My Donations"),
        backgroundColor: Color(0xFFF9F9F9),
        elevation: 2,
      ),
      body: _myDonationList.isEmpty
          ? Column(
              children: [
                SizedBox(height: size.height * 0.25),
                Center(
                  child: Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 15),
                    child: SvgPicture.asset(
                      "assets/placeholders/donation.svg",
                      height: 250,
                    ),
                  ),
                ),
                SizedBox(height: 20),
                Text(
                  'You haven\'t donated yet!',
                  style: TextStyle(
                    fontSize: 18,
                  ),
                ),
              ],
            )
          : Padding(
              padding: EdgeInsets.only(top: 5),
              child: ListView.builder(
                itemCount: _myDonationList.length,
                itemBuilder: (listviewcontext, index) {
                  int _donatedAmount = _myDonationList[index]["Amount"];
                  bool _paymentStatus =
                      _myDonationList[index]["payment_status"];
                  String _donatedDate = _myDonationList[index]["date"];
                  return Padding(
                    padding: EdgeInsets.symmetric(horizontal: 10, vertical: 5),
                    child: Container(
                      height: size.height * 0.08,
                      decoration: BoxDecoration(
                        boxShadow: [
                          BoxShadow(
                            color: Colors.grey.withOpacity(0.3),
                            spreadRadius: 0.7,
                            blurRadius: 2,
                            offset: Offset(0, 0), // changes position of shadow
                          ),
                        ],
                        color: Colors.white,
                        borderRadius: BorderRadius.circular(5),
                      ),
                      child: Center(
                        child: ListTile(
                          title: Text(
                            _donatedDate,
                            style: TextStyle(
                              fontSize: size.height * 0.02,
                              fontWeight: FontWeight.w500,
                            ),
                          ),
                          trailing: Column(
                            crossAxisAlignment: CrossAxisAlignment.end,
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              Text.rich(
                                TextSpan(
                                  children: [
                                    TextSpan(
                                      text: "Donated:",
                                      style: TextStyle(
                                        fontSize: size.height * 0.018,
                                        color: Colors.grey[700],
                                      ),
                                    ),
                                    TextSpan(
                                      text: "  ₹ $_donatedAmount",
                                      style: TextStyle(
                                        fontSize: size.height * 0.018,
                                        color: Colors.grey[700],
                                        fontWeight: FontWeight.w500,
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                              Text.rich(
                                TextSpan(
                                  children: [
                                    TextSpan(
                                      text: 'Status:  ',
                                      style: TextStyle(
                                        fontSize: size.height * 0.018,
                                        color: Colors.grey[700],
                                      ),
                                    ),
                                    _paymentStatus == true
                                        ? TextSpan(
                                            text: 'Success',
                                            style: TextStyle(
                                              fontSize: size.height * 0.018,
                                              color: Colors.green,
                                              fontWeight: FontWeight.w500,
                                            ),
                                          )
                                        : TextSpan(
                                            text: 'Failed',
                                            style: TextStyle(
                                              fontSize: size.height * 0.018,
                                              color: Colors.red,
                                              fontWeight: FontWeight.w500,
                                            ),
                                          )
                                  ],
                                ),
                              ),
                            ],
                          ),
                        ),
                      ),
                    ),
                  );
                },
              ),
            ),
    );
  }
}
