import 'package:flutter/material.dart';
import 'package:india/Common/loading_bool.dart';
import 'package:india/Common/loading_widget.dart';
import 'package:india/Services/user_data.dart';
import 'package:india/Widgets/Screens/Profile/followers_data.dart';
import 'package:india/Widgets/Screens/Profile/following_data.dart';
import 'package:provider/provider.dart';

// ignore: must_be_immutable
class MyNetwork extends StatelessWidget {
  String authtoken;
  String username;
  MyNetwork({Key? key, required this.authtoken, required this.username})
      : super(key: key);

  @override
  Widget build(BuildContext context) {
    Size size = MediaQuery.of(context).size;
    bool _loading = Provider.of<BoolLoader>(context).loadingStatus;
    return Scaffold(
      appBar: AppBar(
        centerTitle: true,
        title: Text("My Network"),
        backgroundColor: Color(0xFFF9F9F9),
        elevation: 2,
      ),
      body: _loading
          ? LoadingWidget()
          : ListView(
              children: [
                Container(
                  margin: EdgeInsets.symmetric(horizontal: 10, vertical: 10),
                  height: size.height * 0.06,
                  decoration: BoxDecoration(
                    boxShadow: [
                      BoxShadow(
                        color: Colors.grey.withOpacity(0.3),
                        spreadRadius: 0.7,
                        blurRadius: 2,
                        offset: Offset(0, 0), // changes position of shadow
                      ),
                    ],
                    color: Colors.white,
                    borderRadius: BorderRadius.circular(5),
                  ),
                  child: Center(
                    child: ListTile(
                      onTap: () {
                        Provider.of<BoolLoader>(context, listen: false)
                            .boolLoader(status: true);
                        Provider.of<UserData>(context, listen: false)
                            .following(
                          authtoken: authtoken,
                          userprofilename: username,
                        )
                            .then((value) {
                          Provider.of<BoolLoader>(context, listen: false)
                              .boolLoader(status: false);
                          if (value["status"] == 200) {
                            Navigator.push(
                              context,
                              MaterialPageRoute(
                                builder: (_) => FollowingMembers(
                                  authtoken: authtoken,
                                ),
                              ),
                            );
                          }
                        });
                      },
                      title: Text(
                        "Following",
                        style: TextStyle(fontSize: 18),
                      ),
                      trailing: Icon(Icons.arrow_right),
                    ),
                  ),
                ),
                Container(
                  margin: EdgeInsets.symmetric(horizontal: 10),
                  height: size.height * 0.06,
                  decoration: BoxDecoration(
                    boxShadow: [
                      BoxShadow(
                        color: Colors.grey.withOpacity(0.3),
                        spreadRadius: 0.7,
                        blurRadius: 2,
                        offset: Offset(0, 0), // changes position of shadow
                      ),
                    ],
                    color: Colors.white,
                    borderRadius: BorderRadius.circular(5),
                  ),
                  child: Center(
                    child: ListTile(
                      onTap: () {
                        Provider.of<BoolLoader>(context, listen: false)
                            .boolLoader(status: true);
                        Provider.of<UserData>(context, listen: false)
                            .followers(
                          authtoken: authtoken,
                          userprofilename: username,
                        )
                            .then((value) {
                          Provider.of<BoolLoader>(context, listen: false)
                              .boolLoader(status: false);
                          if (value["status"] == 200) {
                            Navigator.push(
                              context,
                              MaterialPageRoute(
                                builder: (_) => Followers(
                                  authtoken: authtoken,
                                ),
                              ),
                            );
                          }
                        });
                      },
                      title: Text(
                        "Followers",
                        style: TextStyle(fontSize: 18),
                      ),
                      trailing: Icon(Icons.arrow_right),
                    ),
                  ),
                ),
              ],
            ),
    );
  }
}
