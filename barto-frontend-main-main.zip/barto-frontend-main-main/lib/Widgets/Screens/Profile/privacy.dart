import 'dart:ui';
import 'package:flutter/material.dart';
import 'package:india/Common/loading_bool.dart';
import 'package:india/Common/loading_widget.dart';
import 'package:india/Services/user_data.dart';
import 'package:india/Widgets/Screens/Profile/blocked_user.dart';
import 'package:provider/provider.dart';

// ignore: must_be_immutable
class Privacy extends StatelessWidget {
  String authtoken;
  Privacy({required this.authtoken});

  @override
  Widget build(BuildContext context) {
    Size size = MediaQuery.of(context).size;
    bool _loading = Provider.of<BoolLoader>(context).loadingStatus;
    return Scaffold(
      appBar: AppBar(
        centerTitle: true,
        title: Text("Privacy"),
        backgroundColor: Color(0xFFF9F9F9),
        elevation: 2,
      ),
      backgroundColor: Colors.white,
      body: _loading
          ? LoadingWidget()
          : Container(
              margin: EdgeInsets.symmetric(horizontal: 10, vertical: 8),
              height: size.height * 0.06,
              decoration: BoxDecoration(
                boxShadow: [
                  BoxShadow(
                    color: Colors.grey.withOpacity(0.3),
                    spreadRadius: 0.7,
                    blurRadius: 2,
                    offset: Offset(0, 0), // changes position of shadow
                  ),
                ],
                color: Colors.white,
                borderRadius: BorderRadius.circular(5),
              ),
              child: Center(
                child: ListView(
                  children: [
                    ListTile(
                      onTap: () {
                        Provider.of<BoolLoader>(context, listen: false)
                            .boolLoader(status: true);
                        Provider.of<UserData>(context, listen: false)
                            .blockedUsers(
                          authtoken: authtoken,
                        )
                            .then((value) {
                          if (value["status"] == 200) {
                            Provider.of<BoolLoader>(context, listen: false)
                                .boolLoader(status: false);
                            Navigator.push(
                              context,
                              MaterialPageRoute(
                                builder: (_) => BlockedUsers(
                                  authtoken: authtoken,
                                  routeNumber: 1,
                                ),
                              ),
                            );
                          } else {
                            Provider.of<BoolLoader>(context, listen: false)
                                .boolLoader(status: false);
                          }
                        });
                      },
                      title: Text(
                        "Blocked Users",
                        style: TextStyle(fontSize: 18),
                      ),
                      trailing: Icon(Icons.arrow_right),
                    ),
                  ],
                ),
              ),
            ),
    );
  }
}
