import 'dart:io';

import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_svg/svg.dart';
import 'package:in_app_review/in_app_review.dart';
import 'package:india/Common/color.dart';
import 'package:india/Common/loading_bool.dart';
import 'package:india/Common/loading_widget.dart';
import 'package:india/Common/show_toast.dart';
import 'package:india/Services/domain.dart';
import 'package:india/Services/user_data.dart';
import 'package:india/Services/wishlist.dart';
import 'package:india/Widgets/Authentication/Signin/login_bottommodal.dart';
import 'package:india/Widgets/Authentication/Signup/create_user.dart';
import 'package:india/Widgets/Screens/Profile/donations.dart';
import 'package:india/Widgets/Screens/Profile/feedback.dart';
import 'package:india/Widgets/Screens/Profile/my_network.dart';
import 'package:india/Widgets/Screens/Profile/privacy.dart';
import 'package:india/Widgets/Screens/Profile/wishlist_screen.dart';
import 'package:india/Widgets/Screens/Profile/about_us.dart';
import 'package:india/main.dart';
import 'package:provider/provider.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../string_extension.dart';

class ProfileScreen extends StatefulWidget {
  const ProfileScreen({Key? key}) : super(key: key);

  @override
  State<ProfileScreen> createState() => _ProfileScreenState();
}

class _ProfileScreenState extends State<ProfileScreen> {
  String authToken = '';
  String? fcmtoken;
  String fullname = '';
  String username = '';
  String? email;
  String? phonenumber;
  String? gender;
  String? dob;
  bool? privacy;
  double maxradius = 68;
  LoginModalSheet loginModalSheet = LoginModalSheet();
  final InAppReview inAppReview = InAppReview.instance;

  Future<String> getAuthandFcmToken() async {
    SharedPreferences sharedPreferences = await SharedPreferences.getInstance();
    setState(() {
      authToken = sharedPreferences.getString("authtoken") ?? '';
      fcmtoken = sharedPreferences.getString("fcmtoken");
    });
    return authToken;
  }

  @override
  void initState() {
    getAuthandFcmToken();
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    Size size = MediaQuery.of(context).size;
    bool _loading = Provider.of<BoolLoader>(context).loadingStatus;
    fullname = Provider.of<UserData>(context).fullname.toString();
    username = Provider.of<UserData>(context).username.toString();
    email = Provider.of<UserData>(context).email.toString();
    gender = Provider.of<UserData>(context).gender.toString();
    dob = Provider.of<UserData>(context).dob.toString();
    privacy = Provider.of<UserData>(context).phoneprivacy;
    phonenumber = Provider.of<UserData>(context).phone.toString();
    return Scaffold(
      appBar: AppBar(
        centerTitle: true,
        title: Text("Account"),
        backgroundColor: Color(0xFFF9F9F9),
        elevation: 2,
        leading: Container(),
        actions: [
          PopupMenuButton(
            icon: Icon(Icons.more_vert),
            onSelected: (value) {
              setState(() {
                switch (value) {
                  case 1:
                    Provider.of<BoolLoader>(context, listen: false)
                        .boolLoader(status: false);
                    if (authToken.isEmpty) {
                      loginModalSheet.bottomModalSheet(context: context);
                    } else {
                      Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (_) => Privacy(
                            authtoken: authToken,
                          ),
                        ),
                      );
                    }
                    break;
                }
              });
            },
            itemBuilder: (context) => [
              PopupMenuItem(
                value: 1,
                child: Row(
                  children: [
                    SvgPicture.asset(
                      'assets/profileicons/privacy.svg',
                      height: 23,
                    ),
                    Text(
                      " Privacy",
                      style: TextStyle(
                        fontWeight: FontWeight.w500,
                        fontSize: 16,
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ],
      ),
      backgroundColor: Colors.white,
      body: _loading
          ? LoadingWidget()
          : SafeArea(
              child: GestureDetector(
                onTap: () {
                  setState(() {
                    maxradius = 68;
                  });
                },
                child: Container(
                  child: SingleChildScrollView(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        SizedBox(height: size.height * 0.05),
                        Center(
                          child: InkWell(
                            onTap: () {
                              setState(() {
                                maxradius = 150;
                              });
                            },
                            child: CircleAvatar(
                              maxRadius: maxradius,
                              child: CircleAvatar(
                                maxRadius: maxradius,
                                backgroundColor: Colors.grey[200],
                                child: (authToken.isEmpty ||
                                        Provider.of<UserData>(context)
                                            .avatar
                                            .isEmpty)
                                    ? Icon(
                                        Icons.person,
                                        size: 100,
                                        color: Colors.grey,
                                      )
                                    : ClipOval(
                                        child: SizedBox(
                                          child: AspectRatio(
                                            aspectRatio: 1 / 1,
                                            child: Padding(
                                              padding:
                                                  const EdgeInsets.all(15.0),
                                              child: CachedNetworkImage(
                                                fit: BoxFit.cover,
                                                imageUrl:
                                                    "${Domain.url}${Provider.of<UserData>(context).avatar}",
                                                placeholder: (context, url) =>
                                                    new CircularProgressIndicator(),
                                                errorWidget:
                                                    (context, url, error) =>
                                                        new Icon(Icons.error),
                                              ),
                                            ),
                                          ),
                                        ),
                                      ),
                              ),
                            ),
                          ),
                        ),
                        SizedBox(height: 5),
                        Row(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            SizedBox(width: 80),
                            // Full Name
                            Flexible(
                              child: Text(
                                authToken.isNotEmpty
                                    ? fullname.capitalize()
                                    : 'Full Name',
                                style: TextStyle(
                                  fontSize: 25,
                                  fontWeight: FontWeight.w500,
                                ),
                                maxLines: 1,
                                overflow: TextOverflow.ellipsis,
                              ),
                            ),
                            SizedBox(width: 5),
                            // Edit profile
                            IconButton(
                              onPressed: () {
                                Provider.of<BoolLoader>(context, listen: false)
                                    .boolLoader(status: false);

                                if (authToken.isEmpty) {
                                  loginModalSheet.bottomModalSheet(
                                      context: context);
                                } else {
                                  Navigator.of(context).push(
                                    MaterialPageRoute(
                                      builder: (_) => CreateUser(
                                        sourcepage: 2,
                                        authtoken: authToken,
                                        fullname: fullname,
                                        username: username,
                                        email: email,
                                        gender: gender,
                                        dob: dob,
                                        privacy: privacy,
                                      ),
                                    ),
                                  );
                                }
                              },
                              icon: Icon(
                                Icons.edit,
                              ),
                            ),
                            SizedBox(width: 30),
                          ],
                        ),
                        SizedBox(height: 5),
                        // User name
                        Center(
                          child: Text(
                            authToken.isNotEmpty ? "@$username" : 'Username',
                            style: TextStyle(fontSize: 22),
                          ),
                        ),
                        SizedBox(height: 5),
                        // Phonenumber
                        Center(
                          child: Text(
                            authToken.isNotEmpty
                                ? "+$phonenumber"
                                : 'Phonenumber',
                            style: TextStyle(fontSize: 19),
                          ),
                        ),
                        SizedBox(height: 20),
                        // Wish List
                        listTile(
                          leadingIcon: Icons.favorite,
                          name: 'Wish List',
                          trailingIcon: Icons.chevron_right,
                          onTap: () {
                            Provider.of<BoolLoader>(context, listen: false)
                                .boolLoader(status: false);
                            if (authToken.isEmpty) {
                              loginModalSheet.bottomModalSheet(
                                  context: context);
                            } else {
                              Provider.of<BoolLoader>(context, listen: false)
                                  .boolLoader(status: true);
                              Provider.of<Wishlist>(context, listen: false)
                                  .getWishslist(authtoken: authToken)
                                  .then((value) {
                                if (value["status"] == 200) {
                                  Navigator.push(
                                    context,
                                    MaterialPageRoute(
                                      builder: (_) => WishListScreen(
                                        authtoken: authToken,
                                      ),
                                    ),
                                  );
                                  Provider.of<BoolLoader>(context,
                                          listen: false)
                                      .boolLoader(status: false);
                                } else {
                                  ShowToast.showToast(context,
                                      exception: "Kindly try again later");
                                }
                              });
                            }
                          },
                        ),
                        SizedBox(height: 5),
                        // My Network
                        listTile(
                          leadingIcon: Icons.supervisor_account,
                          name: 'My Network',
                          trailingIcon: Icons.chevron_right,
                          onTap: () {
                            if (authToken.isEmpty) {
                              loginModalSheet.bottomModalSheet(
                                  context: context);
                            } else {
                              Provider.of<BoolLoader>(context, listen: false)
                                  .boolLoader(status: false);
                              Navigator.push(
                                context,
                                MaterialPageRoute(
                                  builder: (_) => MyNetwork(
                                    authtoken: authToken,
                                    username: username,
                                  ),
                                ),
                              );
                            }
                          },
                        ),
                        SizedBox(height: 5),
                        // About us
                        listTile(
                          leadingIcon: Icons.info,
                          name: 'About Us',
                          trailingIcon: Icons.chevron_right,
                          onTap: () {
                            Navigator.push(
                              context,
                              MaterialPageRoute(
                                builder: (_) => AboutUs(),
                              ),
                            );
                          },
                        ),
                        SizedBox(height: 5),
                        // Feedback
                        listTile(
                          leadingIcon: Icons.feedback,
                          name: 'Feedback and complaints',
                          trailingIcon: Icons.chevron_right,
                          onTap: () {
                            Provider.of<BoolLoader>(context, listen: false)
                                .boolLoader(status: false);
                            Navigator.push(
                              context,
                              MaterialPageRoute(
                                builder: (_) => FeedbackComplaint(),
                              ),
                            );
                          },
                        ),
                        SizedBox(height: 5),
                        listTile(
                          leadingIcon: Icons.star_rate,
                          name: 'Rate us',
                          trailingIcon: Icons.chevron_right,
                          onTap: () async {
                            if (await inAppReview.isAvailable()) {
                              inAppReview.requestReview();
                            } else {
                              inAppReview.openStoreListing(
                                  appStoreId: "com.barto.india");
                            }
                          },
                        ),
                        SizedBox(height: 5),

                        ListTile(
                          contentPadding: EdgeInsets.only(left: 50, right: 45),
                          onTap: () {
                            if (authToken.isEmpty) {
                              loginModalSheet.bottomModalSheet(
                                context: context,
                              );
                            } else {
                              Navigator.push(
                                context,
                                MaterialPageRoute(
                                  builder: (_) => Donations(
                                    authtoken: authToken,
                                  ),
                                ),
                              );
                            }
                          },
                          leading: SvgPicture.asset(
                            "assets/profileicons/donate.svg",
                            height: 25,
                          ),
                          title: Text(
                            'Donations',
                            style: TextStyle(
                              fontSize: 20,
                              color: Colors.black,
                            ),
                          ),
                          trailing: Icon(
                            Icons.chevron_right,
                            color: Colors.black,
                          ),
                        ),

                        SizedBox(height: 5),
                        listTile(
                          leadingIcon: Icons.call,
                          name: 'Contact',
                          trailingIcon: Icons.chevron_right,
                          onTap: () {},
                        ),
                        SizedBox(height: 20),
                        authToken.isNotEmpty
                            ? Padding(
                                padding: const EdgeInsets.only(left: 50),
                                child: TextButton(
                                  onPressed: () async {
                                    showAlertDialog(context);
                                  },
                                  child: Text(
                                    'Logout',
                                    style: TextStyle(
                                      fontSize: 20,
                                      color: Colors.red,
                                    ),
                                  ),
                                ),
                              )
                            : Container(),
                        SizedBox(height: 40),
                      ],
                    ),
                  ),
                ),
              ),
            ),
    );
  }

  ListTile listTile({
    required IconData leadingIcon,
    required IconData trailingIcon,
    required VoidCallback onTap,
    required String name,
  }) {
    return ListTile(
      contentPadding: EdgeInsets.only(left: 50, right: 45),
      onTap: onTap,
      leading: Icon(
        leadingIcon,
        color: colorBlue,
        // color: Colors.black,
      ),
      title: Text(
        name,
        style: TextStyle(
          fontSize: 20,
          color: Colors.black,
        ),
      ),
      trailing: Icon(
        trailingIcon,
        color: Colors.black,
      ),
    );
  }

  Future showAlertDialog(BuildContext context) async {
    if (Platform.isAndroid) {
      Widget cancelButton = TextButton(
        child: const Text("Cancel"),
        onPressed: () {
          Navigator.pop(context);
        },
      );
      Widget logoutButton = TextButton(
        child: const Text(
          "Logout",
          style: TextStyle(
            color: Colors.red,
          ),
        ),
        onPressed: () async {
          if (authToken.isEmpty) {
            loginModalSheet.bottomModalSheet(
              context: context,
            );
          } else {
            SharedPreferences sharedPreferences =
                await SharedPreferences.getInstance();
            await sharedPreferences.remove('authtoken');
            await sharedPreferences.remove('phonenumber');
            await sharedPreferences.remove('pincode');
            setState(() {
              fullname = '';
            });
            UserData.logout(
              fcmToken: fcmtoken!,
              authtoken: authToken,
            );
            Navigator.pushAndRemoveUntil(
              context,
              MaterialPageRoute(
                builder: (_) => MyHomePage(),
              ),
              (route) => false,
            );
          }
          Navigator.pop(context);
        },
      );

      AlertDialog alert = AlertDialog(
        content: const Text("Are you sure to Logout?"),
        actions: [
          cancelButton,
          logoutButton,
        ],
      );
      await showDialog(
        context: context,
        builder: (BuildContext context) {
          return alert;
        },
      );
    } else {
      showDialog(
        context: context,
        builder: (context) => CupertinoAlertDialog(
          content: Text(
            "Are you sure to Logout?",
            style: TextStyle(fontSize: 18),
          ),
          actions: <Widget>[
            CupertinoDialogAction(
              isDefaultAction: true,
              onPressed: () {
                Navigator.pop(context);
              },
              child: Text("Cancel"),
            ),
            CupertinoDialogAction(
              textStyle: TextStyle(color: Colors.red),
              isDefaultAction: true,
              child: Text("Logout"),
              onPressed: () async {
                if (authToken.isEmpty) {
                  loginModalSheet.bottomModalSheet(
                    context: context,
                  );
                } else {
                  SharedPreferences sharedPreferences =
                      await SharedPreferences.getInstance();
                  await sharedPreferences.remove('authtoken');
                  await sharedPreferences.remove('phonenumber');
                  await sharedPreferences.remove('pincode');
                  setState(() {
                    fullname = '';
                  });
                  UserData.logout(
                    fcmToken: fcmtoken!,
                    authtoken: authToken,
                  );
                  Navigator.pushAndRemoveUntil(
                    context,
                    MaterialPageRoute(
                      builder: (_) => MyHomePage(),
                    ),
                    (route) => false,
                  );
                }
              },
            ),
          ],
        ),
      );
    }
  }
}
