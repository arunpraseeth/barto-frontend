import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:india/Common/loading_bool.dart';
import 'package:india/Common/loading_widget.dart';
import 'package:india/Common/show_toast.dart';
import 'package:india/Services/domain.dart';
import 'package:india/Services/donate.dart';
import 'package:india/Services/seller_details.dart';
import 'package:india/Services/user_data.dart';
import 'package:india/Widgets/Screens/seller_profile.dart';
import 'package:india/Widgets/Screens/string_extension.dart';
import 'package:provider/provider.dart';
import 'package:pull_to_refresh/pull_to_refresh.dart';

// ignore: must_be_immutable
class TopDonators extends StatelessWidget {
  RefreshController refreshController =
      RefreshController(initialRefresh: false);

  @override
  Widget build(BuildContext context) {
    Size size = MediaQuery.of(context).size;
    bool _loading = Provider.of<BoolLoader>(context).loadingStatus;
    String authtoken = Provider.of<UserData>(context).authtoken;
    List<dynamic> topDanotors = Provider.of<Donate>(context).topdonators;
    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
        centerTitle: true,
        title: Text("Top Donators"),
        backgroundColor: Color(0xFFF9F9F9),
        elevation: 2,
      ),
      body: _loading
          ? LoadingWidget()
          : topDanotors.isEmpty
              ? Column(
                  children: [
                    SizedBox(height: size.height * 0.25),
                    Center(
                      child: Padding(
                        padding: const EdgeInsets.symmetric(horizontal: 15),
                        child: SvgPicture.asset(
                          "assets/placeholders/donation.svg",
                          height: 250,
                        ),
                      ),
                    ),
                    SizedBox(height: 20),
                    Text(
                      'No donations yet!',
                      style: TextStyle(
                        fontSize: 18,
                      ),
                    ),
                  ],
                )
              : Padding(
                  padding: EdgeInsets.only(top: 5),
                  child: SmartRefresher(
                    controller: refreshController,
                    enablePullDown: true,
                    enablePullUp: true,
                    onRefresh: () {
                      refreshPage(
                        context,
                        authToken: authtoken,
                      );
                    },
                    onLoading: () {
                      onLoading(
                        context,
                        authToken: authtoken,
                      );
                    },
                    child: ListView.builder(
                      itemCount: topDanotors.length,
                      itemBuilder: (listviewcontext, index) {
                        int _donatedAmount = topDanotors[index]["Amount"];
                        String _donatorName =
                            topDanotors[index]["user"][0]["name"];
                        String _avatar =
                            topDanotors[index]["user"][0]["avatar"];
                        String username =
                            topDanotors[index]["user"][0]["user_name"];
                        return Padding(
                          padding:
                              EdgeInsets.symmetric(horizontal: 10, vertical: 5),
                          child: InkWell(
                            onTap: () {
                              // print(topDanotors[index]);
                              Provider.of<BoolLoader>(context, listen: false)
                                  .boolLoader(status: true);
                              Provider.of<SellerDetails>(context, listen: false)
                                  .getsellerDetails(
                                authtoken: authtoken,
                                username: username,
                              )
                                  .then((value) {
                                Provider.of<BoolLoader>(context, listen: false)
                                    .boolLoader(status: false);
                                if (value["status"] == 200) {
                                  Navigator.push(
                                    context,
                                    MaterialPageRoute(
                                      builder: (_) => SellerProfile(),
                                    ),
                                  );
                                } else {
                                  ShowToast.showToast(context,
                                      exception: "Kindly try again later");
                                }
                              });
                            },
                            child: Container(
                              height: size.height * 0.08,
                              decoration: BoxDecoration(
                                boxShadow: [
                                  BoxShadow(
                                    color: Colors.grey.withOpacity(0.3),
                                    spreadRadius: 0.7,
                                    blurRadius: 2,
                                    offset: Offset(
                                        0, 0), // changes position of shadow
                                  ),
                                ],
                                color: Colors.white,
                                borderRadius: BorderRadius.circular(5),
                              ),
                              child: Center(
                                child: ListTile(
                                  leading: CircleAvatar(
                                    radius: 30,
                                    backgroundColor: Colors.grey[200],
                                    child: _avatar.isEmpty
                                        ? Icon(
                                            Icons.account_circle,
                                            size: 30,
                                            color: Colors.grey,
                                          )
                                        : CachedNetworkImage(
                                            fit: BoxFit.cover,
                                            height: size.height * 0.13,
                                            imageUrl: "${Domain.url}$_avatar",
                                            placeholder: (context, url) => Icon(
                                              Icons.image,
                                              size: 30,
                                              color: Colors.grey,
                                            ),
                                            errorWidget:
                                                (context, url, error) =>
                                                    new Icon(Icons.error),
                                          ),
                                  ),
                                  title: Text(
                                    " ${_donatorName.capitalize()}",
                                    style: TextStyle(
                                      fontSize: size.height * 0.02,
                                      fontWeight: FontWeight.w500,
                                    ),
                                  ),
                                  trailing: Text(
                                    "Donated:  ₹ $_donatedAmount",
                                    style: TextStyle(
                                      fontSize: size.height * 0.018,
                                      color: Colors.grey[700],
                                    ),
                                  ),
                                ),
                              ),
                            ),
                          ),
                        );
                      },
                    ),
                  ),
                ),
    );
  }

  refreshPage(
    BuildContext context, {
    required String authToken,
  }) {
    Provider.of<Donate>(context, listen: false)
        .topDonators(
      refresh: true,
      authtoken: authToken,
    )
        .then((value) {
      if (value["status"] == 200) {
        Map<String, dynamic> _response = value["response"];
        Map<String, dynamic> _data = _response["data"];
        Map<String, dynamic> _info = _data["info"];
        List<dynamic> _donation = _info["donation"];
        if (_donation.isEmpty) {
          refreshController.refreshCompleted();
        } else {
          refreshController.refreshCompleted();
        }
      } else {
        refreshController.refreshFailed();
      }
    });
  }

  onLoading(
    BuildContext context, {
    required String authToken,
  }) {
    Provider.of<Donate>(context, listen: false)
        .topDonators(
      refresh: false,
      authtoken: authToken,
    )
        .then((value) {
      if (value["status"] == 200) {
        Map<String, dynamic> _response = value["response"];
        Map<String, dynamic> _data = _response["data"];
        Map<String, dynamic> _info = _data["info"];
        List<dynamic> _donation = _info["donation"];
        if (_donation.isEmpty) {
          refreshController.refreshCompleted();
        } else {
          refreshController.refreshCompleted();
        }
      } else {
        refreshController.refreshFailed();
      }
    });
  }
}
