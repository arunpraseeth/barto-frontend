import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:india/Common/color.dart';
import 'package:india/Common/loading_bool.dart';
import 'package:india/Common/loading_widget.dart';
import 'package:india/Model/location.dart';
import 'package:india/Model/shared_pref.dart';
import 'package:india/Services/domain.dart';
import 'package:india/Services/get_home.dart';
import 'package:india/Services/get_products.dart';
import 'package:india/Services/wishlist.dart';
import 'package:india/Widgets/Screens/specific_product.dart';
import 'package:provider/provider.dart';

// ignore: must_be_immutable
class WishListScreen extends StatefulWidget {
  String authtoken;
  WishListScreen({required this.authtoken});

  @override
  State<WishListScreen> createState() => _WishListScreenState();
}

class _WishListScreenState extends State<WishListScreen> {
  @override
  void initState() {
    GetStoredInfo.getStoreInfo();
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    Size size = MediaQuery.of(context).size;
    bool _loading = Provider.of<BoolLoader>(context).loadingStatus;
    Map<String, dynamic> _products =
        Provider.of<Wishlist>(context).wishlistproducts;
    List wishlistproducts = _products.isEmpty ? [] : _products["products"];
    String latitude = Provider.of<StoreLocation>(context).latitude.toString();
    String longitude = Provider.of<StoreLocation>(context).longitude.toString();
    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
        centerTitle: true,
        backgroundColor: Color(0xFFF9F9F9),
        elevation: 2,
        title: Text("Wishlist"),
      ),
      body: _loading
          ? LoadingWidget()
          : Container(
              child: _products.isEmpty
                  ? Center(
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Padding(
                            padding: const EdgeInsets.symmetric(horizontal: 15),
                            child: SvgPicture.asset(
                              "assets/placeholders/wishlist.svg",
                              height: 250,
                            ),
                          ),
                          SizedBox(height: 20),
                          Text(
                            "You don't have any in wishlist.",
                            style: TextStyle(
                              fontSize: 18,
                            ),
                          ),
                        ],
                      ),
                    )
                  : GridView.builder(
                      shrinkWrap: true,
                      physics: ScrollPhysics(),
                      itemCount: wishlistproducts.length,
                      padding: EdgeInsets.all(3),
                      gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                        childAspectRatio: size.width < 500 ? 0.85 : 1.1,
                        crossAxisCount: 2,
                      ),
                      itemBuilder: (BuildContext gridviewcontext, int index) {
                        Map<String, dynamic> _productLocation =
                            wishlistproducts[index]["product_location"];
                        String areaname = _productLocation["area"];
                        String cityname = _productLocation["city"];
                        String statename = _productLocation["state"];
                        String countryname = _productLocation["country"];
                        bool _featured = wishlistproducts[index]["featured"];
                        return InkWell(
                          onTap: () {
                            Provider.of<BoolLoader>(context, listen: false)
                                .boolLoader(status: true);
                            Provider.of<ProductInformation>(context,
                                    listen: false)
                                .getproductInformation(
                              authtoken: widget.authtoken,
                              productid: wishlistproducts[index]["_id"],
                            )
                                .then(
                              (value) {
                                if (value["status"] == 200) {
                                  Navigator.push(
                                    this.context,
                                    MaterialPageRoute(
                                      builder: (_) => SpecificProduct(),
                                    ),
                                  ).then((value) {
                                    if (value == "specificProduct") {
                                      WidgetsBinding.instance
                                          ?.addPostFrameCallback(
                                        (duration) {
                                          Provider.of<Wishlist>(context,
                                                  listen: false)
                                              .getWishslist(
                                                  authtoken: widget.authtoken);
                                          // Provider.of<GetHome>(context,
                                          //         listen: false)
                                          //     .clearProductsList();
                                          Provider.of<GetHome>(context,
                                                  listen: false)
                                              .getProducts(
                                            refresh: true,
                                            authtoken: widget.authtoken,
                                            lat: latitude == "0.0"
                                                ? GetStoredInfo.latitude
                                                : latitude,
                                            long: longitude == "0.0"
                                                ? GetStoredInfo.longitude
                                                : longitude,
                                          );
                                        },
                                      );
                                      Provider.of<BoolLoader>(context,
                                              listen: false)
                                          .boolLoader(status: false);
                                    }
                                  });
                                }
                                Provider.of<BoolLoader>(context, listen: false)
                                    .boolLoader(status: false);
                              },
                            );
                          },
                          child: Padding(
                            padding: const EdgeInsets.all(8.0),
                            child: Container(
                              decoration: BoxDecoration(
                                borderRadius: BorderRadius.circular(10),
                                color: Colors.white,
                                boxShadow: [
                                  BoxShadow(
                                    color: Colors.grey.withOpacity(0.3),
                                    spreadRadius: 0.7,
                                    blurRadius: 2,
                                    offset: Offset(
                                        0, 0), // changes position of shadow
                                  ),
                                ],
                              ),
                              child: Stack(
                                children: [
                                  Center(
                                    child: Column(
                                      mainAxisAlignment:
                                          MainAxisAlignment.center,
                                      children: [
                                        wishlistproducts[index]
                                                    ["product_image"] ==
                                                null
                                            ? Icon(
                                                Icons.person,
                                                size: 50,
                                                color: Colors.grey,
                                              )
                                            : CachedNetworkImage(
                                                fit: BoxFit.cover,
                                                height: 100,
                                                imageUrl:
                                                    "${Domain.url}${wishlistproducts[index]["product_image"]}",
                                                placeholder: (context, url) =>
                                                    Icon(
                                                  Icons.image,
                                                  size: 50,
                                                  color: Colors.grey,
                                                ),
                                                errorWidget:
                                                    (context, url, error) =>
                                                        new Icon(Icons.error),
                                              ),

                                        SizedBox(height: size.height * 0.01),
                                        // Product name
                                        Text(
                                          wishlistproducts[index]
                                              ["product_name"],
                                          style: TextStyle(
                                            fontSize: size.width * 0.043,
                                            fontWeight: FontWeight.w600,
                                          ),
                                        ),
                                        SizedBox(height: size.height * 0.01),
                                        // Product price
                                        Text(
                                          wishlistproducts[index]["price"],
                                          style: TextStyle(
                                            fontSize: size.width * 0.038,
                                          ),
                                        ),

                                        SizedBox(height: size.height * 0.01),
                                        Row(
                                          mainAxisAlignment:
                                              MainAxisAlignment.center,
                                          children: [
                                            SizedBox(width: 10),
                                            Icon(
                                              Icons.location_on,
                                              size: size.width * 0.032,
                                            ),
                                            Flexible(
                                              child: Container(
                                                child: Padding(
                                                  padding:
                                                      const EdgeInsets.only(
                                                          right: 10),
                                                  child: Text(
                                                    (areaname.isEmpty &&
                                                            cityname.isEmpty &&
                                                            statename.isEmpty)
                                                        ? countryname
                                                        : (areaname.isEmpty &&
                                                                cityname
                                                                    .isEmpty)
                                                            ? "$statename, $countryname"
                                                            : (areaname.isEmpty)
                                                                ? "$cityname, $statename"
                                                                : "$areaname, $cityname",
                                                    maxLines: 1,
                                                    overflow:
                                                        TextOverflow.ellipsis,
                                                    softWrap: false,
                                                    style: TextStyle(
                                                      fontSize:
                                                          size.width * 0.033,
                                                    ),
                                                  ),
                                                ),
                                              ),
                                            ),
                                          ],
                                        ),
                                      ],
                                    ),
                                  ),
                                  Align(
                                    alignment: Alignment.topRight,
                                    child: IconButton(
                                      onPressed: () {
                                        setState(() {
                                          wishlistproducts[index]["wishlist"] =
                                              false;
                                        });
                                        // Provider.of<GetHome>(context,
                                        //         listen: false)
                                        //     .clearProductsList();
                                        Provider.of<Wishlist>(this.context,
                                                listen: false)
                                            .removeWishslist(
                                          productid: wishlistproducts[index]
                                              ["_id"],
                                          authtoken: widget.authtoken,
                                        )
                                            .then((value) {
                                          setState(() {
                                            wishlistproducts.removeAt(index);
                                          });
                                          filterbasedonLocation(
                                            authToken: widget.authtoken,
                                            latitude: latitude,
                                            longitude: longitude,
                                          );
                                        });
                                      },
                                      icon: wishlistproducts[index]
                                                  ["wishlist"] ==
                                              false
                                          ? Container(
                                              width: 23,
                                              height: 23,
                                              decoration: BoxDecoration(
                                                borderRadius:
                                                    BorderRadius.circular(50),
                                                color:
                                                    colorBlue.withOpacity(0.7),
                                              ),
                                              child: Icon(
                                                Icons.favorite,
                                                color: Colors.white,
                                                size: 17,
                                              ),
                                            )
                                          : Icon(
                                              Icons.favorite,
                                              color: colorBlue,
                                              size: 22,
                                            ),
                                    ),
                                  ),
                                  // Featured
                                  _featured
                                      ? Container(
                                          width: size.width * 0.20,
                                          height: size.height * 0.030,
                                          decoration: BoxDecoration(
                                            borderRadius: BorderRadius.only(
                                              bottomRight: Radius.circular(10),
                                            ),
                                            color: colorBlue,
                                          ),
                                          child: Center(
                                            child: Text(
                                              "Featured",
                                              style: TextStyle(
                                                fontSize: size.width * 0.035,
                                                fontWeight: FontWeight.w500,
                                                color: Colors.white,
                                              ),
                                            ),
                                          ),
                                        )
                                      : Container(),
                                ],
                              ),
                            ),
                          ),
                        );
                      },
                    ),
            ),
    );
  }

  filterbasedonLocation({
    required String authToken,
    required String latitude,
    required String longitude,
  }) {
    Provider.of<GetHome>(this.context, listen: false)
        .getProducts(
      authtoken: authToken,
      refresh: true,
      lat: latitude == "0.0" ? GetStoredInfo.latitude : latitude,
      long: longitude == "0.0" ? GetStoredInfo.longitude : longitude,
    )
        .then((value) {
      Provider.of<BoolLoader>(context, listen: false).boolLoader(status: false);
    });
  }
}
