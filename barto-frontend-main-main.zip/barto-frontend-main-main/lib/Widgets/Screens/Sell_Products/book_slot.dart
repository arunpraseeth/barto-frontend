import 'package:flutter/material.dart';
import 'package:flutter_spinkit/flutter_spinkit.dart';
import 'package:flutter_svg/svg.dart';
import 'package:india/Common/color.dart';
import 'package:india/Common/loading_bool.dart';
import 'package:india/Common/show_toast.dart';
import 'package:india/Model/location.dart';
import 'package:india/Model/shared_pref.dart';
import 'package:india/Services/get_home.dart';
import 'package:india/Services/my_postapi.dart';
import 'package:india/Services/sell_form.dart';
import 'package:india/Widgets/Screens/Sell_Products/slot_booking.dart';
import 'package:flutter_overlay_loader/flutter_overlay_loader.dart';
import 'package:india/Widgets/Screens/bottom_navbar.dart';
import 'package:provider/provider.dart';

// ignore: must_be_immutable
class BookSlot extends StatelessWidget {
  String? authToken;
  BookSlot({
    required this.authToken,
  });

  @override
  Widget build(BuildContext context) {
    Size size = MediaQuery.of(context).size;
    String? productid = Provider.of<SellForm>(context).productId;
    String latitude = Provider.of<StoreLocation>(context).latitude.toString();
    String longitude = Provider.of<StoreLocation>(context).longitude.toString();
    // print(authToken);
    // print(productid);
    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
        centerTitle: true,
        backgroundColor: Color(0xFFF5F5F5),
        elevation: 2,
        actions: [
          IconButton(
            onPressed: () {
              // Provider.of<GetHome>(context, listen: false).clearProductsList();
              filterbasedonLocation(
                context: context,
                latitude: latitude,
                longitude: longitude,
              );
            },
            icon: Icon(
              Icons.home,
              size: 30,
              color: colorBlue,
            ),
          ),
        ],
      ),
      body: Container(
        padding: EdgeInsets.symmetric(horizontal: 10),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            SizedBox(height: 20),
            Container(
              height: size.height * 0.45,
              width: double.infinity,
              // color: colorBlue,
              child: Center(
                child: SvgPicture.asset(
                  'assets/placeholders/adsuccessful.svg',
                ),
              ),
            ),
            SizedBox(height: size.height * 0.15),
            Container(
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(5),
                color: Colors.white,
                boxShadow: [
                  BoxShadow(
                    color: Colors.grey.withOpacity(0.3),
                    spreadRadius: 0.7,
                    blurRadius: 2,
                    offset: Offset(0, 0), // changes position of shadow
                  ),
                ],
              ),
              child: ListTile(
                onTap: () {
                  Loader.show(
                    context,
                    progressIndicator: SpinKitCircle(
                      color: colorBlue,
                    ),
                  );
                  Provider.of<BoolLoader>(context, listen: false)
                      .boolLoader(status: false);
                  Provider.of<SellForm>(context, listen: false)
                      .getplans(
                    authtoken: authToken!,
                    productid: productid!,
                  )
                      .then((value) {
                    if (value["status"] == 200) {
                      Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (_) => SlotBooking(
                            authtoken: authToken ?? '',
                            productid: productid,
                            latitude: latitude,
                            longitude: longitude,
                          ),
                        ),
                      );
                      Loader.hide();
                    } else {
                      ShowToast.showToast(
                        context,
                        exception: "Currently no plans available in your area",
                      );
                      Loader.hide();
                    }
                  });
                },
                title: Text(
                  "Want to get featured ?",
                  style: TextStyle(fontSize: 18, fontWeight: FontWeight.w500),
                ),
                trailing: Icon(
                  Icons.arrow_forward_ios,
                  size: 20,
                ),
              ),
            ),
            SizedBox(height: 40),
          ],
        ),
      ),
    );
  }

  filterbasedonLocation({
    required BuildContext context,
    required String latitude,
    required String longitude,
  }) {
    Provider.of<MyPostApi>(context, listen: false)
        .nonpaid(authtoken: authToken ?? '');
    Provider.of<MyPostApi>(context, listen: false)
        .paid(authtoken: authToken ?? '');
    Provider.of<GetHome>(context, listen: false)
        .getProducts(
      refresh: true,
      authtoken: authToken ?? '',
      lat: latitude == "0.0" ? GetStoredInfo.latitude : latitude,
      long: longitude == "0.0" ? GetStoredInfo.longitude : longitude,
    )
        .then((value) {
      if (value["status"] == 200) {
        Navigator.pushAndRemoveUntil(
          context,
          MaterialPageRoute(
            builder: (_) => CustomBottomNavBar(chooseIndex: 0),
          ),
          (route) => false,
        );
      }
    });
  }
}
