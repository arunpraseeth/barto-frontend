import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:india/Common/color.dart';
import 'package:india/Common/custom_navigator.dart';
import 'package:india/Common/show_toast.dart';
import 'package:india/Services/sell_form.dart';
import 'package:india/Widgets/Screens/Sell_Products/string_extension.dart';
import 'package:india/Widgets/Screens/Sell_Products/upload_image.dart';
import 'package:provider/provider.dart';

// ignore: must_be_immutable
class FormPage extends StatefulWidget {
  String? categoryid;
  FormPage({this.categoryid});

  @override
  State<FormPage> createState() => _FormPageState();
}

class _FormPageState extends State<FormPage> {
  String fieldType = '';
  String labelText = '';
  String? _selectedValue;
  String? _dropdownValueId;
  List stringFieldList = [];
  Map<String, String> _textFieldValues = {};
  Map<String, String>? _dropdowntextValues = {};
  TextEditingController _productName = TextEditingController();
  TextEditingController _productdescription = TextEditingController();
  TextEditingController _productPrice = TextEditingController();
  TextEditingController _yearcontroller = TextEditingController();
  final _key = GlobalKey<FormState>();
  FocusNode _descriptionNode = FocusNode();
  FocusNode _yearNode = FocusNode();
  FocusNode priceNode = FocusNode();

  @override
  void initState() {
    super.initState();
  }

  @override
  void dispose() {
    super.dispose();
    _descriptionNode.dispose();
    _yearNode.dispose();
    priceNode.dispose();
  }

  @override
  Widget build(BuildContext context) {
    List categoryFormList = Provider.of<SellForm>(context).categoryFormList;
    List<String> dropdownlistValues =
        Provider.of<SellForm>(context).dropdownListValues;
    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
        elevation: 2,
        centerTitle: true,
        title: Text("Product Details"),
        backgroundColor: Color(0xFFF5F5F5),
      ),
      body: Container(
        child: categoryFormList.length > 0
            ? GestureDetector(
                onTap: () {
                  _descriptionNode.unfocus();
                  _yearNode.unfocus();
                  priceNode.unfocus();
                },
                child: SingleChildScrollView(
                  child: Form(
                    key: _key,
                    child: Column(
                      children: [
                        SizedBox(height: 15),
                        Padding(
                          padding: const EdgeInsets.symmetric(horizontal: 20),
                          child: Row(
                            children: [
                              Text(
                                "Product Name",
                                style: TextStyle(fontSize: 20),
                              ),
                              Text(
                                " *",
                                style: TextStyle(fontSize: 17),
                              ),
                            ],
                          ),
                        ),
                        Padding(
                          padding: const EdgeInsets.only(
                              left: 17, right: 20, top: 5),
                          child: Container(
                            height: 60,
                            decoration: BoxDecoration(
                              borderRadius: BorderRadius.circular(5),
                              color: Colors.white,
                              boxShadow: [
                                BoxShadow(
                                  color: Colors.grey.withOpacity(0.3),
                                  spreadRadius: 0.7,
                                  blurRadius: 2,
                                  offset: Offset(
                                      0, 0), // changes position of shadow
                                ),
                              ],
                            ),
                            child: Center(
                              child: TextFormField(
                                keyboardType: TextInputType.name,
                                style: TextStyle(fontSize: 20),
                                controller: _productName,
                                maxLength: 15,
                                decoration: InputDecoration(
                                  counterText: "",
                                  contentPadding: EdgeInsets.only(left: 15),
                                  hintText: "Type here",
                                  border: InputBorder.none,
                                ),
                                validator: (value) {
                                  if (value!.length < 3) {
                                    return "Kindly fill product name";
                                  }
                                },
                              ),
                            ),
                          ),
                        ),
                        SizedBox(height: 15),
                        // Product Price
                        Padding(
                          padding: const EdgeInsets.symmetric(horizontal: 20),
                          child: Row(
                            children: [
                              Text(
                                "Product Price",
                                style: TextStyle(fontSize: 20),
                              ),
                              Text(
                                " *",
                                style: TextStyle(fontSize: 17),
                              ),
                            ],
                          ),
                        ),
                        // Product Price
                        Padding(
                          padding: const EdgeInsets.only(
                              left: 17, right: 20, top: 5),
                          child: Container(
                            height: 60,
                            decoration: BoxDecoration(
                              borderRadius: BorderRadius.circular(5),
                              color: Colors.white,
                              boxShadow: [
                                BoxShadow(
                                  color: Colors.grey.withOpacity(0.3),
                                  spreadRadius: 0.7,
                                  blurRadius: 2,
                                  offset: Offset(
                                      0, 0), // changes position of shadow
                                ),
                              ],
                            ),
                            child: Center(
                              child: TextFormField(
                                keyboardType: TextInputType.number,
                                focusNode: priceNode,
                                // keyboardType: TextInputType.numberWithOptions(
                                //     signed: true),
                                // inputFormatters: [
                                //   FilteringTextInputFormatter.digitsOnly,
                                // ],
                                style: TextStyle(fontSize: 20),
                                controller: _productPrice,
                                decoration: InputDecoration(
                                  prefixText: "₹ ",
                                  contentPadding: EdgeInsets.only(left: 15),
                                  hintText: "Type here",
                                  border: InputBorder.none,
                                ),
                                validator: (value) {
                                  if (value!.isEmpty) {
                                    return "Kindly fill product price";
                                  }
                                },
                              ),
                            ),
                          ),
                        ),
                        SizedBox(height: 15),
                        // Product Description
                        Padding(
                          padding: const EdgeInsets.symmetric(horizontal: 20),
                          child: Row(
                            children: [
                              Text(
                                "Product Description",
                                style: TextStyle(fontSize: 20),
                              ),
                              Text(
                                " *",
                                style: TextStyle(fontSize: 17),
                              ),
                            ],
                          ),
                        ),
                        // Product Description
                        Padding(
                          padding: const EdgeInsets.only(
                              left: 17, right: 20, top: 5),
                          child: Container(
                            height: 60,
                            decoration: BoxDecoration(
                              borderRadius: BorderRadius.circular(5),
                              color: Colors.white,
                              boxShadow: [
                                BoxShadow(
                                  color: Colors.grey.withOpacity(0.3),
                                  spreadRadius: 0.7,
                                  blurRadius: 2,
                                  offset: Offset(
                                      0, 0), // changes position of shadow
                                ),
                              ],
                            ),
                            child: Center(
                              child: TextFormField(
                                focusNode: _descriptionNode,
                                style: TextStyle(fontSize: 20),
                                controller: _productdescription,
                                keyboardType: TextInputType.multiline,
                                maxLines: null,
                                decoration: InputDecoration(
                                  contentPadding: EdgeInsets.only(left: 15),
                                  hintText: "Type here",
                                  border: InputBorder.none,
                                ),
                                validator: (value) {
                                  if (value!.length < 4) {
                                    return "Kindly enter product description";
                                  }
                                },
                                onEditingComplete: () {
                                  // print("edit");
                                  _descriptionNode.unfocus();
                                },
                              ),
                            ),
                          ),
                        ),
                        ListView.builder(
                          shrinkWrap: true,
                          physics: ScrollPhysics(),
                          itemCount: categoryFormList.length,
                          itemBuilder: (listviewcontext, index) {
                            fieldType = categoryFormList[index]["type"];
                            labelText = categoryFormList[index]["label"];
                            return Container(
                              padding: EdgeInsets.symmetric(horizontal: 20),
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  SizedBox(height: 20),
                                  Row(
                                    children: [
                                      Text(
                                        labelText,
                                        style: TextStyle(fontSize: 20),
                                      ),
                                      categoryFormList[index]["mandatory"] ==
                                              true
                                          ? Text(
                                              " *",
                                              style: TextStyle(fontSize: 17),
                                            )
                                          : Container(),
                                    ],
                                  ),
                                  dynamicWidget(
                                    categoryFormList: categoryFormList,
                                    dropdownlistValues: dropdownlistValues,
                                    index: index,
                                  ),
                                  // (textfieldType == "checkbox") ?
                                ],
                              ),
                            );
                          },
                        ),

                        // SizedBox(height: 30),
                        // Align(
                        //   alignment: Alignment.bottomCenter,
                        //   child: InkWell(
                        //     onTap: () {
                        //       // print(_dropdowntextValues);
                        //       if (_key.currentState!.validate() &&
                        //           _selectedValue != "") {
                        //         _pincode == null
                        //             ? Provider.of<GetCurrentLocation>(context,
                        //                     listen: false)
                        //                 .getLocationPermission(context: context)
                        //             : null;
                        //         Navigator.push(
                        //           context,
                        //           MaterialPageRoute(
                        //             builder: (_) => UploadProductImage(
                        //               categoryid: widget.categoryid,
                        //               productName: _productName.text.trim(),
                        //               productPrice: _productPrice.text.trim(),
                        //               productDescription:
                        //                   _productdescription.text.trim(),
                        //               dynamicMap: _dropdowntextValues ?? {},
                        //             ),
                        //           ),
                        //         );
                        //       } else {
                        //         ShowToast.showToast(context,
                        //             exception: "Kindly fill the details");
                        //       }
                        //     },
                        //     child: Padding(
                        //       padding: const EdgeInsets.symmetric(vertical: 5),
                        //       child: Container(
                        //         width: MediaQuery.of(context).size.width * 0.5,
                        //         height: 50,
                        //         decoration: BoxDecoration(
                        //           borderRadius: BorderRadius.circular(5),
                        //           color: colorBlue,
                        //         ),
                        //         child: Center(
                        //           child: Text(
                        //             "Next",
                        //             style: TextStyle(
                        //               fontSize: 22,
                        //               fontWeight: FontWeight.w500,
                        //               color: Colors.black87,
                        //             ),
                        //           ),
                        //         ),
                        //       ),
                        //     ),
                        //   ),
                        // ),
                        SizedBox(height: 10),
                      ],
                    ),
                  ),
                ),
              )
            : Center(
                child: Text(
                  "No Form Available",
                  style: TextStyle(fontSize: 20),
                ),
              ),
      ),
      bottomNavigationBar: BottomAppBar(
        color: Colors.white,
        elevation: 0,
        child: BoxCustomNavigatorButton.customContainer(
          boxName: "Next",
          onTap: () {
            if (categoryFormList.isNotEmpty) {
              if (_key.currentState!.validate() && _selectedValue != "") {
                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (_) => UploadProductImage(
                      categoryid: widget.categoryid,
                      productName: _productName.text.trim().capitalize(),
                      productPrice: _productPrice.text.trim(),
                      productDescription: _productdescription.text.trim(),
                      dynamicMap: _dropdowntextValues ?? {},
                    ),
                  ),
                );
              } else {
                ShowToast.showToast(context,
                    exception: "Kindly fill the details");
              }
            } else {}
          },
          context: context,
        ),
      ),
    );
  }

  Widget dynamicWidget({
    required List<String> dropdownlistValues,
    required List categoryFormList,
    required int index,
  }) {
    // print("codegroup: ${categoryFormList[index]["codeGroup"]}");
    if (fieldType == "dropdown") {
      List<String> dropdownValues = [];
      for (int i = 0;
          i < categoryFormList[index]["codeGroup"]["codeValues"].length;
          i++) {
        dropdownValues
            .add(categoryFormList[index]["codeGroup"]["codeValues"][i]["name"]);
      }
      return Padding(
        padding: const EdgeInsets.only(top: 5),
        child: dropDown(
          hintText: "Choose one",
          listValues: dropdownValues.toSet().toList(),
          onChanged: (value) {
            setState(() {
              // print(categoryFormList[index]["codeGroup"]["codeValues"]);
              for (int i = 0;
                  i < categoryFormList[index]["codeGroup"]["codeValues"].length;
                  i++) {
                if (categoryFormList[index]["codeGroup"]["codeValues"][i]
                        ["name"] ==
                    value) {
                  setState(() {
                    _dropdownValueId = categoryFormList[index]["codeGroup"]
                        ["codeValues"][i]["_id"];
                  });
                }
              }
              _textFieldValues
                  .addAll({"${categoryFormList[index]["label"]}": value!});
              _dropdowntextValues?.addAll(
                  {"${categoryFormList[index]["name"]}": _dropdownValueId!});
            });
          },
          selectedValue: (_textFieldValues.isNotEmpty &&
                  _textFieldValues
                      .containsKey(categoryFormList[index]["label"]))
              ? _textFieldValues[categoryFormList[index]['label']]
              : null,
        ),
      );
    } else if (fieldType == "text") {
      return Padding(
        padding: const EdgeInsets.only(top: 5),
        child: Container(
          height: 60,
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(5),
            color: Colors.white,
            boxShadow: [
              BoxShadow(
                color: Colors.grey.withOpacity(0.3),
                spreadRadius: 0.7,
                blurRadius: 2,
                offset: Offset(0, 0), // changes position of shadow
              ),
            ],
          ),
          child: Center(
            child: TextFormField(
              keyboardType: TextInputType.name,
              style: TextStyle(fontSize: 20),
              onChanged: (value) {
                getTextFieldValues(
                  categoryFormList: categoryFormList,
                  text: value,
                  index: index,
                );
              },
              decoration: InputDecoration(
                contentPadding: EdgeInsets.only(left: 15),
                hintText: "Type here",
                border: InputBorder.none,
              ),
              validator: (value) {
                if (value!.isEmpty) {
                  return "Kindly fill the details";
                }
              },
            ),
          ),
        ),
      );
    } else {
      if (categoryFormList[index]["label"] == "Year" ||
          categoryFormList[index]["label"] == "year") {
        return Padding(
          padding: const EdgeInsets.only(top: 5),
          child: Container(
            height: 60,
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(5),
              color: Colors.white,
              boxShadow: [
                BoxShadow(
                  color: Colors.grey.withOpacity(0.3),
                  spreadRadius: 0.7,
                  blurRadius: 2,
                  offset: Offset(0, 0), // changes position of shadow
                ),
              ],
            ),
            child: Center(
              child: TextFormField(
                focusNode: _yearNode,
                controller: _yearcontroller,
                keyboardType: TextInputType.number,
                // keyboardType: TextInputType.numberWithOptions(signed: true),
                inputFormatters: [
                  FilteringTextInputFormatter.digitsOnly,
                ],
                style: TextStyle(fontSize: 20),
                onChanged: (value) {
                  if (value.isNotEmpty) {
                    if (int.parse(value) > DateTime.now().year &&
                        value.length >= 4) {
                      _yearcontroller.clear();
                      _yearNode.unfocus();
                    } else {
                      getNumberFieldValues(
                        categoryFormList: categoryFormList,
                        text: value,
                        index: index,
                      );
                    }
                  }
                },
                decoration: InputDecoration(
                  contentPadding: EdgeInsets.only(left: 15),
                  hintText: "Type here",
                  border: InputBorder.none,
                ),
                validator: (value) {
                  if (value!.isEmpty) {
                    return "Kindly fill the details";
                  }
                },
                onEditingComplete: () {
                  _yearNode.unfocus();
                },
              ),
            ),
          ),
        );
      } else {
        return Padding(
          padding: const EdgeInsets.only(top: 5),
          child: Container(
            height: 60,
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(5),
              color: Colors.white,
              boxShadow: [
                BoxShadow(
                  color: Colors.grey.withOpacity(0.3),
                  spreadRadius: 0.7,
                  blurRadius: 2,
                  offset: Offset(0, 0), // changes position of shadow
                ),
              ],
            ),
            child: Center(
              child: TextFormField(
                // keyboardType: TextInputType.number,
                keyboardType: TextInputType.numberWithOptions(signed: true),
                inputFormatters: [
                  FilteringTextInputFormatter.digitsOnly,
                ],
                style: TextStyle(fontSize: 20),
                onChanged: (value) {
                  getNumberFieldValues(
                    categoryFormList: categoryFormList,
                    text: value,
                    index: index,
                  );
                },
                decoration: InputDecoration(
                  contentPadding: EdgeInsets.only(left: 15),
                  hintText: "Type here",
                  border: InputBorder.none,
                ),
                validator: (value) {
                  if (value!.isEmpty) {
                    return "Kindly fill the details";
                  }
                },
              ),
            ),
          ),
        );
      }
    }
    // ! date type
    // else if (fieldType == "date") {
    //   return customContainer(
    //     context,
    //     child: Padding(
    //       padding: const EdgeInsets.only(left: 15, top: 14),
    //       child: Text(
    //         '${(Provider.of<FormPage>(context).dateString.runtimeType == Null || Provider.of<FormPage>(context).dateString!.isEmpty) ? 'Date of Birth' : Provider.of<FormPage>(context).dateString}',
    //         style: Provider.of<FormPage>(context).dateString.runtimeType == Null
    //             ? TextStyle(
    //                 fontSize: 20,
    //                 fontWeight: FontWeight.w600,
    //                 color: Colors.grey[700],
    //               )
    //             : TextStyle(
    //                 fontSize: 20,
    //                 color: Colors.black,
    //                 fontWeight: FontWeight.w500,
    //               ),
    //       ),
    //     ),
    //     onTap: () {
    //       _selectDate(context: context);
    //     },
    //   );
    // } else if (fieldType == "radio") {
    //   print(
    //       "$labelText: ${categoryFormList[index]["codeGroup"]["codeValues"].length}");
    //   return ListView.builder(
    //     shrinkWrap: true,
    //     physics: ScrollPhysics(),
    //     itemCount: 3,
    //     itemBuilder: (context, index) {
    //       return Radio(
    //         value: 1,
    //         groupValue: 1,
    //         onChanged: (value) {},
    //       );
    //     },
    //   );
    // } else {
    //   return Checkbox(
    //     value: true,
    //     onChanged: (value) {},
    //   );
    // }
  }

  String? get selectedValue => _selectedValue;

  getNumberFieldValues({
    required String text,
    required int index,
    required List categoryFormList,
  }) {
    _dropdowntextValues!.addAll({"${categoryFormList[index]["name"]}": text});
  }

  getTextFieldValues({
    required String text,
    required int index,
    required List categoryFormList,
  }) {
    // _dropdowntextValues?.addAll({"${categoryFormList[index]["name"]}": _dropdownValueId!});
    _dropdowntextValues!.addAll({"${categoryFormList[index]["name"]}": text});
  }

  Widget dropDown({
    required String hintText,
    required String? selectedValue,
    required List<String> listValues,
    required Function(String? value) onChanged,
  }) {
    return Container(
      height: 60,
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(5),
        color: Colors.white,
        boxShadow: [
          BoxShadow(
            color: Colors.grey.withOpacity(0.3),
            spreadRadius: 0.7,
            blurRadius: 2,
            offset: Offset(0, 0), // changes position of shadow
          ),
        ],
      ),
      child: Center(
        child: ListTile(
          title: DropdownButtonHideUnderline(
            child: DropdownButton<String>(
              hint: Text(hintText),
              style: TextStyle(fontSize: 20, color: Colors.black),
              onChanged: onChanged,
              value: selectedValue,
              items: listValues.map(
                (String _value) {
                  return DropdownMenuItem<String>(
                    value: _value,
                    child: new Text(
                      _value,
                      style: TextStyle(fontSize: 20),
                    ),
                  );
                },
              ).toList(),
            ),
          ),
        ),
      ),
    );
  }

  Widget customContainer(
    BuildContext context, {
    required VoidCallback onTap,
    required Widget? child,
  }) {
    return InkWell(
      onTap: onTap,
      child: Container(
        width: double.infinity,
        height: 55,
        decoration: BoxDecoration(
          color: Colors.grey[200],
          border: Border.all(
            color: colorBlue,
          ),
          borderRadius: BorderRadius.circular(7),
        ),
        child: child,
      ),
    );
  }
}
