import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:india/Common/loading_bool.dart';
import 'package:india/Common/loading_widget.dart';
import 'package:india/Common/show_toast.dart';
import 'package:india/Services/domain.dart';
import 'package:india/Services/sell_form.dart';
import 'package:india/Widgets/Screens/Sell_Products/form_page.dart';
import 'package:india/Widgets/Screens/Sell_Products/sub_category.dart';
import 'package:provider/provider.dart';
import "string_extension.dart";

class SellProduct extends StatelessWidget {
  final GlobalKey<ScaffoldState> _scaffoldKey = GlobalKey<ScaffoldState>();

  @override
  Widget build(BuildContext context) {
    List categoryList = Provider.of<SellForm>(context).categoryList;
    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
        centerTitle: true,
        elevation: 1.5,
        title: Text("What are you selling?"),
        backgroundColor: Color(0xFFF5F5F5),
        leading: Container(),
      ),
      key: _scaffoldKey,
      body: Provider.of<BoolLoader>(context).loadingStatus
          ? LoadingWidget()
          : Container(
              margin: EdgeInsets.only(top: 10, bottom: 40),
              child: GridView.builder(
                // shrinkWrap: true,
                // physics: ScrollPhysics(),
                itemCount: categoryList.length,
                gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                  crossAxisCount: 3,
                  childAspectRatio: MediaQuery.of(context).size.width /
                      (MediaQuery.of(context).size.height / 2.4),
                ),
                itemBuilder: (BuildContext gridviewcontext, int index) {
                  return InkWell(
                    onTap: () async {
                      if (categoryList[index]["subcats"].length > 0) {
                        Provider.of<BoolLoader>(context, listen: false)
                            .boolLoader(status: false);
                        Navigator.push(
                          context,
                          MaterialPageRoute(
                            builder: (_) => SubCategory(
                              subcategoryList: categoryList[index]["subcats"],
                            ),
                          ),
                        );
                      } else {
                        Provider.of<BoolLoader>(context, listen: false)
                            .boolLoader(status: true);
                        Provider.of<SellForm>(context, listen: false)
                            .getCategoryForm(
                          categoryId: categoryList[index]["_id"],
                        )
                            .then(
                          (value) {
                            Provider.of<BoolLoader>(context, listen: false)
                                .boolLoader(status: false);
                            if (value["status"] == 200) {
                              Navigator.push(
                                _scaffoldKey.currentContext!,
                                MaterialPageRoute(
                                  builder: (_) => FormPage(
                                    categoryid: categoryList[index]["_id"],
                                  ),
                                ),
                              );
                            } else {
                              ShowToast.showToast(_scaffoldKey.currentContext!,
                                  exception: "Kindly try again later");
                            }
                          },
                        );
                      }
                    },
                    child: Column(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Flexible(
                          flex: 1,
                          fit: FlexFit.tight,
                          child: Padding(
                            padding: const EdgeInsets.symmetric(
                                horizontal: 10, vertical: 10),
                            child: Container(
                              width: MediaQuery.of(context).size.width / 5,
                              decoration: BoxDecoration(
                                borderRadius: BorderRadius.circular(10),
                                color: Colors.white,
                                boxShadow: [
                                  BoxShadow(
                                    color: Colors.grey.withOpacity(0.3),
                                    spreadRadius: 0.7,
                                    blurRadius: 2,
                                    offset: Offset(0, 0),
                                  ),
                                ],
                              ),
                              child: Padding(
                                padding: const EdgeInsets.all(3),
                                child: Container(
                                  child:
                                      categoryList[index]["cat_img_url"] == null
                                          ? Icon(
                                              Icons.collections,
                                              size: 50,
                                              color: Colors.grey,
                                            )
                                          : SvgPicture.network(
                                              "${Domain.url}${categoryList[index]["cat_img_url"]}",
                                            ),
                                ),
                              ),
                            ),
                          ),
                        ),
                        Padding(
                          padding: const EdgeInsets.only(bottom: 5),
                          child: Text(
                            "${categoryList[index]["name"]}".capitalize(),
                            style: TextStyle(
                              fontSize: 13,
                              fontWeight: FontWeight.w500,
                            ),
                          ),
                        ),
                      ],
                    ),
                  );
                },
              ),
            ),
    );
  }
}
