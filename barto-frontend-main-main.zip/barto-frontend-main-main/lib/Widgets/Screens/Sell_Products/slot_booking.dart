import 'dart:developer';
import 'package:flutter/material.dart';
import 'package:flutter_overlay_loader/flutter_overlay_loader.dart';
import 'package:flutter_spinkit/flutter_spinkit.dart';
import 'package:india/Common/color.dart';
import 'package:india/Common/custom_navigator.dart';
import 'package:india/Common/loading_bool.dart';
import 'package:india/Common/loading_widget.dart';
import 'package:india/Common/show_toast.dart';
import 'package:india/Common/showalert_dialog.dart';
import 'package:india/Model/shared_pref.dart';
import 'package:india/Services/get_home.dart';
import 'package:india/Services/my_postapi.dart';
import 'package:india/Services/sell_form.dart';
import 'package:india/Services/send_payment.dart';
import 'package:india/Widgets/Screens/bottom_navbar.dart';
import 'package:provider/provider.dart';
import 'package:razorpay_flutter/razorpay_flutter.dart';

// ignore: must_be_immutable
class SlotBooking extends StatefulWidget {
  String authtoken;
  String productid;
  String latitude;
  String longitude;
  SlotBooking({
    required this.authtoken,
    required this.productid,
    required this.latitude,
    required this.longitude,
  });

  @override
  State<SlotBooking> createState() => _SlotBookingState();
}

class _SlotBookingState extends State<SlotBooking> {
  int groupvalue = 0;
  late String slotposition;
  late String planid;
  late String paymentSuccessId;
  late String paymentSignature = '';
  late String paymentId;
  late String razorOrderID;
  Razorpay razorpay = Razorpay();

  @override
  void initState() {
    razorpay.on(Razorpay.EVENT_PAYMENT_SUCCESS, handlerPaymentSuccess);
    razorpay.on(Razorpay.EVENT_PAYMENT_ERROR, handlerPaymentError);
    razorpay.on(Razorpay.EVENT_EXTERNAL_WALLET, handlerPaymentWallet);
    super.initState();
  }

  Future openCheckout({
    required int total,
    required String razorOrderID,
    required String phoneNumber,
    required String email,
    required String description,
  }) async {
    var options = {
      // Test key
      'key': 'rzp_test_J2JHEtiAsG6guq',
      'amount': '${total * 100}',
      'application_cost': 30 * 100,
      'name': 'Barto India',
      "order_id": razorOrderID,
      'description': description,
      'timeout': 120,
      'prefill': {
        'contact': '$phoneNumber',
        'email': '$email',
      },
    };
    try {
      razorpay.open(options);
      return 200;
    } catch (e) {
      log('Razorpay error: $e');
      return 400;
    }
  }

  void handlerPaymentSuccess(PaymentSuccessResponse successResponse) {
    paymentSuccessId = successResponse.paymentId ?? '';
    paymentSignature = successResponse.signature ?? '';
    // print('Razorpay PaymentID: ${successResponse.paymentId}');
    // print('Razorpay OrderID: ${successResponse.orderId}');
    // print('Razorpay Signature: ${successResponse.signature}');
    Provider.of<BoolLoader>(context, listen: false).boolLoader(status: true);
    SendPaymentId.sendpaymentid(
      paymentId: paymentId,
      razororderId: razorOrderID,
      razorpaymentId: paymentSuccessId,
      paymentSignature: paymentSignature,
      authtoken: widget.authtoken,
    ).then((value) {
      // print("Payment success: $value");
      Map<String, dynamic> _response = value["response"];
      Map<String, dynamic> _data = _response["data"];
      Map<String, dynamic> _info = _data["info"];
      String _paymentStatus = _info["payment_status"];
      if ((value["status"] == 200) && (_paymentStatus == "Success")) {
        // Provider.of<GetHome>(context, listen: false).clearProductsList();
        filterbasedonLocation(
          context: context,
          latitude: widget.latitude,
          longitude: widget.longitude,
        );
      }
    });
  }

  void handlerPaymentError(PaymentFailureResponse failureResponse) {
    print('FailureResponse code: ${failureResponse.code.toString()}');
    print('FailureResponse message: ${failureResponse.message}');
    Navigator.pop(context);
    ShowAlert.showAlertDialog(
      context,
      exception: "Technical Issue! kindly contact the admin.",
    );
  }

  void handlerPaymentWallet(ExternalWalletResponse walletResponse) {
    print('External wallet name: ${walletResponse.walletName}');
  }

  @override
  void dispose() {
    razorpay.clear();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    Size size = MediaQuery.of(context).size;
    List slotinfo = Provider.of<SellForm>(context).plans;
    bool _loading = Provider.of<BoolLoader>(context).loadingStatus;
    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
        centerTitle: true,
        backgroundColor: Color(0xFFF5F5F5),
        title: Text('Slots'),
      ),
      body: _loading
          ? LoadingWidget()
          : SingleChildScrollView(
              child: Container(
                child: Column(
                  children: [
                    SizedBox(height: size.height * 0.01),
                    ListView.builder(
                      shrinkWrap: true,
                      physics: ScrollPhysics(),
                      itemCount: slotinfo.length,
                      itemBuilder: (listviewcontext, index) {
                        return Padding(
                          padding: EdgeInsets.symmetric(
                              horizontal: 10, vertical: 10),
                          child: InkWell(
                            onTap: () {
                              setState(() {
                                groupvalue = index + 1;
                                planid = slotinfo[index]["_id"];
                              });
                            },
                            child: Container(
                              height: size.height * 0.17,
                              decoration: BoxDecoration(
                                borderRadius: BorderRadius.circular(8),
                                border: Border.all(
                                  width: index == (groupvalue - 1) ? 2 : 0.4,
                                  color: index == (groupvalue - 1)
                                      ? colorBlue
                                      : Colors.white,
                                ),
                                color: Colors.white,
                                boxShadow: [
                                  BoxShadow(
                                    blurRadius: 1.5,
                                    color: Colors.grey,
                                    offset: Offset(0.0, 0.0),
                                  ),
                                ],
                              ),
                              child: Padding(
                                padding: const EdgeInsets.only(
                                    left: 20, top: 5, right: 5),
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  mainAxisSize: MainAxisSize.min,
                                  children: [
                                    Row(
                                      mainAxisAlignment:
                                          MainAxisAlignment.spaceBetween,
                                      children: [
                                        Text(
                                          "${slotinfo[index]["name"]}",
                                          style: TextStyle(
                                            fontSize: size.height * 0.02,
                                            color: Colors.grey[600],
                                          ),
                                        ),
                                        Radio(
                                          value: index + 1,
                                          groupValue: groupvalue,
                                          onChanged: (int? value) {
                                            setState(() {
                                              groupvalue = value!;
                                              planid = slotinfo[index]["_id"];
                                            });
                                          },
                                        ),
                                      ],
                                    ),
                                    SizedBox(height: 10),
                                    Text(
                                      "₹ ${slotinfo[index]["total_cost"]} for ${slotinfo[index]["expiryInDays"]} days",
                                      style: TextStyle(
                                        fontSize: size.height * 0.023,
                                      ),
                                    ),
                                    SizedBox(height: 20),
                                    Text(
                                      "${slotinfo[index]["description"]}",
                                      style: TextStyle(
                                        fontSize: size.height * 0.02,
                                        color: Colors.grey[600],
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                            ),
                          ),
                        );
                      },
                    ),
                  ],
                ),
              ),
            ),
      bottomNavigationBar: BottomAppBar(
        elevation: 0,
        child: BoxCustomNavigatorButton.customContainer(
          boxName: "Book Now",
          context: context,
          onTap: () {
            if (groupvalue != 0) {
              Loader.show(
                context,
                progressIndicator: SpinKitCircle(
                  color: colorBlue,
                ),
              );
              Provider.of<SellForm>(context, listen: false)
                  .buyplans(
                planId: planid,
                authtoken: widget.authtoken,
                productid: widget.productid,
              )
                  .then((value) {
                if (value["status"] == 400) {
                  Loader.hide();
                  ShowToast.showToast(
                    context,
                    exception: 'Kindly try after 5 minutes',
                  );
                } else {
                  Map<String, dynamic> _response = value["response"];
                  Map<String, dynamic> _data = _response["data"];
                  Map<String, dynamic> _info = _data["info"];
                  Map<String, dynamic> _orderDetails = _info["order_details"];
                  String _paymentId = _orderDetails["payment_id"];
                  String _razorOrderId = _orderDetails["razor_order_id"];
                  Loader.hide();
                  setState(() {
                    paymentId = _paymentId;
                    razorOrderID = _razorOrderId;
                  });
                  openCheckout(
                    total: 1,
                    // total: value["response"]["data"]["info"]["order_details"]["amount"],
                    description: "Subscription",
                    razorOrderID: razorOrderID,
                    email: "barto.deepak@gmail.com",
                    phoneNumber: "+919751044998",
                  ).then((value) {
                    if (value == 200) {
                      Loader.hide();
                    } else {
                      Loader.hide();
                    }
                  });
                }
              });
            }
          },
        ),
      ),
    );
  }

  filterbasedonLocation({
    required BuildContext context,
    required String latitude,
    required String longitude,
  }) {
    Provider.of<MyPostApi>(context, listen: false)
        .nonpaid(authtoken: widget.authtoken);
    Provider.of<MyPostApi>(context, listen: false)
        .paid(authtoken: widget.authtoken);
    Provider.of<GetHome>(context, listen: false)
        .getProducts(
      refresh: true,
      authtoken: widget.authtoken,
      lat: latitude == "0.0" ? GetStoredInfo.latitude : latitude,
      long: longitude == "0.0" ? GetStoredInfo.longitude : longitude,
    )
        .then((value) {
      Provider.of<BoolLoader>(context, listen: false).boolLoader(status: false);
      if (value["status"] == 200) {
        Navigator.pushAndRemoveUntil(
          context,
          MaterialPageRoute(
            builder: (_) => CustomBottomNavBar(chooseIndex: 0),
          ),
          (route) => false,
        );
      }
    });
  }
}
