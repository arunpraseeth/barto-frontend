import 'package:flutter/material.dart';
import 'package:india/Common/loading_bool.dart';
import 'package:india/Common/loading_widget.dart';
import 'package:india/Common/show_toast.dart';
import 'package:india/Services/sell_form.dart';
import 'package:india/Widgets/Screens/Sell_Products/form_page.dart';
import 'package:provider/provider.dart';
import "string_extension.dart";

// ignore: must_be_immutable
class SubCategory extends StatelessWidget {
  List subcategoryList;
  SubCategory({required this.subcategoryList});

  bool _loading = false;
  final GlobalKey<ScaffoldState> _scaffoldKey = GlobalKey<ScaffoldState>();
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      key: _scaffoldKey,
      appBar: AppBar(
        centerTitle: true,
        elevation: 2,
        title: Text("Sub category"),
        backgroundColor: Color(0xFFF5F5F5),
      ),
      body: _loading
          ? LoadingWidget()
          : Container(
              padding: EdgeInsets.only(top: 10),
              child: ListView.builder(
                itemCount: subcategoryList.length,
                itemBuilder: (listviewcontext, index) {
                  return Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 10),
                    child: InkWell(
                      onTap: () async {
                        if (subcategoryList[index]["subcats"].length > 0) {
                          Navigator.push(
                            context,
                            MaterialPageRoute(
                              builder: (_) => SubCategory(
                                subcategoryList: subcategoryList[index]
                                    ["subcats"],
                              ),
                            ),
                          );
                        } else {
                          Provider.of<BoolLoader>(context, listen: false)
                              .boolLoader(status: true);
                          await Provider.of<SellForm>(context, listen: false)
                              .getCategoryForm(
                            categoryId: subcategoryList[index]["_id"],
                          )
                              .then(
                            (value) {
                              Provider.of<BoolLoader>(context, listen: false)
                                  .boolLoader(status: false);
                              if (value["status"] == 200) {
                                // if (value.status == 200) {
                                Navigator.push(
                                  _scaffoldKey.currentContext!,
                                  MaterialPageRoute(
                                    builder: (_) => FormPage(
                                      categoryid: subcategoryList[index]["_id"],
                                    ),
                                  ),
                                );
                              } else {
                                ShowToast.showToast(
                                    _scaffoldKey.currentContext!,
                                    exception: "Kindly try again later");
                              }
                            },
                          );
                        }
                      },
                      child: Container(
                        decoration: BoxDecoration(
                          boxShadow: [
                            BoxShadow(
                              color: Colors.grey.withOpacity(0.3),
                              spreadRadius: 0.7,
                              blurRadius: 2,
                              offset:
                                  Offset(0, 0), // changes position of shadow
                            ),
                          ],
                          color: Colors.white,
                          borderRadius: BorderRadius.circular(5),
                        ),
                        child: ListTile(
                          title: Text(
                            subcategoryList[index]["name"]
                                .toString()
                                .capitalize(),
                            style: TextStyle(fontSize: 20),
                          ),
                        ),
                      ),
                    ),
                  );
                },
              ),
            ),
    );
  }
}
