import 'dart:io';
import 'package:app_settings/app_settings.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:geolocator/geolocator.dart';
import 'package:image_cropper/image_cropper.dart';
import 'package:image_picker/image_picker.dart';
import 'package:india/Common/color.dart';
import 'package:india/Common/custom_navigator.dart';
import 'package:india/Common/loading_bool.dart';
import 'package:india/Common/loading_widget.dart';
import 'package:india/Common/show_toast.dart';
import 'package:india/Widgets/Screens/Sell_Products/select_location.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:provider/provider.dart';

// ignore: must_be_immutable
class UploadProductImage extends StatefulWidget {
  String? productName;
  String? productPrice;
  String? productDescription;
  String? categoryid;
  Map<String, String> dynamicMap;

  UploadProductImage({
    required this.categoryid,
    required this.productName,
    required this.productPrice,
    required this.productDescription,
    required this.dynamicMap,
  });

  @override
  _UploadProductImageState createState() => _UploadProductImageState();
}

class _UploadProductImageState extends State<UploadProductImage> {
  final List<XFile> imageList = [];
  final ImagePicker _picker = ImagePicker();
  File? croppedFile;
  XFile? image;
  XFile? _image;
  bool _loading = false;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
        centerTitle: true,
        title: Text("Upload Product Photos"),
        backgroundColor: Color(0xFFF5F5F5),
        elevation: 2,
      ),
      body: _loading
          ? LoadingWidget()
          : imageList.isEmpty
              ? Container()
              : Padding(
                  padding: const EdgeInsets.all(5.0),
                  child: SingleChildScrollView(
                    child: GridView.builder(
                      shrinkWrap: true,
                      physics: ScrollPhysics(),
                      itemCount: imageList.length,
                      gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                          crossAxisCount: 3),
                      itemBuilder: (gridviewcontext, index) {
                        return Padding(
                          padding: const EdgeInsets.symmetric(horizontal: 4),
                          child: Stack(
                            children: [
                              Container(
                                color: Color(0xFFDBDBDB),
                                child: Align(
                                  alignment: Alignment.center,
                                  child: Image.file(
                                    File(imageList[index].path),
                                    fit: BoxFit.contain,
                                  ),
                                ),
                              ),
                              Align(
                                alignment: Alignment.topRight,
                                child: Transform.translate(
                                  offset: Offset(20, -15),
                                  child: IconButton(
                                    onPressed: () {
                                      // print(index);
                                      setState(() {
                                        imageList.removeAt(index);
                                      });
                                    },
                                    icon: Icon(
                                      Icons.cancel,
                                      color: colorBlue,
                                    ),
                                  ),
                                ),
                              ),
                            ],
                          ),
                        );
                      },
                    ),
                  ),
                ),
      floatingActionButton: FloatingActionButton(
        onPressed: () {
          showImageSource(context);
        },
        child: Icon(Icons.add_a_photo),
      ),
      bottomNavigationBar: BottomAppBar(
        color: Colors.white,
        elevation: 0,
        child: BoxCustomNavigatorButton.customContainer(
          context: context,
          boxName: "Next",
          onTap: () async {
            if (imageList.isNotEmpty) {
              if (imageList.length > 5) {
                ShowToast.showToast(context,
                    exception: "Kindly select only 5 pictures");
              } else {
                Provider.of<BoolLoader>(context, listen: false)
                    .boolLoader(status: false);
                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (_) => SelectProductLocation(
                      categoryid: widget.categoryid,
                      productName: widget.productName,
                      productPrice: widget.productPrice,
                      productDescription: widget.productDescription,
                      dynamicMap: widget.dynamicMap,
                      images: imageList,
                    ),
                  ),
                );
              }
              // else {
              //   getLocationPermission(context: context, size: size);
              // }
            } else {
              ShowToast.showToast(context, exception: "Kindly add 5 images");
            }
          },
        ),
      ),
    );
  }

  Future getLocationPermission({
    required BuildContext context,
    required Size size,
  }) async {
    bool serviceEnabled = await Geolocator.isLocationServiceEnabled();
    LocationPermission permission;
    if (!serviceEnabled) {
      showAlertDialog(
        context,
        size: size,
        title: "Your location service is disabled.",
        text1: "Enable",
        text2: "Cancel",
        onPressed1: () => AppSettings.openLocationSettings(),
      );
      return Future.error('Location services are disabled.');
    } else {
      permission = await Geolocator.checkPermission();
      print('Permission: $permission');
      if (permission == LocationPermission.denied ||
          permission == LocationPermission.deniedForever) {
        permission = await Geolocator.requestPermission();
        if (permission == LocationPermission.denied ||
            permission == LocationPermission.deniedForever) {
          showAlertDialog(
            context,
            size: size,
            title: "Kindly Provide location permisison.",
            text1: "Enable",
            text2: "Cancel",
            onPressed1: () => AppSettings.openAppSettings(),
          );
        } else {
          Provider.of<BoolLoader>(context, listen: false)
              .boolLoader(status: false);
          MaterialPageRoute(
            builder: (_) => SelectProductLocation(
              categoryid: widget.categoryid,
              productName: widget.productName,
              productPrice: widget.productPrice,
              productDescription: widget.productDescription,
              dynamicMap: widget.dynamicMap,
              images: imageList,
            ),
          );
        }
      } else if (permission == LocationPermission.whileInUse ||
          permission == LocationPermission.always) {
        Provider.of<BoolLoader>(context, listen: false)
            .boolLoader(status: false);
        Navigator.push(
          context,
          MaterialPageRoute(
            builder: (_) => SelectProductLocation(
              categoryid: widget.categoryid,
              productName: widget.productName,
              productPrice: widget.productPrice,
              productDescription: widget.productDescription,
              dynamicMap: widget.dynamicMap,
              images: imageList,
            ),
          ),
        );
      } else {
        return Future.error(
          'Location permissions are permanently denied, we cannot request permissions.',
        );
      }
    }
  }

  Future<ImageSource?> showImageSource(BuildContext context) {
    if (Platform.isAndroid) {
      return showModalBottomSheet(
        context: context,
        builder: (context) {
          return Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              ListTile(
                leading: Icon(
                  Icons.camera_alt,
                  color: Colors.black,
                ),
                title: Text('Camera'),
                onTap: () {
                  _cameraImage();
                  // print('Image file path: ${croppedFile?.path ?? 'Nothing'}');
                  Navigator.pop(context);
                },
              ),
              ListTile(
                leading: Icon(
                  Icons.image,
                  color: Colors.black,
                ),
                title: Text('Gallery'),
                onTap: () {
                  selectImage();
                  // print('Image file path: ${croppedFile?.path ?? 'Nothing'}');
                  Navigator.pop(context);
                },
              ),
            ],
          );
        },
      );
    } else {
      return showCupertinoModalPopup(
        context: context,
        builder: (context) {
          return CupertinoActionSheet(
            actions: [
              CupertinoActionSheetAction(
                onPressed: () {
                  _cameraImage();
                  // print('Image file path: ${croppedFile?.path ?? 'Nothing'}');
                  Navigator.pop(context);
                },
                child: Text('Camera'),
              ),
              CupertinoActionSheetAction(
                onPressed: () async {
                  selectImage();
                  // print('Image file path: ${croppedFile?.path ?? 'Nothing'}');
                  Navigator.pop(context);
                },
                child: Text('Gallery'),
              ),
            ],
          );
        },
      );
    }
  }

  void selectImage() async {
    var galleryStatus = await Permission.photos.status;
    if (galleryStatus.isGranted) {
      final List<XFile>? _selectedImages = await _picker.pickMultiImage(
        imageQuality: 85,
        // maxHeight: 1000,
        // maxWidth: 1000,
      );
      // print(_selectedImages?.length ?? 0);
      if (_selectedImages!.isNotEmpty) {
        for (int i = 0; i < _selectedImages.length; i++) {
          croppedFile =
              await ImageCropper.cropImage(sourcePath: _selectedImages[i].path);
          if (croppedFile != null) {
            setState(() {
              // final bytes = croppedFile!.readAsBytesSync().lengthInBytes;
              // final kb = bytes / 1024;
              // final mb = kb / 1024;
              _image = XFile(croppedFile!.path);
              imageList.add(_image!);
              // print('Image file path: $_image');
            });
          }
        }
      }
      // print("Image list: ${imageList.length}");
    } else if (galleryStatus.isDenied) {
      ShowToast.showToast(context,
          exception: "Kindly enable permission to upload image");
      galleryStatus = await Permission.storage.request();
      if (galleryStatus.isGranted) {
        final List<XFile>? _selectedImages = await _picker.pickMultiImage(
          imageQuality: 85,
          // maxHeight: 1000,
          // maxWidth: 1000,
        );
        // print(_selectedImages?.length ?? 0);
        if (_selectedImages!.isNotEmpty) {
          for (int i = 0; i < _selectedImages.length; i++) {
            croppedFile = await ImageCropper.cropImage(
                sourcePath: _selectedImages[i].path);
            if (croppedFile != null) {
              setState(() {
                _image = XFile(croppedFile!.path);
                imageList.add(_image!);
                // print('Image file path: $_image');
              });
            }
          }
        }
        // print("Image list: ${imageList.length}");
      } else {
        await openAppSettings();
      }
    } else {
      await openAppSettings();
    }
  }

  void _cameraImage() async {
    var cameraStatus = await Permission.camera.status;
    // print(cameraStatus);
    if (cameraStatus.isGranted) {
      image = await _picker.pickImage(
        source: ImageSource.camera,
        imageQuality: 85,
        // maxHeight: 1000,
        // maxWidth: 1000,
      );
      croppedFile = await ImageCropper.cropImage(sourcePath: image?.path ?? '');
      if (croppedFile != null) {
        setState(() {
          _image = XFile(croppedFile!.path);
          imageList.add(_image!);
          // print("size: ${croppedFile!.readAsBytesSync().lengthInBytes}");
          // print('Image file path: $_image');
        });
      }
    } else if (cameraStatus.isDenied) {
      cameraStatus = await Permission.camera.request();
      if (cameraStatus.isGranted) {
        image = await _picker.pickImage(
          source: ImageSource.camera,
          imageQuality: 85,
          // maxHeight: 1000,
          // maxWidth: 1000,
        );
        croppedFile =
            await ImageCropper.cropImage(sourcePath: image?.path ?? '');
        if (croppedFile != null) {
          setState(() {
            _image = XFile(croppedFile!.path);
            imageList.add(_image!);
            // print('Image file path: $_image');
          });
          // Provider.of<SetPicture>(context, listen: false)
          //     .setPicture(authtoken: _authToken!, image: _image!);
        }
      } else {
        await openAppSettings();
      }
    } else {
      await openAppSettings();
    }
  }

  Future showAlertDialog(
    BuildContext context, {
    required Size size,
    required String title,
    required String text1,
    required String text2,
    required VoidCallback onPressed1,
  }) async {
    if (Platform.isAndroid) {
      return showDialog(
        barrierDismissible: true,
        context: context,
        builder: (context) => AlertDialog(
          title: Text(
            title,
            style: TextStyle(fontSize: size.height * 0.015),
          ),
          actions: <Widget>[
            // ignore: deprecated_member_use
            FlatButton(
              child: Text(
                text1,
                style: TextStyle(
                  fontSize: size.height * 0.015,
                  color: Colors.red,
                ),
              ),
              onPressed: onPressed1,
            ),
            // ignore: deprecated_member_use
            FlatButton(
              child: Text(
                text2,
                style: TextStyle(
                  fontSize: size.height * 0.015,
                  // color: colorBlue,
                ),
              ),
              onPressed: () => Navigator.of(context).pop(),
            ),
          ],
        ),
      );
    } else {
      // todo : showDialog for ios
      return showCupertinoDialog(
        barrierDismissible: true,
        context: context,
        builder: (context) => CupertinoAlertDialog(
          title: Text(title),
          actions: <Widget>[
            CupertinoDialogAction(
              child: Text(text1),
              onPressed: onPressed1,
            ),
            CupertinoDialogAction(
              child: Text(text2),
              onPressed: () => Navigator.of(context).pop(),
            ),
          ],
        ),
      );
    }
  }
}
