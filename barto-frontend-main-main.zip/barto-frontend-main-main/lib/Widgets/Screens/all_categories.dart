import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:india/Common/loading_bool.dart';
import 'package:india/Common/loading_widget.dart';
import 'package:india/Services/domain.dart';
import 'package:india/Services/get_home.dart';
import 'package:india/Widgets/Screens/string_extension.dart';
import 'package:india/Widgets/Screens/subCat_products.dart';
import 'package:provider/provider.dart';

// ignore: must_be_immutable
class AllCategories extends StatelessWidget {
  String authtoken;
  String countryname;
  String statename;
  String cityname;
  String areaname;
  AllCategories({
    required this.authtoken,
    required this.countryname,
    required this.statename,
    required this.cityname,
    required this.areaname,
  });

  @override
  Widget build(BuildContext context) {
    final orientation = MediaQuery.of(context).orientation;
    bool _loading = Provider.of<BoolLoader>(context).loadingStatus;
    List _categoryinfo = Provider.of<GetHome>(context).categoryList;
    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
        centerTitle: true,
        backgroundColor: Color(0xFFF9F9F9),
        elevation: 2,
        title: Text("All Categories"),
      ),
      body: _loading
          ? LoadingWidget()
          : Container(
              margin: EdgeInsets.only(top: 10),
              child: GridView.builder(
                itemCount: _categoryinfo.length,
                gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                  childAspectRatio: MediaQuery.of(context).size.width /
                      (MediaQuery.of(context).size.height / 2.4),
                  crossAxisCount: (orientation == Orientation.portrait) ? 3 : 4,
                ),
                itemBuilder: (BuildContext gridviewcontext, int index) {
                  return InkWell(
                    onTap: () {
                      Provider.of<BoolLoader>(context, listen: false)
                          .boolLoader(status: false);
                      Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (_) => SubCatProducts(
                            subcategoryList: _categoryinfo[index]["subcats"],
                            authtoken: authtoken,
                            countryname: countryname,
                            statename: statename,
                            cityname: cityname,
                            areaname: areaname,
                          ),
                        ),
                      );
                    },
                    child: Column(
                      children: [
                        Flexible(
                          flex: 1,
                          fit: FlexFit.tight,
                          child: Padding(
                            padding: const EdgeInsets.symmetric(
                                horizontal: 10, vertical: 10),
                            child: Container(
                              width: MediaQuery.of(context).size.width / 5,
                              decoration: BoxDecoration(
                                borderRadius: BorderRadius.circular(10),
                                color: Colors.white,
                                boxShadow: [
                                  BoxShadow(
                                    color: Colors.grey.withOpacity(0.3),
                                    spreadRadius: 0.7,
                                    blurRadius: 2,
                                    offset: Offset(0, 0),
                                  ),
                                ],
                              ),
                              child: Padding(
                                padding: const EdgeInsets.all(3),
                                child: Container(
                                  child: _categoryinfo[index]["cat_img_url"] ==
                                          null
                                      ? Icon(
                                          Icons.collections,
                                          size: 30,
                                          color: Colors.grey,
                                        )
                                      : SvgPicture.network(
                                          "${Domain.url}${_categoryinfo[index]["cat_img_url"]}",
                                        ),
                                ),
                              ),
                            ),
                          ),
                        ),
                        Padding(
                          padding: const EdgeInsets.only(bottom: 5),
                          child: Text(
                            "${_categoryinfo[index]["name"]}".capitalize(),
                            style: TextStyle(
                              fontSize: 13,
                              fontWeight: FontWeight.w500,
                            ),
                          ),
                        ),
                      ],
                    ),
                  );
                },
              ),
            ),
    );
  }
}


/*

CustomScrollView(
        slivers: [
          SliverAppBar(
            leading: Container(),
            backgroundColor: Color(0xFFF9F9F9),
            expandedHeight: 140.0,
            flexibleSpace: Column(
              children: [
                Flexible(
                  flex: 1,
                  fit: FlexFit.loose,
                  child: Padding(
                    padding: const EdgeInsets.only(top: 20),
                    child: SafeArea(
                      child: InkWell(
                          onTap: () {},
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              Padding(
                                padding: const EdgeInsets.only(left: 10),
                                child: Row(
                                  children: [
                                    Icon(
                                      Icons.location_on,
                                      color: Color(0xFF30BFFD),
                                      size: 25,
                                    ),
                                    SizedBox(width: 10),
                                    Text(
                                      'Location',
                                      style: TextStyle(
                                        fontSize: 18,
                                        color: Colors.black,
                                        fontWeight: FontWeight.w500,
                                      ),
                                    ),
                                    Icon(
                                      Icons.expand_more,
                                      color: Color(0xFF30BFFD),
                                      size: 25,
                                    ),
                                  ],
                                ),
                              ),
                              Padding(
                                padding: const EdgeInsets.only(right: 15),
                                child: Icon(
                                  Icons.notifications,
                                  color: Color(0xFF30BFFD),
                                  size: 25,
                                ),
                              ),
                            ],
                          )),
                    ),
                  ),
                ),
                SizedBox(height: 20),
                Container(
                  width: MediaQuery.of(context).size.width / 1.1,
                  height: 50,
                  decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.circular(10),
                  ),
                  child: Padding(
                    padding: const EdgeInsets.only(left: 15),
                    child: DropdownSearch<String>(
                      selectedItem: _selectedCustomer,
                      items: items,
                      showSearchBox: true,
                      dropDownButton: Container(),
                      dropdownSearchDecoration: InputDecoration(
                        border: InputBorder.none,
                        suffixIcon:
                            Icon(Icons.search, color: Color(0xFF30BFFD)),
                      ),
                      onChanged: (String? value) {
                        setState(() {
                          _selectedCustomer = value!;
                        });
                      },
                    ),
                  ),
                ),
              ],
            ),
          ),
          SliverToBoxAdapter(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Padding(
                  padding: const EdgeInsets.only(left: 20),
                  child: Text(
                    'Categories',
                    style: TextStyle(fontSize: 18),
                  ),
                ),
                GridView.builder(
                  shrinkWrap: true,
                  physics: ScrollPhysics(),
                  itemCount: 20,
                  padding: EdgeInsets.all(10),
                  gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                      childAspectRatio: 1,
                      // childAspectRatio: (size.height < 700.0)
                      //     ? 0.85
                      //     : (size.height > 700.0 && size.height < 900.0)
                      //         ? 0.85
                      //         : 1.1,
                      crossAxisCount:
                          (orientation == Orientation.portrait) ? 3 : 4),
                  itemBuilder: (BuildContext context, int index) {
                    return Column(
                      children: [
                        Padding(
                          padding: const EdgeInsets.symmetric(
                              horizontal: 10, vertical: 10),
                          child: Material(
                            borderRadius: BorderRadius.circular(10),
                            elevation: 2,
                            child: Container(
                              width: 80,
                              height: 80,
                              decoration: BoxDecoration(
                                // border: Border.all(),
                                borderRadius: BorderRadius.circular(10),
                              ),
                              child: Padding(
                                padding: const EdgeInsets.all(15),
                                child: Icon(Icons.car_rental, size: 50),
                              ),
                            ),
                          ),
                        ),
                        Text(
                          'Categories',
                          style: TextStyle(fontSize: 15),
                        ),
                      ],
                    );
                  },
                ),
              ],
            ),
          ),
        ],
      ),

*/