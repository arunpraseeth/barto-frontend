import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:india/Common/color.dart';
import 'package:india/Common/loading_bool.dart';
import 'package:india/Widgets/Authentication/Signin/login_bottommodal.dart';
import 'package:india/Widgets/Screens/chat_screen.dart';
import 'package:india/Widgets/Screens/home_page.dart';
import 'package:india/Widgets/Screens/My%20Posts/my_post.dart';
import 'package:india/Widgets/Screens/Profile/profile_screen.dart';
import 'package:india/Widgets/Screens/Sell_Products/sell_product.dart';
import 'package:provider/provider.dart';
import 'package:shared_preferences/shared_preferences.dart';

// ignore: must_be_immutable
class CustomBottomNavBar extends StatefulWidget {
  int chooseIndex;
  CustomBottomNavBar({required this.chooseIndex});
  @override
  _CustomBottomNavBarState createState() => _CustomBottomNavBarState();
}

class _CustomBottomNavBarState extends State<CustomBottomNavBar> {
  GlobalKey<ScaffoldState> _scaffoldKey = GlobalKey();

  String? authtoken;
  String userId = '';
  bool shouldPop = false;
  LoginModalSheet loginModalSheet = LoginModalSheet();

  @override
  void initState() {
    getAuthtoken();
    super.initState();
  }

  getAuthtoken() async {
    SharedPreferences sharedPreferences = await SharedPreferences.getInstance();
    authtoken = sharedPreferences.getString('authtoken');
    // print('Authtoken: $authtoken');
    return authtoken;
  }

  List pages = [
    HomeScreen(),
    ChatHome(),
    SellProduct(),
    MyPost(),
    ProfileScreen(),
  ];

  @override
  Widget build(BuildContext context) {
    bool keyboardIsOpened = MediaQuery.of(context).viewInsets.bottom != 0.0;
    Size size = MediaQuery.of(context).size;
    return WillPopScope(
      onWillPop: () async {
        return shouldPop;
      },
      child: Scaffold(
        // resizeToAvoidBottomInset: false,
        key: _scaffoldKey,
        body: pages[widget.chooseIndex],
        floatingActionButton: keyboardIsOpened
            ? Container()
            : Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  SizedBox(height: 15),
                  Container(
                    width: size.height * 0.08,
                    height: size.height * 0.08,
                    child: FloatingActionButton(
                      onPressed: () {
                        Provider.of<BoolLoader>(context, listen: false)
                            .boolLoader(status: false);
                        if (authtoken == null) {
                          loginModalSheet.bottomModalSheet(context: context);
                        } else {
                          setState(() {
                            widget.chooseIndex = 2;
                          });
                        }
                      },
                      backgroundColor: Colors.white,
                      elevation: 2,
                      child: SvgPicture.asset(
                        'assets/navbar/sell.svg',
                        height: size.height * 0.045,
                      ),
                    ),
                  ),
                  SizedBox(height: 11),
                  Text(
                    'Post Ad',
                    style: TextStyle(
                      fontSize: size.width * 0.031,
                      fontWeight: FontWeight.w500,
                    ),
                  ),
                ],
              ),
        floatingActionButtonLocation: FloatingActionButtonLocation.centerDocked,
        bottomNavigationBar: BottomAppBar(
          color: Color(0xFFF9F9F9),
          child: Container(
            height: size.height / 14,
            decoration: BoxDecoration(
              color: Color(0xFFF9F9F9),
              boxShadow: [
                BoxShadow(
                  color: Colors.grey.withOpacity(0.6),
                  // spreadRadius: 1,
                  blurRadius: 1,
                  offset: Offset(0, -2),
                  // changes position of shadow
                ),
              ],
            ),
            child: Center(
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                children: [
                  // SizedBox(width: 5),
                  InkWell(
                    onTap: () {
                      setState(() {
                        widget.chooseIndex = 0;
                      });
                    },
                    child: Column(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Container(
                          width: 50,
                          child: widget.chooseIndex == 0
                              ? SvgPicture.asset(
                                  'assets/navbar/fill/home.svg',
                                  height: size.height / 35,
                                  // height: 25,
                                  color: colorBlue,
                                )
                              : SvgPicture.asset(
                                  'assets/navbar/stroke/home.svg',
                                  height: size.height / 35,
                                  // height: 25,
                                  color: colorBlue,
                                ),
                        ),
                        SizedBox(height: 6),
                        Text(
                          'Home',
                          style: TextStyle(
                            fontSize: size.width * 0.031,
                            fontWeight: FontWeight.w500,
                          ),
                        ),
                      ],
                    ),
                  ),
                  SizedBox(width: 10),
                  InkWell(
                    onTap: () {
                      Provider.of<BoolLoader>(context, listen: false)
                          .boolLoader(status: false);
                      if (authtoken == null) {
                        loginModalSheet.bottomModalSheet(context: context);
                      } else {
                        setState(() {
                          widget.chooseIndex = 1;
                        });
                      }
                    },
                    child: Column(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Container(
                          width: 50,
                          child: widget.chooseIndex == 1
                              ? SvgPicture.asset(
                                  'assets/navbar/fill/chat.svg',
                                  height: size.height / 35,
                                  // height: 25,
                                  color: colorBlue,
                                )
                              : SvgPicture.asset(
                                  'assets/navbar/stroke/chat.svg',
                                  height: size.height / 35,
                                  // height: 25,
                                  color: colorBlue,
                                ),
                        ),
                        SizedBox(height: 6),
                        Text(
                          'Chat',
                          style: TextStyle(
                            fontSize: size.width * 0.031,
                            fontWeight: FontWeight.w500,
                          ),
                        ),
                      ],
                    ),
                  ),
                  SizedBox(width: 10),
                  Container(
                    width: 50,
                  ),
                  SizedBox(width: 10),
                  InkWell(
                    onTap: () {
                      Provider.of<BoolLoader>(context, listen: false)
                          .boolLoader(status: false);
                      if (authtoken == null) {
                        loginModalSheet.bottomModalSheet(context: context);
                      } else {
                        setState(() {
                          widget.chooseIndex = 3;
                        });
                      }
                    },
                    child: Column(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Container(
                          width: 50,
                          child: widget.chooseIndex == 3
                              ? SvgPicture.asset(
                                  'assets/navbar/fill/mypost.svg',
                                  // height: 25,
                                  height: size.height / 35,
                                  color: colorBlue,
                                )
                              : SvgPicture.asset(
                                  'assets/navbar/stroke/mypost.svg',
                                  height: size.height / 35,
                                  // height: 25,
                                  color: colorBlue,
                                ),
                        ),
                        SizedBox(height: 6),
                        Text(
                          'My Post',
                          style: TextStyle(
                            fontSize: size.width * 0.031,
                            fontWeight: FontWeight.w500,
                          ),
                        ),
                      ],
                    ),
                  ),
                  SizedBox(width: 10),
                  InkWell(
                    onTap: () {
                      setState(() {
                        widget.chooseIndex = 4;
                      });
                    },
                    child: Column(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Container(
                          width: 50,
                          child: widget.chooseIndex == 4
                              ? SvgPicture.asset(
                                  'assets/navbar/fill/profile.svg',
                                  height: size.height / 35,
                                  // height: 25,
                                  color: colorBlue,
                                )
                              : SvgPicture.asset(
                                  'assets/navbar/stroke/profile.svg',
                                  height: size.height / 35,
                                  // height: 25,
                                  color: colorBlue,
                                ),
                        ),
                        SizedBox(height: 6),
                        Text(
                          'Profile',
                          style: TextStyle(
                            fontSize: size.width * 0.031,
                            fontWeight: FontWeight.w500,
                          ),
                        ),
                      ],
                    ),
                  ),
                  // SizedBox(width: 5),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}
