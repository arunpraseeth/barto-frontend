import 'dart:io';
import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:india/Common/loading_bool.dart';
import 'package:india/Services/chat_firestore.dart';
import 'package:india/Services/domain.dart';
import 'package:india/Services/seller_details.dart';
import 'package:india/Services/user_data.dart';
import 'package:india/Widgets/Screens/Profile/blocked_user.dart';
import 'package:india/Widgets/Screens/conversation_screen.dart';
import 'package:provider/provider.dart';
import "string_extension.dart";

// ignore: must_be_immutable
class ChatHome extends StatelessWidget {
  String? name;
  String userId = '';
  String chatsellerId = '';
  List chatListUserId = [];
  List blockedUsers = [];
  List blockeduserName = [];
  List chatListAvatar = [];
  ChatFirestore chatFirestore = ChatFirestore();

  @override
  Widget build(BuildContext context) {
    String authtoken = Provider.of<UserData>(context).authtoken;
    Size size = MediaQuery.of(context).size;
    chatFirestore.getChatList(userId: userId);
    userId = Provider.of<UserData>(context).userId;
    chatListUserId = Provider.of<ChatFirestore>(context).chatListUserId;
    chatsellerId = Provider.of<ChatFirestore>(context).chatsellerId;
    List chatroomUserid = Provider.of<ChatFirestore>(context).chatListUserId;
    Map<String, String> mapchatroomid =
        Provider.of<ChatFirestore>(context).mapchatroomId;
    List chatListFullName =
        Provider.of<ChatFirestore>(context).chatListFullName;
    List chatListUserName =
        Provider.of<ChatFirestore>(context).chatListUserName;

    if (Provider.of<UserData>(context).blockedUsersList.isNotEmpty) {
      blockedUsers = Provider.of<UserData>(context).blockedUsersList;
      for (var users in blockedUsers) {
        blockeduserName.add(users["user_name"]);
      }
    }
    if (Provider.of<ChatFirestore>(context).chatListAvatar.isNotEmpty) {
      chatListAvatar = Provider.of<ChatFirestore>(context).chatListAvatar;
    }
    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
        elevation: 2,
        backgroundColor: Color(0xFFF9F9F9),
        title: Text('Chat'),
        centerTitle: true,
        leading: Container(),
      ),
      body: Container(
        margin: EdgeInsets.symmetric(vertical: 10, horizontal: 10),
        child: chatListFullName.length > 0
            ? ListView.builder(
                itemCount: chatListFullName.length,
                itemBuilder: (listviewcontext, index) {
                  // print("chatListFullName: ${chatListFullName.length}");
                  return Padding(
                    padding: const EdgeInsets.only(bottom: 10),
                    child: Container(
                      height: size.height * 0.085,
                      decoration: BoxDecoration(
                        boxShadow: [
                          BoxShadow(
                            color: Colors.grey.withOpacity(0.5),
                            spreadRadius: 0.7,
                            blurRadius: 2,
                            offset: Offset(0, 0), // changes position of shadow
                          ),
                        ],
                        color: Colors.white,
                        borderRadius: BorderRadius.circular(5),
                      ),
                      child: Center(
                        child: ListTile(
                          onTap: () {
                            Provider.of<BoolLoader>(context, listen: false)
                                .boolLoader(status: false);
                            // print("chatListUserId[index]: ${chatListUserId[index]}");
                            // print("userId: $userId");
                            // print("chatlistuserid: ${chatListUserId[index]}");
                            // print("sellerid: $chatsellerId");
                            // print(Provider.of<ChatFirestore>(context,listen: false).chatListUserName[index]);
                            // print("fullname: ${Provider.of<ChatFirestore>(context, listen: false).chatListFullName[index]}");
                            if (blockedUsers.isNotEmpty) {
                              // print(chatListUserName[index]);
                              // print(blockeduserName.contains(chatListUserName[index]));
                              if (blockeduserName
                                  .contains(chatListUserName[index])) {
                                // print("blocked user");
                                showAlertDialog(
                                  context,
                                  authtoken: authtoken,
                                  // userName: blockedUsers[index]["user_name"],
                                );
                              } else {
                                Provider.of<SellerDetails>(context,
                                        listen: false)
                                    .getsellerDetails(
                                  username: chatListUserName[index],
                                  authtoken: authtoken,
                                )
                                    .then(
                                  (value) {
                                    if (value["status"] == 200) {
                                      Navigator.push(
                                        context,
                                        MaterialPageRoute(
                                          builder: (_) => ConversationScreen(
                                            personName: chatListFullName[index],
                                            personAvatar: chatListAvatar[index],
                                            username: chatListUserName[index],
                                            mapchatroomlist:
                                                chatListUserId[index],
                                            chatlistuserId:
                                                chatListUserId[index],
                                            sellerid: chatsellerId,
                                            myid: userId,
                                            chatroomUserid: chatroomUserid,
                                            mapchatroomid: mapchatroomid,
                                            // userId2: chatListUserId[index],
                                          ),
                                        ),
                                      );
                                    } else if (value["status"] == 400 &&
                                        value["error"]["message"] ==
                                            "You are blocked by this user. So you can't view this profile") {
                                      blockedAlertDialog(context);
                                    }
                                  },
                                );
                              }
                            } else {
                              Provider.of<SellerDetails>(context, listen: false)
                                  .getsellerDetails(
                                username: chatListUserName[index],
                                authtoken: authtoken,
                              )
                                  .then(
                                (value) {
                                  if (value["status"] == 200) {
                                    Navigator.push(
                                      context,
                                      MaterialPageRoute(
                                        builder: (_) => ConversationScreen(
                                          personName: chatListFullName[index],
                                          personAvatar: chatListAvatar[index],
                                          username: chatListUserName[index],
                                          mapchatroomlist:
                                              chatListUserId[index],
                                          chatlistuserId: chatListUserId[index],
                                          sellerid: chatsellerId,
                                          myid: userId,
                                          chatroomUserid: chatroomUserid,
                                          mapchatroomid: mapchatroomid,
                                          // userId2: chatListUserId[index],
                                        ),
                                      ),
                                    );
                                  } else if (value["status"] == 400 &&
                                      value["error"]["message"] ==
                                          "You are blocked by this user. So you can't view this profile") {
                                    blockedAlertDialog(context);
                                  }
                                },
                              );
                            }
                          },
                          leading: chatListAvatar[index].isEmpty
                              ? CircleAvatar(
                                  backgroundColor: Colors.grey[200],
                                  radius: 32,
                                  child: ClipOval(
                                    child: SizedBox(
                                      child: AspectRatio(
                                        aspectRatio: 1 / 1,
                                        child: Image.asset(
                                            'assets/barto_logo.png'),
                                      ),
                                    ),
                                  ),
                                )
                              : CircleAvatar(
                                  backgroundColor: Colors.grey[200],
                                  radius: 32,
                                  child: ClipOval(
                                    child: SizedBox(
                                      child: AspectRatio(
                                        aspectRatio: 1 / 1,
                                        child: CachedNetworkImage(
                                          fit: BoxFit.cover,
                                          imageUrl:
                                              "${Domain.url}${chatListAvatar[index]}",
                                          placeholder: (context, url) =>
                                              new CircularProgressIndicator(),
                                          errorWidget: (context, url, error) =>
                                              new Icon(Icons.error),
                                        ),
                                      ),
                                    ),
                                  ),
                                ),
                          title: Text.rich(
                            TextSpan(
                              children: [
                                TextSpan(
                                  text:
                                      "${chatListFullName[index]}".capitalize(),
                                  style: TextStyle(
                                    fontSize: 20,
                                    fontWeight: FontWeight.bold,
                                  ),
                                ),
                                TextSpan(
                                  text: '\n@${chatListUserName[index]}',
                                  style: TextStyle(
                                    fontSize: 18,
                                    fontWeight: FontWeight.w500,
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),
                      ),
                    ),
                  );
                },
              )
            : Center(
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Padding(
                      padding: const EdgeInsets.symmetric(horizontal: 15),
                      child: SvgPicture.asset(
                        "assets/placeholders/nomessage.svg",
                        height: 250,
                      ),
                    ),
                    SizedBox(height: 20),
                    Text(
                      'No chats available.',
                      style: TextStyle(
                        fontSize: 18,
                      ),
                    ),
                  ],
                ),
              ),
      ),
    );
  }

  showAlertDialog(
    BuildContext context, {
    required String authtoken,
    // required String userName,
  }) {
    // set up the button
    if (Platform.isAndroid) {
      Widget cancelButton = TextButton(
        child: Text(
          "Cancel",
          style: TextStyle(color: Colors.black, fontSize: 18),
        ),
        onPressed: () {
          Navigator.of(context).pop();
        },
      );
      Widget unblockButton = TextButton(
        child: Text(
          "Unblock",
          style: TextStyle(color: Colors.red, fontSize: 18),
        ),
        onPressed: () {},
      );

      // set up the AlertDialog
      AlertDialog alert = AlertDialog(
        title: Text("You have blocked this user."),
        // content: Text("This is my message."),
        actions: [cancelButton, unblockButton],
      );

      // show the dialog
      showDialog(
        context: context,
        builder: (BuildContext context) {
          return alert;
        },
      );
    } else {
      return showCupertinoDialog(
        context: context,
        builder: (context) => CupertinoAlertDialog(
          title: Text("You have blocked this user."),
          actions: <Widget>[
            CupertinoDialogAction(
              child: Text("Cancel"),
              onPressed: () => Navigator.of(context).pop(false),
            ),
            CupertinoDialogAction(
              child: Text(
                "Unblock",
                style: TextStyle(color: Colors.red),
              ),
              onPressed: () {
                // UserData.unblockUsers(
                //   authtoken: authtoken,
                //   userName: userName,
                // );
                Navigator.of(context).push(
                  MaterialPageRoute(
                    builder: (_) => BlockedUsers(
                      authtoken: authtoken,
                      routeNumber: 0,
                    ),
                  ),
                );
              },
            ),
          ],
        ),
      );
    }
  }

  blockedAlertDialog(BuildContext context) {
    // set up the button
    if (Platform.isAndroid) {
      // set up the AlertDialog
      AlertDialog alert = AlertDialog(
        title: Text("You are blocked by this user. So you cannot chat."),
      );

      // show the dialog
      showDialog(
        barrierDismissible: true,
        context: context,
        builder: (BuildContext context) {
          return alert;
        },
      );
    } else {
      return showCupertinoDialog(
        barrierDismissible: true,
        context: context,
        builder: (context) => CupertinoAlertDialog(
          title: Text(
            "You are blocked by this user. So you cannot chat.",
          ),
        ),
      );
    }
  }
}
