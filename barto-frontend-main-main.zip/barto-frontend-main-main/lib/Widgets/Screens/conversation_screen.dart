import 'package:cached_network_image/cached_network_image.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:india/Common/color.dart';
import 'package:india/Common/loading_bool.dart';
import 'package:india/Common/loading_widget.dart';
import 'package:india/Common/show_toast.dart';
import 'package:india/Model/location.dart';
import 'package:india/Model/shared_pref.dart';
import 'package:india/Services/chat_firestore.dart';
import 'package:india/Services/domain.dart';
import 'package:india/Services/get_home.dart';
import 'package:india/Services/seller_details.dart';
import 'package:india/Services/user_data.dart';
import 'package:india/Widgets/Screens/bottom_navbar.dart';
import 'package:india/Widgets/Screens/seller_profile.dart';
import 'package:provider/provider.dart';
import 'package:shared_preferences/shared_preferences.dart';

// ignore: must_be_immutable
class ConversationScreen extends StatefulWidget {
  String myid = '';
  String username = '';
  String sellerid = '';
  String mapchatroomlist = '';
  String? productId = '';
  String? chatlistuserId = '';
  String personName = '';
  String personAvatar = '';
  List chatroomUserid = [];
  Map<String, String> mapchatroomid = {};
  ConversationScreen({
    this.productId,
    this.chatlistuserId,
    required this.myid,
    required this.username,
    required this.sellerid,
    required this.personName,
    required this.personAvatar,
    required this.chatroomUserid,
    required this.mapchatroomlist,
    required this.mapchatroomid,
  });
  @override
  State<ConversationScreen> createState() => _ConversationScreenState();
}

class _ConversationScreenState extends State<ConversationScreen> {
  GlobalKey<ScaffoldState> _scaffoldKey = GlobalKey();
  TextEditingController messageController = TextEditingController();
  Stream<QuerySnapshot<Map<String, dynamic>>>? chatmessageStream;
  String? authToken;

  // ignore: unused_field

  Future<String> getAuthToken() async {
    SharedPreferences sharedPreferences = await SharedPreferences.getInstance();
    authToken = sharedPreferences.getString("authtoken");
    // print('Auth token: $authToken');
    return authToken ?? '';
  }

  getchatmessages() {
    // print("chatroomuserid: ${widget.chatroomUserid}");
    // print(
    //     "checking mapchatroomlist/sellerid in mapchatroom id: ${widget.mapchatroomid[widget.mapchatroomlist]}");
    // print(
    //     "containing check mapchatroomlist in chatroomuserid: ${widget.chatroomUserid.contains(widget.mapchatroomlist)}");
    // print("my id == seller id: ${widget.myid != widget.sellerid}");
    // print("mapchatroomid: ${widget.mapchatroomid}");
    // print("mapchatroom list ${widget.mapchatroomlist}");
    // print("seller id: ${widget.sellerid}");
    setState(() {
      // Checking for previous chats id
      if (widget.chatroomUserid.isEmpty) {
        // print(
        //     "1${widget.myid != widget.sellerid ? "${widget.myid}_${widget.sellerid}" : "${widget.chatlistuserId}_${widget.myid}"}");
        chatmessageStream = FirebaseFirestore.instance
            .collection("chatroom")
            .doc(widget.myid != widget.sellerid
                ? "${widget.myid}_${widget.sellerid}"
                : "${widget.chatlistuserId}_${widget.myid}")
            .collection("messages")
            .orderBy("timestamp", descending: true)
            .snapshots();
      } else {
        // Checking for chatroomuserid contains mapchatroomlist/sellerid
        if (widget.chatroomUserid.contains(widget.mapchatroomlist)) {
          // print("2: ${widget.mapchatroomid[widget.mapchatroomlist]}");
          chatmessageStream = FirebaseFirestore.instance
              .collection("chatroom")
              .doc(widget.mapchatroomid[widget.mapchatroomlist])
              .collection("messages")
              .orderBy("timestamp", descending: true)
              .snapshots();
        } else {
          // If nothing is found and this is going to be a new chat then initiate a new chatroom id.
          // print(
          //     "3: ${widget.myid != widget.sellerid ? "${widget.myid}_${widget.sellerid}" : "${widget.chatlistuserId}_${widget.myid}"}");
          chatmessageStream = FirebaseFirestore.instance
              .collection("chatroom")
              .doc(widget.myid != widget.sellerid
                  ? "${widget.myid}_${widget.sellerid}"
                  : "${widget.chatlistuserId}_${widget.myid}")
              .collection("messages")
              .orderBy("timestamp", descending: true)
              .snapshots();
        }
      }
    });
    if (chatmessageStream != null) {
      chatmessageStream!.forEach((field) {
        // print(field.docs.length);
        if (field.docs.length == 0) {
          bottomModalSheet();
        }
      });
    }
  }

  @override
  void initState() {
    getAuthToken();
    GetStoredInfo.getStoreInfo();
    getchatmessages();
    super.initState();
  }

  bool _lsd = false;
  @override
  Widget build(BuildContext context) {
    String latitude = Provider.of<StoreLocation>(context).latitude.toString();
    String longitude = Provider.of<StoreLocation>(context).longitude.toString();
    bool followStatus = Provider.of<SellerDetails>(context).followOrUnfollow;
    // print("Userid: ${widget.myid}");
    // _personName = Provider.of<ChatFirestore>(context).username.toString();
    // _personAvatar = Provider.of<ChatFirestore>(context).avatar.toString();
    return Scaffold(
      key: _scaffoldKey,
      backgroundColor: Colors.white,
      appBar: PreferredSize(
        preferredSize: Size.fromHeight(MediaQuery.of(context).size.height / 11),
        child: AppBar(
          elevation: 2,
          centerTitle: true,
          backgroundColor: Color(0xFFF5F5F5),
          // ignore: deprecated_member_use
          brightness:
              Brightness.light, // this makes status bar text color black
          toolbarHeight: MediaQuery.of(context).size.height / 7,
          title: GestureDetector(
            onTap: () {
              // Provider.of<BoolLoader>(context, listen: false)
              //     .boolLoader(status: true);
              setState(() {
                _lsd = true;
              });
              Provider.of<SellerDetails>(context, listen: false)
                  .getsellerDetails(
                authtoken: authToken,
                username: widget.username,
              )
                  .then((value) {
                setState(() {
                  _lsd = false;
                });
                Provider.of<BoolLoader>(context, listen: false)
                    .boolLoader(status: false);
                if (value["status"] == 200) {
                  Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (_) => SellerProfile(),
                    ),
                  );
                } else {
                  ShowToast.showToast(context,
                      exception: "Kindly try again later");
                }
              });
            },
            child: Transform.translate(
              offset: Offset(-15, 0),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.start,
                children: [
                  widget.personAvatar.isEmpty
                      ? CircleAvatar(
                          backgroundColor: colorBlue.withOpacity(0.5),
                          radius: 25,
                          child: ClipOval(
                            child: SizedBox(
                              child: AspectRatio(
                                aspectRatio: 1 / 1,
                                child: Image.asset('assets/barto_logo.png'),
                              ),
                            ),
                          ),
                        )
                      : CircleAvatar(
                          backgroundColor: Colors.grey[200],
                          radius: 25,
                          child: ClipOval(
                            child: SizedBox(
                              child: AspectRatio(
                                aspectRatio: 1 / 1,
                                child: CachedNetworkImage(
                                  fit: BoxFit.cover,
                                  imageUrl:
                                      "${Domain.url}${widget.personAvatar}",
                                  placeholder: (context, url) =>
                                      new CircularProgressIndicator(),
                                  errorWidget: (context, url, error) =>
                                      new Icon(Icons.error),
                                ),
                              ),
                            ),
                          ),
                        ),
                  Padding(
                    padding: const EdgeInsets.only(left: 10),
                    child: Text(
                      widget.personName,
                      style: TextStyle(fontSize: 17),
                    ),
                  ),
                ],
              ),
            ),
          ),
          actions: [
            PopupMenuButton(
              icon: Icon(Icons.more_vert),
              onSelected: (value) {
                setState(() {
                  switch (value) {
                    case 1:
                      Provider.of<SellerDetails>(context, listen: false)
                          .followUser();
                      Provider.of<SellerDetails>(context, listen: false)
                          .followUnFollow(
                        username: widget.username,
                        followstatus: followStatus ? "Follow" : "UnFollow",
                        authtoken: authToken,
                      )
                          .then((value) {
                        if (value["status"] == 200) {
                          Provider.of<SellerDetails>(context, listen: false)
                              .getsellerDetails(
                            authtoken: authToken,
                            username: widget.username,
                          );
                        }
                      });
                      break;
                    case 2:
                      Provider.of<BoolLoader>(context, listen: false)
                          .boolLoader(status: true);
                      SellerDetails.blockuser(
                        username: widget.username,
                        authtoken: authToken,
                      ).then((value) {
                        if (value["status"] == 200) {
                          // Provider.of<GetHome>(context, listen: false)
                          //     .clearProductsList();
                          filterbasedonLocation(
                            username: widget.username,
                            latitude: latitude,
                            longitude: longitude,
                          );
                          Provider.of<UserData>(context, listen: false)
                              .following(
                            authtoken: authToken ?? '',
                            userprofilename: widget.username,
                          );
                          Provider.of<BoolLoader>(context, listen: false)
                              .boolLoader(status: false);
                        } else {
                          Provider.of<BoolLoader>(context, listen: false)
                              .boolLoader(status: false);
                          ShowToast.showToast(context,
                              exception: "Try again later");
                        }
                      });
                      break;
                  }
                });
              },
              itemBuilder: (context) => [
                PopupMenuItem(
                  value: 1,
                  child: Text(
                    // "Follow",
                    followStatus ? "Unfollow" : "Follow",
                    style: TextStyle(fontWeight: FontWeight.w500, fontSize: 16),
                  ),
                ),
                PopupMenuItem(
                  value: 2,
                  child: Text(
                    "Block",
                    style: TextStyle(
                      fontWeight: FontWeight.w500,
                      fontSize: 16,
                    ),
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
      body: _lsd
          ? LoadingWidget()
          : Padding(
              padding: EdgeInsets.only(top: 10),
              child: Stack(
                children: [
                  StreamBuilder<QuerySnapshot<Map<String, dynamic>>>(
                    stream: chatmessageStream,
                    builder: (context, snapshot) {
                      if (snapshot.hasData) {
                        return snapshot.data!.docs.length > 0
                            ? Column(
                                children: [
                                  Expanded(
                                    child: ListView.builder(
                                      reverse: true,
                                      itemCount: snapshot.data!.docs.length,
                                      itemBuilder: (listviewcontext, index) {
                                        // print(snapshot.data!.docs[index].data());
                                        return Container(
                                          padding: EdgeInsets.symmetric(
                                              horizontal: 10),
                                          child: snapshot.data!.docs[index]
                                                      .data()["senderId"] ==
                                                  widget.myid
                                              ? Align(
                                                  alignment:
                                                      Alignment.bottomRight,
                                                  child: displayMessage(
                                                    snapshot,
                                                    index,
                                                    bottomRight:
                                                        Radius.circular(0),
                                                    bottomLeft:
                                                        Radius.circular(15),
                                                  ),
                                                )
                                              : Align(
                                                  alignment:
                                                      Alignment.bottomLeft,
                                                  child: Padding(
                                                    padding:
                                                        const EdgeInsets.only(
                                                            bottom: 5),
                                                    child: Container(
                                                      decoration: BoxDecoration(
                                                        border: Border.all(
                                                          color: colorBlue,
                                                        ),
                                                        borderRadius:
                                                            BorderRadius.only(
                                                          bottomRight:
                                                              Radius.circular(
                                                                  15),
                                                          topLeft:
                                                              Radius.circular(
                                                                  15),
                                                          topRight:
                                                              Radius.circular(
                                                                  15),
                                                        ),
                                                      ),
                                                      child: Padding(
                                                        padding:
                                                            const EdgeInsets
                                                                .all(10),
                                                        child: Text(
                                                          snapshot.data!
                                                                  .docs[index]
                                                                  .data()[
                                                              "message"],
                                                          style: TextStyle(
                                                            fontSize: 20,
                                                            color: colorBlue,
                                                          ),
                                                        ),
                                                      ),
                                                    ),
                                                  ),
                                                ),
                                        );
                                      },
                                    ),
                                  ),
                                  SizedBox(
                                    height: MediaQuery.of(context).size.height *
                                        0.09,
                                    // height: 20,
                                  ),
                                ],
                              )
                            // : bottomModalSheet();
                            : Container();
                      } else {
                        return Center(child: LoadingWidget());
                      }
                    },
                  ),
                  Align(
                    alignment: Alignment.bottomCenter,
                    child: BottomAppBar(
                      child: Container(
                        padding: EdgeInsets.only(
                            left: 15, right: 2, top: 10, bottom: 10),
                        child: Row(
                          children: [
                            Expanded(
                              child: Container(
                                decoration: BoxDecoration(
                                  borderRadius: BorderRadius.circular(50),
                                  border: Border.all(color: colorBlue),
                                  // color: colorBlue,
                                ),
                                padding:
                                    const EdgeInsets.symmetric(horizontal: 20),
                                child: TextFormField(
                                  controller: messageController,
                                  cursorColor: Colors.black,
                                  decoration: new InputDecoration(
                                    border: InputBorder.none,
                                    focusedBorder: InputBorder.none,
                                    enabledBorder: InputBorder.none,
                                    errorBorder: InputBorder.none,
                                    disabledBorder: InputBorder.none,
                                    // contentPadding: EdgeInsets.only(left: 0),
                                    hintText: "Type here...",
                                    hintStyle: TextStyle(color: Colors.black45),
                                  ),
                                  style: TextStyle(
                                      color: Colors.black, fontSize: 20),
                                ),
                              ),
                            ),
                            SizedBox(width: 2),
                            IconButton(
                              onPressed: () {
                                // Checking for message if empty
                                if (messageController.text.isNotEmpty) {
                                  // checking Previous chat list - to whom I have chatted with list.
                                  // If empty or chatroomuserid list doesnt not container mapchatroomlist/sellerid
                                  // create new chatroom.
                                  if (widget.chatroomUserid.isEmpty ||
                                      widget.chatroomUserid.contains(
                                              widget.mapchatroomlist) ==
                                          false) {
                                    List<String> user = [
                                      widget.myid,
                                      widget.sellerid,
                                    ];
                                    Map<String, dynamic> chatroomMap = {
                                      "users": user,
                                      "sellerId": widget.sellerid,
                                      "chatroomId":
                                          "${widget.myid}_${widget.sellerid}",
                                    };
                                    ChatFirestore.createChatRoom(
                                      chatroomMap: chatroomMap,
                                      chatroomId:
                                          "${widget.myid}_${widget.sellerid}",
                                    ).then((value) {
                                      ChatFirestore.createMessage(
                                        chatRoomId:
                                            "${widget.myid}_${widget.sellerid}",
                                        message: messageController.text,
                                        senderId: widget.myid,
                                      ).then((value) {
                                        if (value == 200) {
                                          messageController.clear();
                                        }
                                      });
                                    });
                                  } else {
                                    // Checking whether I have chatted with this seller before by comparing the list of chatted people
                                    // with the seller id I am having.
                                    if (widget.chatroomUserid
                                        .contains(widget.sellerid)) {
                                      ChatFirestore.createMessage(
                                        chatRoomId:
                                            "${widget.mapchatroomid[widget.sellerid]}",
                                        message: messageController.text,
                                        senderId: widget.myid,
                                      ).then((value) {
                                        if (value == 200) {
                                          messageController.clear();
                                        }
                                      });
                                    } // checking mapchatroomid {containing already chatted person id_myid}
                                    else if (widget.mapchatroomid.containsValue(
                                        "${widget.chatlistuserId}_${widget.myid}")) {
                                      ChatFirestore.createMessage(
                                        chatRoomId:
                                            "${widget.chatlistuserId}_${widget.myid}",
                                        message: messageController.text,
                                        senderId: widget.myid,
                                      ).then((value) {
                                        if (value == 200) {
                                          messageController.clear();
                                        }
                                      });
                                    } else {
                                      ChatFirestore.createMessage(
                                        chatRoomId:
                                            "${widget.mapchatroomid[widget.chatlistuserId]}",
                                        message: messageController.text,
                                        senderId: widget.myid,
                                      ).then((value) {
                                        if (value == 200) {
                                          messageController.clear();
                                        }
                                      });
                                    }
                                  }
                                }
                              },
                              icon: Icon(
                                Icons.send,
                                size: 30,
                                color: colorBlue,
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
    );
  }

  filterbasedonLocation({
    required String username,
    required String latitude,
    required String longitude,
  }) {
    Provider.of<GetHome>(this.context, listen: false)
        .getProducts(
      authtoken: authToken ?? '',
      refresh: true,
      lat: latitude == "0.0" ? GetStoredInfo.latitude : latitude,
      long: longitude == "0.0" ? GetStoredInfo.longitude : longitude,
    )
        .then((value) {
      Provider.of<BoolLoader>(this.context, listen: false)
          .boolLoader(status: false);
      if (value['status'] == 200) {
        ShowToast.showToast(context, exception: "Successfully blocked");
        Provider.of<UserData>(context, listen: false).following(
          authtoken: authToken ?? '',
          userprofilename: username,
        );
        Navigator.of(context).push(
          MaterialPageRoute(
            builder: (_) => CustomBottomNavBar(chooseIndex: 0),
          ),
        );
      }
    });
  }

  /*
 SizedBox(height: 10),
                    Text(
                      'Filter by',
                      style: TextStyle(
                        color: Colors.black,
                        fontSize: 20,
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                    SizedBox(height: 5),
                    Padding(
                      padding: const EdgeInsets.symmetric(horizontal: 10),
                      child: Divider(),
                    ),
  */
  bottomModalSheet() {
    return showModalBottomSheet(
      isDismissible: false,
      isScrollControlled: true,
      backgroundColor: Colors.white,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(
          top: Radius.circular(20),
        ),
      ),
      context: this.context,
      builder: (context) {
        return StatefulBuilder(
          builder: (buildercontext, builderState) {
            return Padding(
              padding: MediaQuery.of(context).viewInsets,
              child: SingleChildScrollView(
                child: Container(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      SizedBox(height: 10),
                      Center(
                        child: Text(
                          "Reminder before your chat!",
                          style: TextStyle(
                            color: Colors.black,
                            fontSize: 20,
                            fontWeight: FontWeight.w500,
                          ),
                        ),
                      ),
                      SizedBox(height: 5),
                      Padding(
                        padding: const EdgeInsets.symmetric(horizontal: 10),
                        child: Divider(),
                      ),
                      SizedBox(height: 5),
                      Padding(
                        padding: const EdgeInsets.all(10.0),
                        child: Container(
                          width: double.infinity,
                          child: Wrap(
                            children: [
                              Text(
                                "Be safe, take necessary precautions while meeting with buyers and sellers",
                                style: TextStyle(
                                  fontSize: 18,
                                ),
                              ),
                            ],
                          ),
                        ),
                      ),
                      SizedBox(height: 15),
                      Padding(
                        padding: const EdgeInsets.all(10.0),
                        child: Container(
                          width: double.infinity,
                          child: Wrap(
                            children: [
                              Text(
                                "Do not share UPI pin while sending / receiving money",
                                style: TextStyle(
                                  fontSize: 18,
                                ),
                              ),
                            ],
                          ),
                        ),
                      ),
                      SizedBox(height: 15),
                      Padding(
                        padding: const EdgeInsets.all(10.0),
                        child: Container(
                          width: double.infinity,
                          child: Wrap(
                            children: [
                              Text(
                                "Never give money or product in advance",
                                style: TextStyle(
                                  fontSize: 18,
                                ),
                              ),
                            ],
                          ),
                        ),
                      ),
                      SizedBox(height: 15),
                      Padding(
                        padding: const EdgeInsets.all(10.0),
                        child: Container(
                          width: double.infinity,
                          child: Wrap(
                            children: [
                              Text(
                                "Report suspicious users to Barto",
                                style: TextStyle(
                                  fontSize: 18,
                                ),
                              ),
                            ],
                          ),
                        ),
                      ),
                      SizedBox(height: 15),
                      Padding(
                        padding: const EdgeInsets.only(bottom: 10),
                        child: Align(
                          alignment: Alignment.bottomCenter,
                          child: InkWell(
                            onTap: () {
                              Navigator.pop(context);
                            },
                            child: Container(
                              width: MediaQuery.of(context).size.width / 1.7,
                              height: MediaQuery.of(context).size.height / 16,
                              decoration: BoxDecoration(
                                color: Color(0xFF30BFFD),
                                borderRadius: BorderRadius.circular(5),
                              ),
                              child: Center(
                                child: Text(
                                  'Chat',
                                  style: TextStyle(
                                    fontSize:
                                        MediaQuery.of(context).size.height *
                                            0.03,
                                    fontWeight: FontWeight.w500,
                                  ),
                                ),
                              ),
                            ),
                          ),
                        ),
                      ),
                      SizedBox(height: 15),
                    ],
                  ),
                ),
              ),
            );
          },
        );
      },
    );
  }

  Padding displayMessage(
    AsyncSnapshot<QuerySnapshot<Map<String, dynamic>>> snapshot,
    int index, {
    required Radius bottomLeft,
    required Radius bottomRight,
  }) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 5),
      child: Container(
        decoration: BoxDecoration(
          color: colorBlue,
          borderRadius: BorderRadius.only(
            bottomLeft: bottomLeft,
            bottomRight: bottomRight,
            topLeft: Radius.circular(15),
            topRight: Radius.circular(15),
          ),
        ),
        child: Padding(
          padding: const EdgeInsets.all(10),
          child: Text(
            snapshot.data!.docs[index].data()["message"],
            style: TextStyle(fontSize: 20, color: Colors.white),
          ),
        ),
      ),
    );
  }
}
