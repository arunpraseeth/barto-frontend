import 'dart:io' show Platform;
import 'package:app_settings/app_settings.dart';
import 'package:flutter/cupertino.dart';
import "package:flutter/material.dart";
import 'package:flutter_dotenv/flutter_dotenv.dart';
import 'package:geolocator/geolocator.dart';
import 'package:india/Common/color.dart';
import 'package:india/Common/loading_bool.dart';
import 'package:india/Common/loading_widget.dart';
import 'package:india/Common/show_toast.dart';
import 'package:india/Model/location.dart';
import 'package:india/Services/get_home.dart';
import 'package:india/Services/search_places.dart';
import 'package:india/Services/user_data.dart';
import 'package:india/Widgets/Screens/bottom_navbar.dart';
import 'package:india/Widgets/Screens/search.dart';
import 'package:provider/provider.dart';

// ignore: must_be_immutable
class FilterProductLocation extends StatefulWidget {
  String savedlat;
  String savedlong;
  int page;
  FilterProductLocation({
    required this.savedlat,
    required this.savedlong,
    required this.page,
  });

  @override
  State<FilterProductLocation> createState() => _FilterProductLocationState();
}

class _FilterProductLocationState extends State<FilterProductLocation> {
  FocusNode focusNode = FocusNode();

  String apiKey = dotenv.get('PUBLICAPIKEY');

  final GlobalKey<ScaffoldState> _scaffoldKey = GlobalKey<ScaffoldState>();

  TextEditingController searchcontroller = TextEditingController();
  var jsonData;

  @override
  Widget build(BuildContext context) {
    Size size = MediaQuery.of(context).size;
    bool _loading = Provider.of<BoolLoader>(context).loadingStatus;
    String authtoken = Provider.of<UserData>(context).authtoken;
    return Scaffold(
      key: _scaffoldKey,
      backgroundColor: Colors.white,
      appBar: AppBar(
        centerTitle: true,
        backgroundColor: Color(0xFFF5F5F5),
        elevation: 2,
        title: Text("Choose Location"),
      ),
      body: _loading
          ? LoadingWidget()
          : SingleChildScrollView(
              child: Stack(
                children: [
                  Column(
                    children: [
                      Padding(
                        padding:
                            const EdgeInsets.only(left: 15, right: 15, top: 15),
                        child: Container(
                          decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(5),
                            color: Colors.white,
                            boxShadow: [
                              BoxShadow(
                                color: Colors.grey.withOpacity(0.3),
                                spreadRadius: 0.7,
                                blurRadius: 2,
                                offset:
                                    Offset(0, 0), // changes position of shadow
                              ),
                            ],
                          ),
                          child: ListTile(
                            title: TextFormField(
                              controller: searchcontroller,
                              style: TextStyle(fontSize: 20),
                              decoration: InputDecoration(
                                hintText: "Search...",
                                border: InputBorder.none,
                              ),
                              onChanged: (String value) {
                                if (value.length > 2) {
                                  Provider.of<SearchPlaces>(context,
                                          listen: false)
                                      .searchPlaces(placeName: value);
                                } else {
                                  Provider.of<SearchPlaces>(context,
                                          listen: false)
                                      .clearPlaceName();
                                }
                              },
                            ),
                            trailing: Transform.translate(
                              offset: Offset(10, 0),
                              child: IconButton(
                                onPressed: () {
                                  focusNode.unfocus();
                                  searchcontroller.clear();
                                  Provider.of<SearchPlaces>(context,
                                          listen: false)
                                      .clearPlaceName();
                                },
                                icon: Provider.of<SearchPlaces>(context)
                                        .placefeatures
                                        .isEmpty
                                    ? Icon(Icons.search, size: 25)
                                    : Icon(Icons.clear, size: 25),
                              ),
                            ),
                          ),
                        ),
                      ),
                      Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          ListTile(
                            onTap: () async {
                              getLocation(
                                context: context,
                                authtoken: authtoken,
                                size: size,
                              );
                            },
                            leading: Padding(
                              padding: const EdgeInsets.only(left: 5),
                              child: Icon(
                                Icons.my_location,
                                color: colorBlue,
                              ),
                            ),
                            title: Transform.translate(
                              offset: Offset(-10, 0),
                              child: Text(
                                "My Location",
                                style: TextStyle(fontSize: 18),
                              ),
                            ),
                          ),
                          // ! Commenting according to customer's requirement.
                          // Container(
                          //   padding: EdgeInsets.only(right: 40),
                          //   child: Padding(
                          //     padding: const EdgeInsets.only(left: 64),
                          //     child: Transform.translate(
                          //       offset: Offset(0, -12),
                          //       child: Text(
                          //         GetStoredInfo.placename,
                          //         style: TextStyle(
                          //           fontSize: size.width * 0.035,
                          //           color: Colors.black,
                          //           fontWeight: FontWeight.w500,
                          //         ),
                          //         maxLines: 1,
                          //         overflow: TextOverflow.ellipsis,
                          //         softWrap: false,
                          //       ),
                          //     ),
                          //   ),
                          // ),
                        ],
                      ),
                    ],
                  ),
                  Provider.of<SearchPlaces>(context).placefeatures.isNotEmpty
                      ? Padding(
                          padding: const EdgeInsets.only(
                              left: 15, right: 15, top: 80),
                          child: Container(
                            decoration: BoxDecoration(
                              borderRadius: BorderRadius.circular(5),
                              color: Colors.white,
                              boxShadow: [
                                BoxShadow(
                                  color: Colors.grey.withOpacity(0.3),
                                  spreadRadius: 0.7,
                                  blurRadius: 2,
                                  offset: Offset(
                                      0, 0), // changes position of shadow
                                ),
                              ],
                            ),
                            child: ListView.builder(
                              shrinkWrap: true,
                              itemCount: Provider.of<SearchPlaces>(context)
                                  .placefeatures
                                  .length,
                              itemBuilder: (listviewcontext, index) {
                                return Container(
                                  child: Padding(
                                    padding: const EdgeInsets.all(13.0),
                                    child: InkWell(
                                      child: Text(
                                        Provider.of<SearchPlaces>(context)
                                            .placefeatures[index]["place_name"],
                                        style: TextStyle(fontSize: 20),
                                      ),
                                      onTap: () {
                                        Provider.of<BoolLoader>(
                                                _scaffoldKey.currentContext!,
                                                listen: false)
                                            .boolLoader(status: true);
                                        String name = Provider.of<SearchPlaces>(
                                                context,
                                                listen: false)
                                            .placefeatures[index]["place_name"];
                                        List selectedLatLong =
                                            Provider.of<SearchPlaces>(context,
                                                    listen: false)
                                                .placefeatures[index]["center"];
                                        List placename = name.split(",");
                                        if (placename.length == 1) {
                                          for (int i = 0;
                                              i < placename.length;
                                              i++) {
                                            Provider.of<StoreLocation>(context,
                                                    listen: false)
                                                .storeLocation(
                                              lat: selectedLatLong[1],
                                              long: selectedLatLong[0],
                                              countryname: placename[0],
                                            );
                                            Provider.of<BoolLoader>(
                                                    _scaffoldKey
                                                        .currentContext!,
                                                    listen: false)
                                                .boolLoader(status: false);
                                            ShowToast.showToast(
                                              context,
                                              exception:
                                                  "Kindly search for an area or a city",
                                            );
                                          }
                                        } else if (placename.length == 2) {
                                          for (int i = 0;
                                              i < placename.length;
                                              i++) {
                                            Provider.of<StoreLocation>(context,
                                                    listen: false)
                                                .storeLocation(
                                              lat: selectedLatLong[1],
                                              long: selectedLatLong[0],
                                              statename: placename[0],
                                              countryname: placename[1],
                                            );
                                            Provider.of<BoolLoader>(
                                                    _scaffoldKey
                                                        .currentContext!,
                                                    listen: false)
                                                .boolLoader(status: false);
                                            ShowToast.showToast(
                                              context,
                                              exception:
                                                  "Kindly search for an area or a city",
                                            );
                                          }
                                        } else if (placename.length == 3) {
                                          for (int i = 0;
                                              i < placename.length;
                                              i++) {
                                            Provider.of<StoreLocation>(context,
                                                    listen: false)
                                                .storeLocation(
                                              lat: selectedLatLong[1],
                                              long: selectedLatLong[0],
                                              cityname: placename[0],
                                              statename: placename[1],
                                              countryname: placename[2],
                                            );
                                          }
                                          callingGetHome(
                                            context: context,
                                            authtoken: authtoken,
                                            latitude: selectedLatLong[1],
                                            longitude: selectedLatLong[0],
                                          );
                                        } else if (placename.length == 4) {
                                          for (int i = 0;
                                              i < placename.length;
                                              i++) {
                                            Provider.of<StoreLocation>(context,
                                                    listen: false)
                                                .storeLocation(
                                              lat: selectedLatLong[1],
                                              long: selectedLatLong[0],
                                              cityname: placename[0],
                                              districtname: placename[1],
                                              statename: placename[2],
                                              countryname: placename[3],
                                            );
                                          }
                                          callingGetHome(
                                            context: context,
                                            authtoken: authtoken,
                                            latitude: selectedLatLong[1],
                                            longitude: selectedLatLong[0],
                                          );
                                        } else {
                                          for (int i = 0;
                                              i < placename.length;
                                              i++) {
                                            Provider.of<StoreLocation>(context,
                                                    listen: false)
                                                .storeLocation(
                                              lat: selectedLatLong[1],
                                              long: selectedLatLong[0],
                                              areaname: placename[0],
                                              cityname: placename[1],
                                              districtname: placename[2],
                                              statename: placename[3],
                                              countryname: placename[4],
                                            );
                                          }
                                          callingGetHome(
                                            context: context,
                                            authtoken: authtoken,
                                            latitude: selectedLatLong[1],
                                            longitude: selectedLatLong[0],
                                          );
                                        }
                                        focusNode.unfocus();
                                        Provider.of<SearchPlaces>(context,
                                                listen: false)
                                            .clearPlaceName();
                                      },
                                    ),
                                  ),
                                );
                              },
                            ),
                          ),
                        )
                      : Container(),
                ],
              ),
            ),
    );
  }

  callingGetHome({
    required BuildContext context,
    required String authtoken,
    required double latitude,
    required double longitude,
  }) async {
    // Calling get home API
    Provider.of<GetHome>(context, listen: false)
        .getProducts(
      authtoken: authtoken,
      refresh: true,
      lat: "$latitude",
      long: "$longitude",
    )
        .then(
      (value) {
        Provider.of<BoolLoader>(_scaffoldKey.currentContext!, listen: false)
            .boolLoader(status: false);
        if (value["status"] == 200) {
          Navigator.pushAndRemoveUntil(
            _scaffoldKey.currentContext ?? context,
            MaterialPageRoute(
              builder: (_) => widget.page == 1
                  ? CustomBottomNavBar(chooseIndex: 0)
                  : SearchPage(authtoken: authtoken),
            ),
            (route) => false,
          );
        }
      },
    );
  }

  Future getLocation({
    required BuildContext context,
    required String authtoken,
    required Size size,
  }) async {
    LocationPermission permission;
    bool serviceEnabled = await Geolocator.isLocationServiceEnabled();
    if (!serviceEnabled) {
      showAlertDialog(
        context,
        size: size,
        title: "Your location service is disabled.",
        text1: "Enable",
        text2: "Cancel",
        onPressed1: () => AppSettings.openLocationSettings(),
      );
      return Future.error('Location services are disabled.');
    } else {
      permission = await Geolocator.checkPermission();
      // print('Permission: $permission');
      if (permission == LocationPermission.denied ||
          permission == LocationPermission.deniedForever) {
        permission = await Geolocator.requestPermission();
        if (permission == LocationPermission.denied ||
            permission == LocationPermission.deniedForever) {
          showAlertDialog(
            context,
            size: size,
            title: "Kindly Provide location permisison.",
            text1: "Enable",
            text2: "Cancel",
            onPressed1: () => AppSettings.openAppSettings(),
          );
        } else {
          Provider.of<BoolLoader>(context, listen: false)
              .boolLoader(status: true);
          try {
            Position position = await Geolocator.getCurrentPosition(
              desiredAccuracy: LocationAccuracy.high,
            );

            // Latlong modal and storing
            Provider.of<StoreLocation>(context, listen: false).storeLocation(
              lat: position.latitude,
              long: position.longitude,
            );
            // Reverse geocoding
            Provider.of<SearchPlaces>(context, listen: false).myLocation(
              longitude: position.longitude,
              latitude: position.latitude,
              providercontext: context,
            );

            // Calling get home API
            // Provider.of<GetHome>(context, listen: false).clearProductsList();

            Provider.of<GetHome>(context, listen: false)
                .getProducts(
              authtoken: authtoken,
              refresh: true,
              lat: "${position.latitude}",
              long: "${position.longitude}",
            )
                .then((value) {
              if (value["status"] == 200) {
                Navigator.pushAndRemoveUntil(
                  context,
                  MaterialPageRoute(
                    builder: (_) => widget.page == 1
                        ? CustomBottomNavBar(chooseIndex: 0)
                        : SearchPage(authtoken: authtoken),
                  ),
                  (route) => false,
                );
                Provider.of<BoolLoader>(context, listen: false)
                    .boolLoader(status: false);
              } else {
                Provider.of<BoolLoader>(context, listen: false)
                    .boolLoader(status: false);
              }
            });
          } on Exception catch (e) {
            print('Location problem: $e');
            Provider.of<BoolLoader>(context, listen: false)
                .boolLoader(status: false);
          }
        }
      } else if (permission == LocationPermission.whileInUse ||
          permission == LocationPermission.always) {
        Provider.of<BoolLoader>(context, listen: false)
            .boolLoader(status: true);
        try {
          //Getting current posistion
          Position position = await Geolocator.getCurrentPosition(
            desiredAccuracy: LocationAccuracy.high,
          );

          // Latlong modal and storing
          Provider.of<StoreLocation>(context, listen: false).storeLocation(
            lat: position.latitude,
            long: position.longitude,
          );

          // Reverse geocoding
          Provider.of<SearchPlaces>(context, listen: false).myLocation(
            longitude: position.longitude,
            latitude: position.latitude,
            providercontext: context,
          );

          // Calling get home API
          // Provider.of<GetHome>(context, listen: false).clearProductsList();

          // Calling get products api for home
          Provider.of<GetHome>(context, listen: false)
              .getProducts(
            authtoken: authtoken,
            refresh: true,
            lat: "${position.latitude}",
            long: "${position.longitude}",
          )
              .then((value) {
            if (value["status"] == 200) {
              Navigator.pushAndRemoveUntil(
                context,
                MaterialPageRoute(
                  builder: (_) => widget.page == 1
                      ? CustomBottomNavBar(chooseIndex: 0)
                      : SearchPage(authtoken: authtoken),
                ),
                (route) => false,
              );
              Provider.of<BoolLoader>(context, listen: false)
                  .boolLoader(status: false);
            } else {
              Provider.of<BoolLoader>(context, listen: false)
                  .boolLoader(status: false);
            }
          });
        } on Exception catch (e) {
          print('Location problem: $e');
          Provider.of<BoolLoader>(context, listen: false)
              .boolLoader(status: false);
        }
      } else {
        return Future.error(
          'Location permissions are permanently denied, we cannot request permissions.',
        );
      }
    }
  }
}

Future showAlertDialog(
  BuildContext context, {
  required Size size,
  required String title,
  required String text1,
  required String text2,
  required VoidCallback onPressed1,
}) async {
  if (Platform.isAndroid) {
    return showDialog(
      barrierDismissible: true,
      context: context,
      builder: (context) => AlertDialog(
        title: Text(
          title,
          style: TextStyle(fontSize: size.height * 0.02),
        ),
        actions: <Widget>[
          // ignore: deprecated_member_use
          FlatButton(
            child: Text(
              text1,
              style: TextStyle(
                fontSize: size.height * 0.02,
                color: colorBlue,
              ),
            ),
            onPressed: onPressed1,
          ),
          // ignore: deprecated_member_use
          FlatButton(
            child: Text(
              text2,
              style: TextStyle(
                fontSize: size.height * 0.02,
                // color: colorBlue,
              ),
            ),
            onPressed: () => Navigator.of(context).pop(),
          ),
        ],
      ),
    );
  } else {
    // todo : showDialog for ios
    return showCupertinoDialog(
      barrierDismissible: true,
      context: context,
      builder: (context) => CupertinoAlertDialog(
        title: Text(title),
        actions: <Widget>[
          CupertinoDialogAction(
            child: Text(text1),
            onPressed: onPressed1,
          ),
          CupertinoDialogAction(
            child: Text(text2),
            onPressed: () => Navigator.of(context).pop(),
          ),
        ],
      ),
    );
  }
}


 // ! Commenting map for next release
                // Padding(
                //   padding: EdgeInsets.only(top: size.height * 0.095),
                //   child: Container(
                //     height: size.height,
                //     child: MapboxMap(
                //         accessToken: apiKey,
                //         // styleString: style,
                //         initialCameraPosition: CameraPosition(
                //           zoom: 15.0,
                //           target: LatLng(
                //             latitude = latitude,
                //             longitude = longitude,
                //           ),
                //           // target: LatLng(
                //           //   latitude == 0.0 ? savedlat : latitude,
                //           //   longitude == 0.0 ? savedlong : longitude,
                //           // ),
                //         ),
                //         myLocationEnabled: true,
                //         compassEnabled: true,
                //         trackCameraPosition: true,
                //         onMapCreated: (MapboxMapController controller) async {
                //           // Acquire current location (returns the LatLng instance)
                //           print("a: $latitude");
                //           print("b: $longitude");
                //           final result = LatLng(
                //             latitude = latitude,
                //             longitude = longitude,
                //           );
                //           // final result = LatLng(
                //           //   latitude == 0.0 ? savedlat : latitude,
                //           //   longitude == 0.0 ? savedlong : longitude,
                //           // );

                //           // You can either use the moveCamera or animateCamera, but the former
                //           // causes a sudden movement from the initial to 'new' camera position,
                //           // while animateCamera gives a smooth animated transition
                //           await controller.animateCamera(
                //             CameraUpdate.newLatLng(result),
                //           );

                //           // Add a circle denoting current user location
                //           await controller.addCircle(
                //             CircleOptions(
                //               circleRadius: 8.0,
                //               circleColor: '#006992',
                //               circleOpacity: 0.8,

                //               // YOU NEED TO PROVIDE THIS FIELD!!!
                //               // Otherwise, you'll get a silent exception somewhere in the stack
                //               // trace, but the parameter is never marked as @required, so you'll
                //               // never know unless you check the stack trace
                //               geometry: result,
                //               draggable: false,
                //             ),
                //           );
                //         }),
                //   ),
                // ),