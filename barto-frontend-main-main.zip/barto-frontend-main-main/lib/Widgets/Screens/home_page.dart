import 'dart:async';
import 'package:cached_network_image/cached_network_image.dart';
import 'package:india/Common/loading_bool.dart';
import 'package:india/Common/show_toast.dart';
import 'package:india/Model/location.dart';
import 'package:india/Model/shared_pref.dart';
import 'package:flutter/material.dart';
import 'package:flutter_svg/svg.dart';
import 'package:india/Common/color.dart';
import 'package:india/Common/loading_widget.dart';
import 'package:india/Services/domain.dart';
import 'package:india/Services/get_home.dart';
import 'package:india/Services/get_products.dart';
import 'package:india/Services/notification.dart';
import 'package:india/Services/search_product.dart';
import 'package:india/Services/user_data.dart';
import 'package:india/Services/wishlist.dart';
import 'package:india/Widgets/Authentication/Signin/login_bottommodal.dart';
import 'package:india/Widgets/Screens/all_categories.dart';
import 'package:india/Widgets/Screens/filterby_location.dart';
import 'package:india/Widgets/Screens/recent_notification.dart';
import 'package:india/Widgets/Screens/search.dart';
import 'package:india/Widgets/Screens/specific_product.dart';
import 'package:india/Widgets/Screens/subCat_products.dart';
import 'package:provider/provider.dart';
import 'package:pull_to_refresh/pull_to_refresh.dart';
import 'package:shared_preferences/shared_preferences.dart';
import "string_extension.dart";

class HomeScreen extends StatefulWidget {
  @override
  _HomeScreenState createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  RefreshController refreshController =
      RefreshController(initialRefresh: false);
  String? fcmtoken;
  String? authToken;
  List _productinfo = [];
  List _categoryinfo = [];
  List filteredProduct = [];
  late SharedPreferences sharedPreferences;
  LoginModalSheet loginModalSheet = LoginModalSheet();

  Future<String> getAuthToken() async {
    sharedPreferences = await SharedPreferences.getInstance();
    authToken = sharedPreferences.getString("authtoken");
    fcmtoken = sharedPreferences.getString("fcmtoken");
    // print('Auth token: $authToken');
    if (authToken != null) {
      Provider.of<UserData>(context, listen: false)
          .blockedUsers(authtoken: authToken!);
    }
    return authToken ?? '';
  }

  @override
  void initState() {
    GetStoredInfo.getStoreInfo();
    getAuthToken();
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    Size size = MediaQuery.of(context).size;
    bool _loading = Provider.of<BoolLoader>(context).loadingStatus;
    _productinfo = Provider.of<GetHome>(context).productinfoList;
    _categoryinfo = Provider.of<GetHome>(context).categoryList;
    String latitude = Provider.of<StoreLocation>(context).latitude.toString();
    String longitude = Provider.of<StoreLocation>(context).longitude.toString();
    String mapboxPlacename = Provider.of<StoreLocation>(context).placename;
    String country = Provider.of<StoreLocation>(context).countryname;
    String state = Provider.of<StoreLocation>(context).statename;
    String city = Provider.of<StoreLocation>(context).cityname;
    String area = Provider.of<StoreLocation>(context).areaname;
    return Scaffold(
      backgroundColor: Colors.white,
      resizeToAvoidBottomInset: false,
      body: _loading
          ? LoadingWidget()
          : SafeArea(
              child: SmartRefresher(
                controller: refreshController,
                enablePullDown: true,
                enablePullUp: true,
                onRefresh: () {
                  onRefresh(
                    latitude: latitude,
                    longitude: longitude,
                  );
                },
                onLoading: () {
                  homePagination(
                    latitude: latitude,
                    longitude: longitude,
                  );
                },
                child: CustomScrollView(
                  slivers: [
                    SliverAppBar(
                      elevation: 2,
                      forceElevated: true,
                      backgroundColor: Color(0xFFF9F9F9),
                      automaticallyImplyLeading: false,
                      title: Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Flexible(
                            child: Row(
                              children: [
                                Icon(
                                  Icons.location_on,
                                  color: Color(0xFF30BFFD),
                                  size: size.width * 0.045,
                                ),
                                SizedBox(width: 10),
                                Flexible(
                                  child: Container(
                                    padding: EdgeInsets.only(right: 40),
                                    child: InkWell(
                                      onTap: () {
                                        Provider.of<BoolLoader>(context,
                                                listen: false)
                                            .boolLoader(status: false);
                                        Navigator.push(
                                          context,
                                          MaterialPageRoute(
                                            builder: (_) =>
                                                FilterProductLocation(
                                              savedlat: GetStoredInfo.latitude,
                                              savedlong:
                                                  GetStoredInfo.longitude,
                                              page: 1,
                                            ),
                                          ),
                                        );
                                      },
                                      child: Text(
                                        GetStoredInfo.placename.isEmpty
                                            ? "My Location"
                                            : mapboxPlacename.isNotEmpty
                                                ? mapboxPlacename
                                                : GetStoredInfo.placename,
                                        style: TextStyle(
                                          fontSize: size.width * 0.035,
                                          color: Colors.black,
                                          fontWeight: FontWeight.w500,
                                        ),
                                        maxLines: 1,
                                        overflow: TextOverflow.ellipsis,
                                        softWrap: false,
                                      ),
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          ),
                          GestureDetector(
                            onTap: () {
                              if (authToken == null) {
                                loginModalSheet.bottomModalSheet(
                                    context: context);
                              } else {
                                Provider.of<BoolLoader>(context, listen: false)
                                    .boolLoader(status: true);
                                Provider.of<NotificationApi>(context,
                                        listen: false)
                                    .getnotificationapi(
                                  authtoken: authToken ?? '',
                                )
                                    .then((value) {
                                  Provider.of<BoolLoader>(context,
                                          listen: false)
                                      .boolLoader(status: false);
                                  if (value["status"] == 200) {
                                    Navigator.push(
                                      context,
                                      MaterialPageRoute(
                                        builder: (_) => RecentNotifcations(),
                                      ),
                                    );
                                  } else {
                                    ShowToast.showToast(context,
                                        exception:
                                            "Something went wrong, try again later.");
                                  }
                                });
                              }
                            },
                            child: SvgPicture.asset(
                              "assets/homeicon/notification.svg",
                              height: 20,
                            ),
                          ),
                        ],
                      ),
                      expandedHeight: size.width > 400
                          ? size.height * 0.16
                          : size.height * 0.18,

                      // expandedHeight: 120.0,
                      flexibleSpace: FlexibleSpaceBar(
                        background: Material(
                          elevation: 2,
                          child: Column(
                            children: [
                              SizedBox(
                                height: size.height * 0.070,
                              ),
                              Stack(
                                children: [
                                  Padding(
                                    padding: const EdgeInsets.symmetric(
                                        horizontal: 15),
                                    child: Container(
                                      decoration: BoxDecoration(
                                        borderRadius: BorderRadius.circular(5),
                                        color: Colors.white,
                                        boxShadow: [
                                          BoxShadow(
                                            color: Colors.grey.withOpacity(0.3),
                                            spreadRadius: 0.7,
                                            blurRadius: 2,
                                            offset: Offset(0,
                                                0), // changes position of shadow
                                          ),
                                        ],
                                      ),
                                      child: ListTile(
                                        title: TextFormField(
                                          style: TextStyle(fontSize: 20),
                                          readOnly: true,
                                          decoration: InputDecoration(
                                            hintText: "Search...",
                                            border: InputBorder.none,
                                          ),
                                          onTap: () {
                                            Provider.of<SearchProduct>(context,
                                                    listen: false)
                                                .clearSearch();
                                            Provider.of<BoolLoader>(context,
                                                    listen: false)
                                                .boolLoader(status: false);
                                            Navigator.push(
                                              context,
                                              MaterialPageRoute(
                                                builder: (_) => SearchPage(
                                                  authtoken: authToken ?? '',
                                                ),
                                              ),
                                            );
                                          },
                                        ),
                                        trailing: Transform.translate(
                                          offset: Offset(10, 0),
                                          child: Icon(Icons.search, size: 25),
                                        ),
                                      ),
                                    ),
                                  ),
                                ],
                              ),
                            ],
                          ),
                        ),
                      ),
                    ),
                    SliverToBoxAdapter(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              Padding(
                                padding: const EdgeInsets.only(left: 10),
                                child: Text(
                                  'Categories',
                                  style: TextStyle(
                                    fontSize: size.width * 0.041,
                                    fontWeight: FontWeight.w500,
                                  ),
                                ),
                              ),
                              Padding(
                                padding: const EdgeInsets.only(right: 10),
                                child: TextButton(
                                  onPressed: () {
                                    Provider.of<BoolLoader>(context,
                                            listen: false)
                                        .boolLoader(status: false);
                                    Navigator.of(context).push(
                                      MaterialPageRoute(
                                        builder: (_) => AllCategories(
                                          authtoken: authToken ?? '',
                                          countryname: country.isEmpty
                                              ? GetStoredInfo.countryname
                                              : country,
                                          statename: state.isEmpty
                                              ? GetStoredInfo.statename
                                              : state,
                                          cityname: city.isEmpty
                                              ? GetStoredInfo.cityname
                                              : city,
                                          areaname: area.isEmpty
                                              ? GetStoredInfo.arename
                                              : area,
                                        ),
                                      ),
                                    );
                                  },
                                  child: Text(
                                    'See All',
                                    style: TextStyle(
                                      fontSize: size.width * 0.035,
                                      color: Colors.black,
                                      decoration: TextDecoration.underline,
                                    ),
                                  ),
                                ),
                              ),
                            ],
                          ),
                          SizedBox(
                            height: 120,
                            child: ListView.builder(
                              padding: EdgeInsets.zero,
                              shrinkWrap: true,
                              physics: ScrollPhysics(),
                              scrollDirection: Axis.horizontal,
                              itemCount: _categoryinfo.length,
                              itemBuilder: (listviewcontext, index) {
                                return InkWell(
                                  onTap: () {
                                    Provider.of<BoolLoader>(context,
                                            listen: false)
                                        .boolLoader(status: false);
                                    Navigator.push(
                                      context,
                                      MaterialPageRoute(
                                        builder: (_) => SubCatProducts(
                                          subcategoryList: _categoryinfo[index]
                                              ["subcats"],
                                          authtoken: authToken ?? '',
                                          countryname: country.isEmpty
                                              ? GetStoredInfo.countryname
                                              : country,
                                          statename: state.isEmpty
                                              ? GetStoredInfo.statename
                                              : state,
                                          cityname: city.isEmpty
                                              ? GetStoredInfo.cityname
                                              : city,
                                          areaname: area.isEmpty
                                              ? GetStoredInfo.arename
                                              : area,
                                        ),
                                      ),
                                    );
                                  },
                                  child: Column(
                                    mainAxisSize: MainAxisSize.min,
                                    children: [
                                      SizedBox(height: 5),
                                      Padding(
                                        padding: const EdgeInsets.symmetric(
                                            horizontal: 10),
                                        child: Padding(
                                          padding: const EdgeInsets.all(0),
                                          child: Container(
                                            width: 80,
                                            height: 80,
                                            decoration: BoxDecoration(
                                              borderRadius:
                                                  BorderRadius.circular(10),
                                              color: Colors.white,
                                              boxShadow: [
                                                BoxShadow(
                                                  color: Colors.grey
                                                      .withOpacity(0.3),
                                                  spreadRadius: 0.7,
                                                  blurRadius: 2,
                                                  offset: Offset(0, 0),
                                                ),
                                              ],
                                            ),
                                            child: _categoryinfo[index]
                                                        ["cat_img_url"] ==
                                                    null
                                                ? Icon(
                                                    Icons.collections,
                                                    size: 30,
                                                    color: Colors.grey,
                                                  )
                                                : SvgPicture.network(
                                                    "${Domain.url}${_categoryinfo[index]["cat_img_url"]}",
                                                  ),
                                          ),
                                        ),
                                      ),
                                      SizedBox(height: 10),
                                      Text(
                                        "${_categoryinfo[index]["name"]}"
                                            .capitalize(),
                                        style: TextStyle(
                                          fontSize: size.height * 0.0150,
                                          fontWeight: FontWeight.w500,
                                        ),
                                      ),
                                    ],
                                  ),
                                );
                              },
                            ),
                          ),
                          // _loading
                          //     ? Center(
                          //         child: SpinKitCircle(
                          //           color: colorBlue,
                          //           size: 60,
                          //         ),
                          //       )
                          //     :

                          // : _searchedList.isEmpty
                          //     ?
                          _productinfo.isEmpty
                              ? Center(
                                  child: Column(
                                    mainAxisAlignment: MainAxisAlignment.center,
                                    children: [
                                      SizedBox(height: size.height * 0.06),
                                      SvgPicture.asset(
                                        "assets/placeholders/notlisted.svg",
                                        height: 230,
                                      ),
                                      SizedBox(height: 20),
                                      Text(
                                        'No products in chosen location.',
                                        style: TextStyle(
                                          fontSize: 18,
                                        ),
                                      ),
                                    ],
                                  ),
                                )
                              : gridview(
                                  size,
                                  itemcount: _productinfo.length,
                                  product: _productinfo,
                                  latitude: latitude,
                                  longitude: longitude,
                                )

                          // : gridview(
                          //     size,
                          //     itemcount: _searchedList.length,
                          //     product: _searchedList,
                          //     latitude: latitude,
                          //     longitude: longitude,
                          //   ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            ),
    );
  }

  Widget gridview(
    Size size, {
    required int itemcount,
    required List product,
    required String latitude,
    required String longitude,
  }) {
    return GridView.builder(
      shrinkWrap: true,
      physics: ScrollPhysics(),
      itemCount: itemcount,
      padding: EdgeInsets.all(3),
      gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
        childAspectRatio: size.width < 500 ? 0.85 : 1.1,
        crossAxisCount: 2,
      ),
      itemBuilder: (BuildContext gridviewcontext, int index) {
        Map<String, dynamic> _productLocation =
            product[index]["product_location"];
        String areaname = _productLocation["area"];
        String cityname = _productLocation["city"];
        String statename = _productLocation["state"];
        String countryname = _productLocation["country"];
        bool _featured = product[index]["featured"];
        return InkWell(
          onTap: () {
            Provider.of<BoolLoader>(this.context, listen: false)
                .boolLoader(status: true);
            Provider.of<ProductInformation>(this.context, listen: false)
                .getproductInformation(
              authtoken: authToken,
              productid: product[index]["_id"],
            )
                .then(
              (value) {
                if (value["status"] == 200) {
                  Navigator.push(
                    this.context,
                    MaterialPageRoute(
                      builder: (_) => SpecificProduct(),
                    ),
                  ).then(
                    (value) {
                      // Provider.of<BoolLoader>(this.context, listen: false).boolLoader(status: true);
                      if (value == "specificProduct" || value == "Searchpage") {
                        WidgetsBinding.instance?.addPostFrameCallback(
                          (duration) {
                            Provider.of<GetHome>(context, listen: false)
                                .getProducts(
                                  refresh: true,
                                  authtoken: authToken ?? '',
                                  lat: latitude == "0.0"
                                      ? GetStoredInfo.latitude
                                      : latitude,
                                  long: longitude == "0.0"
                                      ? GetStoredInfo.longitude
                                      : longitude,
                                )
                                .then(
                                  (value) => Provider.of<BoolLoader>(
                                          this.context,
                                          listen: false)
                                      .boolLoader(status: false),
                                );
                          },
                        );
                        Provider.of<BoolLoader>(this.context, listen: false)
                            .boolLoader(status: false);
                      }
                    },
                  );
                }
                Provider.of<BoolLoader>(this.context, listen: false)
                    .boolLoader(status: false);
              },
            );
          },
          child: Padding(
            padding: const EdgeInsets.all(8.0),
            child: Container(
              decoration: BoxDecoration(
                boxShadow: [
                  BoxShadow(
                    color: Colors.grey.withOpacity(0.3),
                    spreadRadius: 0.7,
                    blurRadius: 2,
                    offset: Offset(0, 0), // changes position of shadow
                  ),
                ],
                color: Colors.white,
                borderRadius: BorderRadius.circular(10),
              ),
              child: Stack(
                children: [
                  Center(
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        //Product Image
                        product[index]["product_image"] == null
                            ? Icon(
                                Icons.person,
                                size: 50,
                                color: Colors.grey,
                              )
                            : CachedNetworkImage(
                                fit: BoxFit.cover,
                                height: size.height * 0.13,
                                imageUrl:
                                    "${Domain.url}${product[index]["product_image"]}",
                                placeholder: (context, url) => Icon(
                                  Icons.image,
                                  size: 50,
                                  color: Colors.grey,
                                ),
                                errorWidget: (context, url, error) =>
                                    new Icon(Icons.error),
                              ),
                        SizedBox(height: size.height * 0.01),
                        //Product Name
                        Text(
                          product[index]["product_name"],
                          style: TextStyle(
                            fontSize: size.width * 0.043,
                            fontWeight: FontWeight.w600,
                          ),
                        ),
                        SizedBox(height: size.height * 0.008),
                        //Product Price
                        Text(
                          product[index]["price"],
                          style: TextStyle(
                            fontSize: size.width * 0.038,
                          ),
                        ),
                        SizedBox(height: size.height * 0.01),
                        //Product uploaded Location
                        Row(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            SizedBox(width: 10),
                            Icon(
                              Icons.location_on,
                              size: size.width * 0.032,
                            ),
                            Flexible(
                              child: Container(
                                child: Padding(
                                  padding: const EdgeInsets.only(right: 10),
                                  child: Text(
                                    (areaname.isEmpty &&
                                            cityname.isEmpty &&
                                            statename.isEmpty)
                                        ? countryname
                                        : (areaname.isEmpty && cityname.isEmpty)
                                            ? "$statename, $countryname"
                                            : (areaname.isEmpty)
                                                ? "$cityname, $statename"
                                                : "$areaname, $cityname",
                                    maxLines: 1,
                                    overflow: TextOverflow.ellipsis,
                                    softWrap: false,
                                    style: TextStyle(
                                      fontSize: size.width * 0.033,
                                    ),
                                  ),
                                ),
                              ),
                            ),
                          ],
                        ),
                      ],
                    ),
                  ),
                  // Wishlist
                  Align(
                    alignment: Alignment.topRight,
                    child: IconButton(
                      onPressed: () {
                        Provider.of<BoolLoader>(context, listen: false)
                            .boolLoader(status: false);
                        if (authToken == null) {
                          loginModalSheet.bottomModalSheet(context: context);
                        } else {
                          setState(() {
                            product[index]["wishlist"] =
                                !product[index]["wishlist"];
                          });
                          if (product[index]["wishlist"] == true) {
                            Provider.of<Wishlist>(context, listen: false)
                                .addWishslist(
                              productid: product[index]["_id"],
                              authtoken: authToken!,
                            );
                          } else {
                            Provider.of<Wishlist>(context, listen: false)
                                .removeWishslist(
                              productid: product[index]["_id"],
                              authtoken: authToken!,
                            );
                          }
                        }
                      },
                      icon: product[index]["wishlist"]
                          ? Icon(
                              Icons.favorite,
                              color: colorBlue,
                              size: 22,
                            )
                          : Container(
                              width: 25,
                              height: 25,
                              decoration: BoxDecoration(
                                borderRadius: BorderRadius.circular(50),
                                color: colorBlue.withOpacity(0.7),
                              ),
                              child: Icon(
                                Icons.favorite,
                                color: Colors.white,
                                size: 17,
                              ),
                            ),
                    ),
                  ),
                  // Featured
                  _featured
                      ? Container(
                          width: size.width * 0.20,
                          height: size.height * 0.030,
                          decoration: BoxDecoration(
                            borderRadius: BorderRadius.only(
                              bottomRight: Radius.circular(10),
                            ),
                            color: colorBlue,
                          ),
                          child: Center(
                            child: Text(
                              "Featured",
                              style: TextStyle(
                                fontSize: size.width * 0.035,
                                fontWeight: FontWeight.w500,
                                color: Colors.white,
                              ),
                            ),
                          ),
                        )
                      : Container(),
                ],
              ),
            ),
          ),
        );
      },
    );
  }

  onRefresh({
    required String latitude,
    required String longitude,
  }) {
    Provider.of<BoolLoader>(context, listen: false).boolLoader(status: true);
    // Provider.of<GetHome>(context, listen: false).clearProductsList();
    Provider.of<GetHome>(this.context, listen: false)
        .getProducts(
      refresh: true,
      authtoken: authToken ?? '',
      lat: latitude == "0.0" ? GetStoredInfo.latitude : latitude,
      long: longitude == "0.0" ? GetStoredInfo.longitude : longitude,
    )
        .then((value) {
      Provider.of<BoolLoader>(context, listen: false).boolLoader(status: false);
      if (value["status"] == 200) {
        Map<String, dynamic> _response = value["response"];
        Map<String, dynamic> _data = _response["data"];
        Map<String, dynamic> _info = _data["info"];
        List _productdetails = _info["products"];
        if (_productdetails.isEmpty) {
          refreshController.refreshCompleted();
        } else {
          refreshController.refreshCompleted();
        }
      } else {
        refreshController.refreshFailed();
      }
    });
  }

  homePagination({
    required String latitude,
    required String longitude,
  }) {
    Provider.of<GetHome>(this.context, listen: false)
        .getProducts(
      refresh: false,
      authtoken: authToken ?? '',
      lat: latitude == "0.0" ? GetStoredInfo.latitude : latitude,
      long: longitude == "0.0" ? GetStoredInfo.longitude : longitude,
    )
        .then((value) {
      if (value["status"] == 200) {
        Map<String, dynamic> _response = value["response"];
        Map<String, dynamic> _data = _response["data"];
        Map<String, dynamic> _info = _data["info"];
        List _productdetails = _info["products"];
        if (_productdetails.isEmpty) {
          refreshController.loadComplete();
        } else {
          refreshController.loadComplete();
        }
      } else {
        refreshController.loadFailed();
      }
    });
  }
}
