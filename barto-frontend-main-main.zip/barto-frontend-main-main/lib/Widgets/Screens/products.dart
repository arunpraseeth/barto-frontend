import 'dart:convert';
import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_overlay_loader/flutter_overlay_loader.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:india/Common/color.dart';
import 'package:india/Common/loading_bool.dart';
import 'package:india/Common/loading_widget.dart';
import 'package:india/Common/show_toast.dart';
import 'package:india/Model/location.dart';
import 'package:india/Model/shared_pref.dart';
import 'package:india/Services/domain.dart';
import 'package:india/Services/filter.dart';
import 'package:india/Services/get_products.dart';
import 'package:india/Services/search_product.dart';
import 'package:india/Services/wishlist.dart';
import 'package:india/Widgets/Authentication/Signin/login_bottommodal.dart';
import 'package:india/Widgets/Screens/specific_product.dart';
import 'package:provider/provider.dart';
import 'package:pull_to_refresh/pull_to_refresh.dart';
import 'package:shared_preferences/shared_preferences.dart';

// ignore: must_be_immutable
class Products extends StatefulWidget {
  String title;
  String categoryId;
  String countryname;
  String statename;
  String cityname;
  String areaname;
  Products({
    required this.categoryId,
    required this.title,
    required this.countryname,
    required this.statename,
    required this.cityname,
    required this.areaname,
  });

  @override
  State<Products> createState() => _ProductsState();
}

class _ProductsState extends State<Products> {
  TextEditingController searchcontroller = TextEditingController();
  RefreshController refreshController =
      RefreshController(initialRefresh: false);
  String? authToken;
  List _searchedList = [];
  String searchproduct = '';
  int? selectedvalue;
  late String fieldType;
  String? _dropdownValueId;
  TextEditingController mincontroller = TextEditingController();
  TextEditingController maxcontroller = TextEditingController();
  Map<String, String> _textFieldValues = {};
  Map<String, dynamic> _dropdowntextValues = {};
  String sort = '';
  String filter = '';
  LoginModalSheet loginModalSheet = LoginModalSheet();
  Future<String> getAuthToken() async {
    SharedPreferences sharedPreferences = await SharedPreferences.getInstance();
    authToken = sharedPreferences.getString("authtoken");
    // print('Auth token: $authToken');
    return authToken ?? '';
  }

  @override
  void initState() {
    getAuthToken();
    GetStoredInfo.getStoreInfo();
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    Size size = MediaQuery.of(context).size;
    bool _loading = Provider.of<BoolLoader>(context).loadingStatus;
    List<dynamic> _productlist =
        Provider.of<FilterProducts>(context).productlist;
    // List _productinfoapi = Provider.of<FilterProducts>(context).productinfoapi;
    Map<String, dynamic> _productfilters =
        Provider.of<FilterProducts>(context).productfilters;
    String latitude = Provider.of<StoreLocation>(context).latitude.toString();
    String longitude = Provider.of<StoreLocation>(context).longitude.toString();
    return Scaffold(
      backgroundColor: Colors.white,
      resizeToAvoidBottomInset: false,
      body: _loading
          ? LoadingWidget()
          : SafeArea(
              child: SmartRefresher(
                controller: refreshController,
                enablePullDown: true,
                enablePullUp: true,
                onRefresh: () {
                  refreshPage();
                },
                onLoading: () {
                  if (_searchedList.isNotEmpty) {
                    searchPagination(
                      latitude: latitude,
                      longitude: longitude,
                    );
                  } else {
                    homePagination();
                  }
                },
                child: CustomScrollView(
                  slivers: [
                    SliverAppBar(
                      centerTitle: true,
                      title: Text(this.widget.title),
                      actions: [
                        Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            Container(),
                            // Sort
                            PopupMenuButton(
                              icon: Icon(Icons.sort),
                              onSelected: (value) {
                                setState(() {
                                  switch (value) {
                                    case 0:
                                      selectedvalue = 1;
                                      Loader.show(context);
                                      sort = json.encode({"price": "1"});
                                      Provider.of<FilterProducts>(this.context,
                                              listen: false)
                                          .filterbyCategories(
                                        refresh: true,
                                        authtoken: authToken ?? '',
                                        categoryId: widget.categoryId,
                                        country: widget.countryname,
                                        state: widget.statename,
                                        city: widget.cityname,
                                        area: widget.areaname,
                                        sort: sort,
                                        filters: filter.isEmpty ? "{}" : filter,
                                      )
                                          .then((value) {
                                        Loader.hide();
                                      });
                                      break;
                                    case 1:
                                      selectedvalue = 2;
                                      Loader.show(context);
                                      sort = json.encode({"price": "-1"});
                                      Provider.of<FilterProducts>(this.context,
                                              listen: false)
                                          .filterbyCategories(
                                        refresh: true,
                                        authtoken: authToken ?? '',
                                        categoryId: widget.categoryId,
                                        country: widget.countryname,
                                        state: widget.statename,
                                        city: widget.cityname,
                                        area: widget.areaname,
                                        sort: sort,
                                        filters: filter.isEmpty ? "{}" : filter,
                                      )
                                          .then((value) {
                                        Loader.hide();
                                      });
                                      break;
                                  }
                                });
                              },
                              itemBuilder: (context) => [
                                PopupMenuItem(
                                  value: 0,
                                  child: Row(
                                    children: [
                                      Text(
                                        "Low to High",
                                        style: TextStyle(
                                          fontSize: 18,
                                          color: selectedvalue == 1
                                              ? colorBlue
                                              : Colors.black,
                                        ),
                                      ),
                                      SizedBox(width: 10),
                                      Icon(
                                        Icons.arrow_downward,
                                        color: selectedvalue == 1
                                            ? colorBlue
                                            : Colors.black,
                                      ),
                                    ],
                                  ),
                                ),
                                PopupMenuItem(
                                  value: 1,
                                  child: Row(
                                    children: [
                                      Text(
                                        "High to Low",
                                        style: TextStyle(
                                          fontSize: 18,
                                          color: selectedvalue == 2
                                              ? colorBlue
                                              : Colors.black,
                                        ),
                                      ),
                                      SizedBox(width: 10),
                                      Icon(
                                        Icons.arrow_upward,
                                        color: selectedvalue == 2
                                            ? colorBlue
                                            : Colors.black,
                                      ),
                                    ],
                                  ),
                                ),
                              ],
                            ),
                            // Filter
                            Padding(
                              padding: const EdgeInsets.only(right: 5),
                              child: IconButton(
                                onPressed: () {
                                  filterbottomModalSheet(
                                    productfilter: _productfilters,
                                  );
                                },
                                icon: Icon(
                                  Icons.filter_alt,
                                ),
                              ),
                            ),
                          ],
                        ),
                      ],
                      elevation: 2,
                      forceElevated: true,
                      backgroundColor: Color(0xFFF9F9F9),
                      expandedHeight: size.width > 400
                          ? size.height * 0.16
                          : size.height * 0.18,
                      flexibleSpace: FlexibleSpaceBar(
                        background: Material(
                          elevation: 2,
                          child: Column(
                            children: [
                              SizedBox(
                                height: size.height * 0.070,
                                // height: size.height * 0.1,
                                // height: size.height < 900
                                //     ? size.height * 0.065
                                //     : size.height * 0.065,
                              ),
                              Padding(
                                padding:
                                    const EdgeInsets.symmetric(horizontal: 15),
                                child: Container(
                                  decoration: BoxDecoration(
                                    borderRadius: BorderRadius.circular(5),
                                    color: Colors.white,
                                    boxShadow: [
                                      BoxShadow(
                                        color: Colors.grey.withOpacity(0.3),
                                        spreadRadius: 0.7,
                                        blurRadius: 2,
                                        offset: Offset(
                                            0, 0), // changes position of shadow
                                      ),
                                    ],
                                  ),
                                  child: ListTile(
                                    title: TextFormField(
                                      style: TextStyle(fontSize: 20),
                                      controller: searchcontroller,
                                      decoration: InputDecoration(
                                        hintText: "Search...",
                                        border: InputBorder.none,
                                      ),
                                      onChanged: (String value) {
                                        setState(() {
                                          searchproduct = value;
                                        });
                                        if (searchproduct.isEmpty) {
                                          setState(() {
                                            _searchedList.clear();
                                          });
                                        } else {
                                          Provider.of<SearchProduct>(context,
                                                  listen: false)
                                              .searchproduct(
                                            refresh: true,
                                            name: searchproduct,
                                            authtoken: authToken == null
                                                ? ''
                                                : "$authToken",
                                            categoryId: widget.categoryId,
                                            latitude: latitude == "0.0"
                                                ? GetStoredInfo.latitude
                                                : latitude,
                                            longitude: longitude == "0.0"
                                                ? GetStoredInfo.longitude
                                                : longitude,
                                          )
                                              .then((value) {
                                            if (value["status"] == 200) {
                                              Map<String, dynamic> _response =
                                                  value["response"];
                                              Map<String, dynamic> _data =
                                                  _response["data"];
                                              Map<String, dynamic> _info =
                                                  _data["info"];
                                              setState(() {
                                                _searchedList =
                                                    _info["products"];
                                              });
                                            } else {
                                              setState(() {
                                                _searchedList.clear();
                                              });
                                              ShowToast.showToast(
                                                context,
                                                exception:
                                                    "No such products available",
                                              );
                                            }
                                          });
                                        }
                                      },
                                    ),
                                    trailing: Transform.translate(
                                      offset: Offset(10, 0),
                                      child: IconButton(
                                        onPressed: () {
                                          setState(() {
                                            searchcontroller.clear();
                                            _searchedList.clear();
                                          });
                                        },
                                        icon: searchcontroller.text == ""
                                            ? Icon(Icons.search, size: 25)
                                            : Icon(Icons.clear, size: 25),
                                      ),
                                    ),
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
                      ),
                    ),
                    // _productinfoapi.isEmpty
                    //     ? Center(
                    //         child: SpinKitCircle(
                    //           color: colorBlue,
                    //           size: 60,
                    //         ),
                    //       )
                    //     :
                    _productlist.isEmpty
                        ? SliverPadding(
                            padding: EdgeInsets.only(bottom: 20),
                            sliver: SliverToBoxAdapter(
                              child: Container(
                                child: Center(
                                  child: Column(
                                    mainAxisAlignment: MainAxisAlignment.center,
                                    children: [
                                      SizedBox(height: size.height * 0.15),
                                      Padding(
                                        padding: const EdgeInsets.symmetric(
                                            horizontal: 15),
                                        child: SvgPicture.asset(
                                          "assets/placeholders/notlisted.svg",
                                          height: 300,
                                        ),
                                      ),
                                      SizedBox(height: 20),
                                      Text(
                                        'No products in chosen location.',
                                        style: TextStyle(
                                          fontSize: 20,
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                              ),
                            ),
                          )
                        : _searchedList.isEmpty
                            ? gridView(
                                size,
                                product: _productlist,
                              )
                            : gridView(
                                size,
                                product: _searchedList,
                              ),
                  ],
                ),
              ),
            ),
    );
  }

  SliverToBoxAdapter gridView(Size size, {required List<dynamic> product}) {
    return SliverToBoxAdapter(
      child: Container(
        margin: EdgeInsets.only(top: 10),
        // height: size.height * 0.8,
        child: GridView.builder(
          shrinkWrap: true,
          physics: ScrollPhysics(),
          itemCount: product.length,
          padding: EdgeInsets.all(3),
          gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
            childAspectRatio: size.width < 500 ? 0.85 : 1.1,
            crossAxisCount: 2,
          ),
          itemBuilder: (BuildContext gridviewcontext, int index) {
            Map<String, dynamic> _productLocation =
                product[index]["product_location"];
            String areaname = _productLocation["area"];
            String cityname = _productLocation["city"];
            String statename = _productLocation["state"];
            String countryname = _productLocation["country"];
            bool _featured = product[index]["featured"];
            return InkWell(
              onTap: () {
                Provider.of<BoolLoader>(context, listen: false)
                    .boolLoader(status: true);
                Provider.of<ProductInformation>(context, listen: false)
                    .getproductInformation(
                  authtoken: authToken,
                  productid: product[index]["_id"],
                )
                    .then((value) {
                  Provider.of<BoolLoader>(context, listen: false)
                      .boolLoader(status: false);
                  if (value["status"] == 200) {
                    Navigator.push(
                      this.context,
                      MaterialPageRoute(
                        builder: (_) => SpecificProduct(),
                      ),
                    );
                  }
                });
              },
              child: Padding(
                padding: const EdgeInsets.all(8.0),
                child: Container(
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(10),
                    color: Colors.white,
                    boxShadow: [
                      BoxShadow(
                        color: Colors.grey.withOpacity(0.3),
                        spreadRadius: 0.7,
                        blurRadius: 2,
                        offset: Offset(0, 0), // changes position of shadow
                      ),
                    ],
                  ),
                  child: Stack(
                    children: [
                      Center(
                        child: Column(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            product[index]["product_image"] == null
                                ? Icon(
                                    Icons.person,
                                    size: 50,
                                    color: Colors.grey,
                                  )
                                : Flexible(
                                    flex: 1,
                                    fit: FlexFit.loose,
                                    child: CachedNetworkImage(
                                      fit: BoxFit.cover,
                                      height: 100,
                                      imageUrl:
                                          "${Domain.url}${product[index]["product_image"]}",
                                      placeholder: (context, url) => Icon(
                                        Icons.image,
                                        size: 50,
                                        color: Colors.grey,
                                      ),
                                      errorWidget: (context, url, error) =>
                                          new Icon(Icons.error),
                                    ),
                                  ),
                            SizedBox(height: size.height * 0.01),
                            // Product name
                            Text(
                              product[index]["product_name"],
                              style: TextStyle(
                                fontSize: size.width * 0.043,
                                fontWeight: FontWeight.w600,
                              ),
                            ),
                            SizedBox(height: size.height * 0.01),
                            // Product price
                            Text(
                              product[index]["price"],
                              style: TextStyle(
                                fontSize: size.width * 0.038,
                              ),
                            ),
                            SizedBox(height: size.height * 0.01),
                            Row(
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: [
                                SizedBox(width: 10),
                                Icon(
                                  Icons.location_on,
                                  size: size.width * 0.032,
                                ),
                                Flexible(
                                  child: Container(
                                    child: Padding(
                                      padding: const EdgeInsets.only(right: 10),
                                      child: Text(
                                        (areaname.isEmpty &&
                                                cityname.isEmpty &&
                                                statename.isEmpty)
                                            ? countryname
                                            : (areaname.isEmpty &&
                                                    cityname.isEmpty)
                                                ? "$statename, $countryname"
                                                : (areaname.isEmpty)
                                                    ? "$cityname, $statename"
                                                    : "$areaname, $cityname",
                                        maxLines: 1,
                                        overflow: TextOverflow.ellipsis,
                                        softWrap: false,
                                        style: TextStyle(
                                          fontSize: size.width * 0.033,
                                        ),
                                      ),
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          ],
                        ),
                      ),
                      Align(
                        alignment: Alignment.topRight,
                        child: IconButton(
                          onPressed: () {
                            Provider.of<BoolLoader>(context, listen: false)
                                .boolLoader(status: false);
                            if (authToken == null) {
                              loginModalSheet.bottomModalSheet(
                                  context: context);
                            } else {
                              setState(() {
                                product[index]["wishlist"] =
                                    !product[index]["wishlist"];
                              });
                              Provider.of<BoolLoader>(context, listen: false)
                                  .boolLoader(status: true);
                              if (product[index]["wishlist"] == true) {
                                Provider.of<Wishlist>(context, listen: false)
                                    .addWishslist(
                                  productid: product[index]["_id"],
                                  authtoken: authToken!,
                                )
                                    .then((value) {
                                  if (value == "Added to wishlist") {
                                    Provider.of<BoolLoader>(context,
                                            listen: false)
                                        .boolLoader(status: false);
                                  }
                                });
                              } else {
                                Provider.of<Wishlist>(context, listen: false)
                                    .removeWishslist(
                                  productid: product[index]["_id"],
                                  authtoken: authToken!,
                                )
                                    .then((value) {
                                  Provider.of<BoolLoader>(context,
                                          listen: false)
                                      .boolLoader(status: false);
                                });
                              }
                            }
                          },
                          icon: product[index]["wishlist"] == false
                              ? Container(
                                  width: 25,
                                  height: 25,
                                  decoration: BoxDecoration(
                                    borderRadius: BorderRadius.circular(50),
                                    color: colorBlue.withOpacity(0.7),
                                  ),
                                  child: Icon(
                                    Icons.favorite,
                                    color: Colors.white,
                                    size: 17,
                                  ),
                                )
                              : Icon(
                                  Icons.favorite,
                                  color: colorBlue,
                                  size: 22,
                                ),
                        ),
                      ),
                      // Featured
                      _featured
                          ? Container(
                              width: size.width * 0.20,
                              height: size.height * 0.030,
                              decoration: BoxDecoration(
                                borderRadius: BorderRadius.only(
                                  bottomRight: Radius.circular(10),
                                ),
                                color: colorBlue,
                              ),
                              child: Center(
                                child: Text(
                                  "Featured",
                                  style: TextStyle(
                                    fontSize: size.width * 0.035,
                                    fontWeight: FontWeight.w500,
                                    color: Colors.white,
                                  ),
                                ),
                              ),
                            )
                          : Container(),
                    ],
                  ),
                ),
              ),
            );
          },
        ),
      ),
    );
  }

  Future<dynamic> filterbottomModalSheet({
    required Map<String, dynamic> productfilter,
  }) {
    return showModalBottomSheet(
      isScrollControlled: true,
      backgroundColor: Colors.white,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(
          top: Radius.circular(20),
        ),
      ),
      context: this.context,
      builder: (context) {
        return StatefulBuilder(
          builder: (buildercontext, builderState) {
            return Padding(
              padding: MediaQuery.of(context).viewInsets,
              child: SingleChildScrollView(
                child: Column(
                  children: [
                    SizedBox(height: 10),
                    Text(
                      'Filter by',
                      style: TextStyle(
                        color: Colors.black,
                        fontSize: 20,
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                    SizedBox(height: 5),
                    Padding(
                      padding: const EdgeInsets.symmetric(horizontal: 10),
                      child: Divider(),
                    ),
                    Column(
                      mainAxisSize: MainAxisSize.min,
                      children: <Widget>[
                        Container(
                          height: MediaQuery.of(context).size.height / 1.5,
                          child: Container(
                            margin: EdgeInsets.only(
                                left: 20, right: 20, bottom: 20),
                            child: Stack(
                              children: [
                                Column(
                                  mainAxisSize: MainAxisSize.min,
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    SizedBox(height: 10),
                                    //? Fields
                                    (productfilter.isNotEmpty)
                                        ? ListView.builder(
                                            itemCount:
                                                productfilter["fields"].length,
                                            shrinkWrap: true,
                                            physics: ScrollPhysics(),
                                            itemBuilder:
                                                (listviewcontext, index) {
                                              List<dynamic> fields =
                                                  productfilter["fields"];
                                              fieldType = fields[index]["type"];
                                              return Container(
                                                width: MediaQuery.of(context)
                                                    .size
                                                    .width,
                                                decoration: BoxDecoration(
                                                  borderRadius:
                                                      BorderRadius.circular(10),
                                                  // color: Colors.grey[200],
                                                ),
                                                child: dynamicWidget(
                                                  builderState: builderState,
                                                  index: index,
                                                  fields: fields,
                                                  productfilter: productfilter,
                                                ),
                                              );
                                            },
                                          )
                                        : Container(),
                                    Padding(
                                      padding: const EdgeInsets.symmetric(
                                          horizontal: 5),
                                      child: Container(
                                        width:
                                            MediaQuery.of(context).size.width,
                                        decoration: BoxDecoration(
                                          borderRadius:
                                              BorderRadius.circular(10),
                                          color: Colors.grey[200],
                                        ),
                                        child: Padding(
                                          padding: const EdgeInsets.symmetric(
                                              horizontal: 10),
                                          child: Column(
                                            crossAxisAlignment:
                                                CrossAxisAlignment.start,
                                            children: [
                                              SizedBox(height: 10),
                                              Text(
                                                'Price:',
                                                style: TextStyle(
                                                  color: Colors.black,
                                                  fontSize: 20,
                                                  fontWeight: FontWeight.w600,
                                                ),
                                              ),
                                              Divider(),
                                              Container(
                                                child: Column(
                                                  crossAxisAlignment:
                                                      CrossAxisAlignment.start,
                                                  children: [
                                                    SizedBox(height: 10),
                                                    // ! Rangle slider next update
                                                    // FlutterSlider(
                                                    //   values: [0, 25000],
                                                    //   rangeSlider: true,
                                                    //   min: 0,
                                                    //   max: 25000,
                                                    //   onDragging:
                                                    //       (handlerIndex, lowerValue, upperValue) {
                                                    //     setState(() {
                                                    //       _lowerValue = lowerValue;
                                                    //       _upperValue = upperValue;
                                                    //     });
                                                    //     print("lowervalue: $_lowerValue");
                                                    //     print("upperValue: $_upperValue");
                                                    //   },
                                                    // )
                                                    Row(
                                                      mainAxisAlignment:
                                                          MainAxisAlignment
                                                              .spaceBetween,
                                                      children: [
                                                        Padding(
                                                          padding:
                                                              const EdgeInsets
                                                                      .only(
                                                                  left: 10),
                                                          child: Container(
                                                            width: 80,
                                                            decoration:
                                                                BoxDecoration(
                                                              border:
                                                                  Border.all(
                                                                color:
                                                                    Colors.grey,
                                                              ),
                                                              borderRadius:
                                                                  BorderRadius
                                                                      .circular(
                                                                          5),
                                                            ),
                                                            child:
                                                                TextFormField(
                                                              controller:
                                                                  mincontroller,
                                                              keyboardType: TextInputType
                                                                  .numberWithOptions(
                                                                      signed:
                                                                          true),
                                                              inputFormatters: [
                                                                FilteringTextInputFormatter
                                                                    .digitsOnly,
                                                              ],
                                                              decoration:
                                                                  new InputDecoration(
                                                                border:
                                                                    InputBorder
                                                                        .none,
                                                                focusedBorder:
                                                                    InputBorder
                                                                        .none,
                                                                enabledBorder:
                                                                    InputBorder
                                                                        .none,
                                                                errorBorder:
                                                                    InputBorder
                                                                        .none,
                                                                disabledBorder:
                                                                    InputBorder
                                                                        .none,
                                                                contentPadding:
                                                                    EdgeInsets
                                                                        .only(
                                                                  left: 10,
                                                                  // bottom: 11,
                                                                  // top: 11,
                                                                  // right: 15,
                                                                ),
                                                                hintText: "min",
                                                              ),
                                                            ),
                                                          ),
                                                        ),
                                                        Padding(
                                                          padding:
                                                              const EdgeInsets
                                                                      .only(
                                                                  right: 10),
                                                          child: Container(
                                                            width: 80,
                                                            decoration:
                                                                BoxDecoration(
                                                              border:
                                                                  Border.all(
                                                                color:
                                                                    Colors.grey,
                                                              ),
                                                              borderRadius:
                                                                  BorderRadius
                                                                      .circular(
                                                                          5),
                                                            ),
                                                            child:
                                                                TextFormField(
                                                              controller:
                                                                  maxcontroller,
                                                              keyboardType: TextInputType
                                                                  .numberWithOptions(
                                                                      signed:
                                                                          true),
                                                              inputFormatters: [
                                                                FilteringTextInputFormatter
                                                                    .digitsOnly,
                                                              ],
                                                              decoration:
                                                                  new InputDecoration(
                                                                border:
                                                                    InputBorder
                                                                        .none,
                                                                focusedBorder:
                                                                    InputBorder
                                                                        .none,
                                                                enabledBorder:
                                                                    InputBorder
                                                                        .none,
                                                                errorBorder:
                                                                    InputBorder
                                                                        .none,
                                                                disabledBorder:
                                                                    InputBorder
                                                                        .none,
                                                                contentPadding:
                                                                    EdgeInsets
                                                                        .only(
                                                                  left: 10,
                                                                  // bottom: 11,
                                                                  // top: 11,
                                                                  // right: 15,
                                                                ),
                                                                hintText: "max",
                                                              ),
                                                            ),
                                                          ),
                                                        ),
                                                      ],
                                                    ),
                                                    SizedBox(height: 15),
                                                  ],
                                                ),
                                              ),
                                            ],
                                          ),
                                        ),
                                      ),
                                    ),
                                  ],
                                ),
                                Align(
                                  alignment: Alignment.bottomCenter,
                                  child: Row(
                                    mainAxisAlignment:
                                        MainAxisAlignment.spaceBetween,
                                    children: [
                                      InkWell(
                                        onTap: () {
                                          builderState(() {
                                            _dropdowntextValues.clear();
                                            _textFieldValues.clear();
                                            mincontroller.clear();
                                            maxcontroller.clear();
                                          });
                                        },
                                        child: Container(
                                          width: MediaQuery.of(context)
                                                  .size
                                                  .width *
                                              0.4,
                                          height: 40,
                                          decoration: BoxDecoration(
                                            color: Color(0xFFF9F9F9),
                                            borderRadius:
                                                BorderRadius.circular(5),
                                          ),
                                          child: Center(
                                            child: Text(
                                              'Clear All',
                                              style: TextStyle(
                                                fontSize: 16,
                                                fontWeight: FontWeight.w500,
                                              ),
                                            ),
                                          ),
                                        ),
                                      ),
                                      InkWell(
                                        onTap: () {
                                          if (_dropdowntextValues.isNotEmpty ||
                                              mincontroller.text.isNotEmpty ||
                                              maxcontroller.text.isNotEmpty) {
                                            builderState(() {
                                              _dropdowntextValues.addAll({
                                                "price": [
                                                  mincontroller.text.trim(),
                                                  maxcontroller.text.trim(),
                                                ]
                                              });
                                            });
                                            // print(_dropdowntextValues);
                                            Loader.show(context);
                                            filter = json
                                                .encode(_dropdowntextValues);
                                            Provider.of<FilterProducts>(
                                                    this.context,
                                                    listen: false)
                                                .filterbyCategories(
                                              refresh: true,
                                              authtoken: authToken ?? '',
                                              categoryId: widget.categoryId,
                                              country: widget.countryname,
                                              state: widget.statename,
                                              city: widget.cityname,
                                              area: widget.areaname,
                                              sort: sort.isEmpty ? "{}" : sort,
                                              filters: filter.isEmpty
                                                  ? "{}"
                                                  : filter,
                                            )
                                                .then((value) {
                                              Loader.hide();
                                              Navigator.pop(context);
                                            });
                                          }
                                        },
                                        child: Container(
                                          width: MediaQuery.of(context)
                                                  .size
                                                  .width *
                                              0.4,
                                          height: 40,
                                          decoration: BoxDecoration(
                                            color: Color(0xFF30BFFD),
                                            borderRadius:
                                                BorderRadius.circular(5),
                                          ),
                                          child: Center(
                                            child: Text(
                                              'Apply',
                                              style: TextStyle(
                                                fontSize: 16,
                                                fontWeight: FontWeight.w500,
                                              ),
                                            ),
                                          ),
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                              ],
                            ),
                          ),
                        )
                      ],
                    ),
                  ],
                ),
              ),
            );
          },
        );
      },
    );
  }

  Widget dropDown({
    required String hintText,
    required String? selectedValue,
    required List<String> listValues,
    required Function(String? value) onChanged,
  }) {
    return Padding(
      padding: const EdgeInsets.all(7),
      child: Container(
        decoration: BoxDecoration(
          boxShadow: [
            BoxShadow(
              color: Colors.grey.withOpacity(0.3),
              spreadRadius: 0.7,
              blurRadius: 2,
              offset: Offset(0, 0), // changes position of shadow
            ),
          ],
          color: Colors.white,
          borderRadius: BorderRadius.circular(5),
        ),
        child: ListTile(
          title: DropdownButtonHideUnderline(
            child: DropdownButton<String>(
              hint: Text(hintText),
              style: TextStyle(fontSize: 20, color: Colors.black),
              onChanged: onChanged,
              value: selectedValue,
              items: listValues.map(
                (String _value) {
                  return DropdownMenuItem<String>(
                    value: _value,
                    child: new Text(
                      _value,
                      style: TextStyle(fontSize: 20),
                    ),
                  );
                },
              ).toList(),
            ),
          ),
        ),
      ),
    );
  }

  refreshPage() {
    Provider.of<FilterProducts>(this.context, listen: false)
        .filterbyCategories(
      refresh: true,
      authtoken: authToken ?? '',
      categoryId: widget.categoryId,
      country: widget.countryname,
      state: widget.statename,
      city: widget.cityname,
      area: widget.areaname,
      sort: sort.isEmpty ? "{}" : sort,
      filters: filter.isEmpty ? "{}" : filter,
    )
        .then((value) {
      if (value["status"] == 200) {
        Map<String, dynamic> _response = value["response"];
        Map<String, dynamic> _data = _response["data"];
        Map<String, dynamic> _info = _data["info"];
        List _productdetails = _info["products"];
        if (_productdetails.isEmpty) {
          refreshController.refreshCompleted();
        } else {
          refreshController.refreshCompleted();
        }
      } else {
        refreshController.refreshFailed();
      }
    });
  }

  searchPagination({
    required String latitude,
    required String longitude,
  }) {
    Provider.of<SearchProduct>(context, listen: false)
        .searchproduct(
      refresh: false,
      authtoken: authToken == null ? '' : 'Bearer $authToken',
      categoryId: '',
      latitude: latitude == "0.0" ? GetStoredInfo.latitude : latitude,
      longitude: longitude == "0.0" ? GetStoredInfo.longitude : longitude,
      name: searchcontroller.text,
    )
        .then((value) {
      if (value["status"] == 200) {
        Map<String, dynamic> _response = value["response"];
        Map<String, dynamic> _data = _response["data"];
        Map<String, dynamic> _info = _data["info"];
        List _productdetails = _info["products"];
        if (_productdetails.isEmpty) {
          refreshController.loadComplete();
        } else {
          refreshController.loadComplete();
        }
      } else {
        refreshController.loadFailed();
      }
    });
  }

  homePagination() {
    Provider.of<FilterProducts>(context, listen: false)
        .filterbyCategories(
      refresh: false,
      authtoken: authToken ?? '',
      categoryId: widget.categoryId,
      country: widget.countryname,
      state: widget.statename,
      city: widget.cityname,
      area: widget.areaname,
      sort: sort.isEmpty ? "{}" : sort,
      filters: filter.isEmpty ? "{}" : filter,
    )
        .then((value) {
      if (value["status"] == 200) {
        Map<String, dynamic> _response = value["response"];
        Map<String, dynamic> _data = _response["data"];
        Map<String, dynamic> _info = _data["info"];
        List _productdetails = _info["products"];
        if (_productdetails.isEmpty) {
          refreshController.loadComplete();
        } else {
          refreshController.loadComplete();
        }
      } else {
        refreshController.loadFailed();
      }
    });
  }

  Widget dynamicWidget({
    required Map<String, dynamic> productfilter,
    required int index,
    required List<dynamic> fields,
    required builderState,
  }) {
    if (fieldType == "dropdown") {
      List<String> dropdownValues = [];
      for (int i = 0;
          i < fields[index]["codeGroup"]["codeValues"].length;
          i++) {
        dropdownValues.add(fields[index]["codeGroup"]["codeValues"][i]["name"]);
      }
      // print("Dropdown values: $dropdownValues");
      // print("values: ${_textFieldValues[fields[index]['label']]}");
      return dropDown(
        hintText: productfilter["fields"][index]["displayText"],
        listValues: dropdownValues.toSet().toList(),
        onChanged: (value) {
          builderState(() {
            // print(fields[index]["codeGroup"]["codeValues"]);
            for (int i = 0;
                i < fields[index]["codeGroup"]["codeValues"].length;
                i++) {
              if (fields[index]["codeGroup"]["codeValues"][i]["name"] ==
                  value) {
                setState(() {
                  _dropdownValueId =
                      fields[index]["codeGroup"]["codeValues"][i]["_id"];
                });
              }
            }
            _textFieldValues.addAll({"${fields[index]["label"]}": value!});
            _dropdowntextValues
                .addAll({"${fields[index]["name"]}": _dropdownValueId!});
          });
        },
        selectedValue: (_textFieldValues.isNotEmpty &&
                _textFieldValues.containsKey(fields[index]["label"]))
            ? _textFieldValues[fields[index]['label']]
            : null,
      );
    } else {
      return Container();
    }
  }
}
