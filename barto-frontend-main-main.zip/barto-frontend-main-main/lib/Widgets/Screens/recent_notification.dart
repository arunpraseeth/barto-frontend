import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/material.dart';
import 'package:flutter_svg/svg.dart';
import 'package:india/Common/loading_bool.dart';
import 'package:india/Common/loading_widget.dart';
import 'package:india/Services/domain.dart';
import 'package:india/Services/get_products.dart';
import 'package:india/Services/notification.dart';
import 'package:india/Services/user_data.dart';
import 'package:india/Widgets/Screens/specific_product.dart';
import 'package:provider/provider.dart';

class RecentNotifcations extends StatelessWidget {
  const RecentNotifcations({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    Size size = MediaQuery.of(context).size;
    bool _loading = Provider.of<BoolLoader>(context).loadingStatus;
    String authtoken = Provider.of<UserData>(context).authtoken;
    List<dynamic> _notificationsList =
        Provider.of<NotificationApi>(context).notificationList;
    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
        centerTitle: true,
        elevation: 2,
        backgroundColor: Color(0xFFF9F9F9),
        title: Text('Recent Notifications'),
      ),
      body: _loading
          ? LoadingWidget()
          : _notificationsList.isEmpty
              ? Center(
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      SvgPicture.asset(
                        'assets/placeholders/nonotification.svg',
                        height: 250,
                      ),
                      SizedBox(height: 15),
                      Text(
                        "No notifications available.",
                        style: TextStyle(
                          fontSize: 18,
                        ),
                      ),
                    ],
                  ),
                )
              : ListView.builder(
                  itemCount: _notificationsList.length,
                  itemBuilder: (listviewcontext, index) {
                    Map<String, dynamic> _payload =
                        _notificationsList[index]["payload"];
                    String _productId = _payload["productId"];
                    print(_notificationsList[index]["notify_img_url"]);
                    return Container(
                      margin: EdgeInsets.symmetric(horizontal: 10, vertical: 8),
                      height: size.height * 0.08,
                      decoration: BoxDecoration(
                        boxShadow: [
                          BoxShadow(
                            color: Colors.grey.withOpacity(0.3),
                            spreadRadius: 0.7,
                            blurRadius: 2,
                            offset: Offset(0, 0), // changes position of shadow
                          ),
                        ],
                        color: Colors.white,
                        borderRadius: BorderRadius.circular(10),
                      ),
                      child: Center(
                        child: ListTile(
                          onTap: () {
                            Provider.of<BoolLoader>(context, listen: false)
                                .boolLoader(status: true);
                            Provider.of<ProductInformation>(context,
                                    listen: false)
                                .getproductInformation(
                              authtoken: authtoken,
                              productid: _productId,
                            )
                                .then((value) {
                              if (value["status"] == 200) {
                                Navigator.push(
                                  context,
                                  MaterialPageRoute(
                                    builder: (_) => SpecificProduct(),
                                  ),
                                ).then((value) {
                                  if (value != "specificProduct") {
                                    WidgetsBinding.instance
                                        ?.addPostFrameCallback((duration) {
                                      Provider.of<NotificationApi>(context,
                                              listen: false)
                                          .getnotificationapi(
                                        authtoken: authtoken,
                                      );
                                    });
                                  }
                                });
                                NotificationApi.deletenotificationapi(
                                  index: "$index",
                                  authtoken: authtoken,
                                );
                              }
                              Provider.of<BoolLoader>(context, listen: false)
                                  .boolLoader(status: false);
                            });
                          },
                          leading: //Product Image
                              _notificationsList[index]["notify_img_url"] ==
                                      null
                                  ? Icon(
                                      Icons.person,
                                      size: 50,
                                      color: Colors.grey,
                                    )
                                  : CircleAvatar(
                                      radius: 25,
                                      child: ClipOval(
                                        child: AspectRatio(
                                          aspectRatio: 1 / 1,
                                          child: CachedNetworkImage(
                                            fit: BoxFit.fill,
                                            height: size.height * 0.13,
                                            imageUrl:
                                                "${Domain.url}${_notificationsList[index]["notify_img_url"]}",
                                            placeholder: (context, url) => Icon(
                                              Icons.image,
                                              size: 50,
                                              color: Colors.grey,
                                            ),
                                            errorWidget:
                                                (context, url, error) =>
                                                    new Icon(Icons.error),
                                          ),
                                        ),
                                      ),
                                    ),
                          title: Text(
                            _notificationsList[index]["title"],
                            style: TextStyle(
                              fontSize: size.height * 0.02,
                            ),
                          ),
                        ),
                      ),
                    );
                  },
                ),
    );
  }
}
