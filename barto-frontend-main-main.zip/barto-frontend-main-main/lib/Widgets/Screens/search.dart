import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/material.dart';
import 'dart:io' show Platform;
import 'package:flutter_svg/flutter_svg.dart';
import 'package:india/Common/color.dart';
import 'package:india/Common/loading_bool.dart';
import 'package:india/Common/loading_widget.dart';
import 'package:india/Common/show_toast.dart';
import 'package:india/Model/location.dart';
import 'package:india/Model/shared_pref.dart';
import 'package:india/Services/domain.dart';
import 'package:india/Services/get_home.dart';
import 'package:india/Services/get_products.dart';
import 'package:india/Services/search_product.dart';
import 'package:india/Services/wishlist.dart';
import 'package:india/Widgets/Authentication/Signin/login_bottommodal.dart';
import 'package:india/Widgets/Screens/filterby_location.dart';
import 'package:india/Widgets/Screens/specific_product.dart';
import 'package:provider/provider.dart';
import 'package:pull_to_refresh/pull_to_refresh.dart';

// ignore: must_be_immutable
class SearchPage extends StatefulWidget {
  String authtoken;
  SearchPage({
    required this.authtoken,
  });

  @override
  _SearchPageState createState() => _SearchPageState();
}

class _SearchPageState extends State<SearchPage> {
  TextEditingController searchcontroller = TextEditingController();
  RefreshController refreshController =
      RefreshController(initialRefresh: false);
  String searchproduct = '';
  LoginModalSheet loginModalSheet = LoginModalSheet();
  List _searchedList = [];
  @override
  Widget build(BuildContext context) {
    Size size = MediaQuery.of(context).size;
    bool _loading = Provider.of<BoolLoader>(context).loadingStatus;
    String latitude = Provider.of<StoreLocation>(context).latitude.toString();
    String longitude = Provider.of<StoreLocation>(context).longitude.toString();
    String mapboxPlacename = Provider.of<StoreLocation>(context).placename;
    return Scaffold(
      backgroundColor: Colors.white,
      resizeToAvoidBottomInset: false,
      body: _loading
          ? LoadingWidget()
          : SafeArea(
              child: SmartRefresher(
                controller: refreshController,
                enablePullDown: true,
                enablePullUp: true,
                onRefresh: () {
                  onRefresh(
                    context: context,
                    authtoken: widget.authtoken,
                    latitude: latitude,
                    longitude: longitude,
                  );
                },
                onLoading: () {
                  onLoading(
                    context: context,
                    authtoken: widget.authtoken,
                    latitude: latitude,
                    longitude: longitude,
                  );
                },
                child: CustomScrollView(
                  slivers: [
                    SliverAppBar(
                      elevation: 2,
                      forceElevated: true,
                      backgroundColor: Color(0xFFF9F9F9),
                      automaticallyImplyLeading: false,
                      title: InkWell(
                        onTap: () {
                          Provider.of<BoolLoader>(context, listen: false)
                              .boolLoader(status: false);
                          Navigator.push(
                            context,
                            MaterialPageRoute(
                              builder: (_) => FilterProductLocation(
                                savedlat: GetStoredInfo.latitude,
                                savedlong: GetStoredInfo.longitude,
                                page: 2,
                              ),
                            ),
                          );
                        },
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            IconButton(
                              onPressed: () {
                                Navigator.of(context).pop("Searchpage");
                              },
                              icon: Icon(
                                Platform.isAndroid
                                    ? Icons.arrow_back
                                    : Icons.arrow_back_ios,
                              ),
                            ),
                            Flexible(
                              child: Row(
                                children: [
                                  Icon(
                                    Icons.location_on,
                                    color: Color(0xFF30BFFD),
                                    size: size.width * 0.045,
                                  ),
                                  SizedBox(width: 10),
                                  Flexible(
                                    child: Text(
                                      GetStoredInfo.placename.isEmpty
                                          ? "My Location"
                                          : mapboxPlacename.isNotEmpty
                                              ? mapboxPlacename
                                              : GetStoredInfo.placename,
                                      style: TextStyle(
                                        fontSize: size.width * 0.035,
                                        color: Colors.black,
                                        fontWeight: FontWeight.w500,
                                      ),
                                      maxLines: 1,
                                      overflow: TextOverflow.ellipsis,
                                      softWrap: false,
                                    ),
                                  ),
                                  Icon(
                                    Icons.expand_more,
                                    color: Color(0xFF30BFFD),
                                    size: size.width * 0.045,
                                  ),
                                ],
                              ),
                            ),
                          ],
                        ),
                      ),
                      expandedHeight: size.width > 400
                          ? size.height * 0.16
                          : size.height * 0.18,

                      // expandedHeight: 120.0,
                      flexibleSpace: FlexibleSpaceBar(
                        background: Material(
                          elevation: 2,
                          child: Column(
                            children: [
                              SizedBox(
                                height: size.height * 0.070,
                              ),
                              Stack(
                                children: [
                                  Padding(
                                    padding: const EdgeInsets.symmetric(
                                        horizontal: 15),
                                    child: Container(
                                      decoration: BoxDecoration(
                                        borderRadius: BorderRadius.circular(5),
                                        color: Colors.white,
                                        boxShadow: [
                                          BoxShadow(
                                            color: Colors.grey.withOpacity(0.3),
                                            spreadRadius: 0.7,
                                            blurRadius: 2,
                                            offset: Offset(0,
                                                0), // changes position of shadow
                                          ),
                                        ],
                                      ),
                                      child: ListTile(
                                        title: TextFormField(
                                          controller: searchcontroller,
                                          style: TextStyle(fontSize: 20),
                                          decoration: InputDecoration(
                                            hintText: "Search...",
                                            border: InputBorder.none,
                                          ),
                                          // ! BITCH, I SERIOUSLY DON'T UNDERSTAND HOW THIS CODE WORKS.
                                          //! NEVERTHLESS I WROTE THIS FUCKING CODE. FUCK!!! HAVE TO CHECK THIS.
                                          onChanged: (String value) {
                                            setState(() {
                                              searchproduct = value;
                                            });
                                            if (searchproduct.isEmpty) {
                                              setState(() {
                                                _searchedList.clear();
                                              });
                                            } else {
                                              Provider.of<SearchProduct>(
                                                      context,
                                                      listen: false)
                                                  .searchproduct(
                                                refresh: true,
                                                name: searchproduct,
                                                authtoken:
                                                    widget.authtoken.isEmpty
                                                        ? ''
                                                        : "${widget.authtoken}",
                                                categoryId: '',
                                                latitude: latitude == "0.0"
                                                    ? GetStoredInfo.latitude
                                                    : latitude,
                                                longitude: longitude == "0.0"
                                                    ? GetStoredInfo.longitude
                                                    : longitude,
                                              )
                                                  .then((value) {
                                                if (value["status"] == 200) {
                                                  Map<String, dynamic>
                                                      _response =
                                                      value["response"];
                                                  Map<String, dynamic> _data =
                                                      _response["data"];
                                                  Map<String, dynamic> _info =
                                                      _data["info"];
                                                  setState(() {
                                                    _searchedList =
                                                        _info["products"];
                                                  });
                                                } else {
                                                  setState(() {
                                                    _searchedList.clear();
                                                  });
                                                  ShowToast.showToast(
                                                    context,
                                                    exception:
                                                        "No such products available",
                                                  );
                                                }
                                              });
                                            }
                                          },
                                          // onChanged: (String searchedvalue) {
                                          //   if (searchedvalue.length >= 3) {
                                          //     Provider.of<SearchProduct>(
                                          //             context,
                                          //             listen: false)
                                          //         .clearSearch();
                                          //     Provider.of<SearchProduct>(
                                          //             context,
                                          //             listen: false)
                                          //         .searchproduct(
                                          //       refresh: true,
                                          //       name: searchedvalue,
                                          //       authtoken: widget.authtoken,
                                          //       categoryId: '',
                                          //       latitude: latitude == "0.0"
                                          //           ? GetStoredInfo.latitude
                                          //           : latitude,
                                          //       longitude: longitude == "0.0"
                                          //           ? GetStoredInfo.longitude
                                          //           : longitude,
                                          //     )
                                          //         .then((value) {
                                          //       if (value["status"] != 200) {
                                          //         ShowToast.showToast(
                                          //           context,
                                          //           exception:
                                          //               "No such products available",
                                          //         );
                                          //       }
                                          //     });
                                          //   } else {
                                          //     Provider.of<SearchProduct>(
                                          //             context,
                                          //             listen: false)
                                          //         .clearSearch();
                                          //   }
                                          // },
                                        ),
                                        trailing: Transform.translate(
                                          offset: Offset(10, 0),
                                          child: IconButton(
                                              onPressed: () {
                                                Provider.of<SearchProduct>(
                                                        context,
                                                        listen: false)
                                                    .searchproduct(
                                                  refresh: true,
                                                  name: searchcontroller.text
                                                      .trim(),
                                                  authtoken: widget.authtoken,
                                                  categoryId: '',
                                                  latitude: latitude == "0.0"
                                                      ? GetStoredInfo.latitude
                                                      : latitude,
                                                  longitude: longitude == "0.0"
                                                      ? GetStoredInfo.longitude
                                                      : longitude,
                                                )
                                                    .then((value) {
                                                  if (value["status"] != 200) {
                                                    ShowToast.showToast(
                                                      context,
                                                      exception:
                                                          "No such products available",
                                                    );
                                                  }
                                                });
                                              },
                                              icon:
                                                  // searchcontroller.text == ""
                                                  //     ?
                                                  Icon(Icons.search, size: 25)
                                              // :
                                              // Icon(Icons.clear, size: 25),
                                              ),
                                        ),
                                      ),
                                    ),
                                  ),
                                ],
                              ),
                            ],
                          ),
                        ),
                      ),
                    ),
                    SliverToBoxAdapter(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          _searchedList.isEmpty
                              ? Column(
                                  children: [
                                    SizedBox(height: size.height * 0.15),
                                    Center(
                                      child: Padding(
                                        padding: const EdgeInsets.symmetric(
                                            horizontal: 15),
                                        child: SvgPicture.asset(
                                          "assets/placeholders/search.svg",
                                          height: 250,
                                        ),
                                      ),
                                    ),
                                    // SizedBox(height: 20),
                                    // Text(
                                    //   'No products in chosen location.',
                                    //   style: TextStyle(
                                    //     fontSize: 20,
                                    //   ),
                                    // ),
                                  ],
                                )
                              : gridview(
                                  size,
                                  product: _searchedList,
                                  latitude: latitude,
                                  longitude: longitude,
                                ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            ),
    );
  }

  Widget gridview(
    Size size, {
    required List product,
    required String latitude,
    required String longitude,
  }) {
    return GridView.builder(
      shrinkWrap: true,
      physics: ScrollPhysics(),
      itemCount: product.length,
      padding: EdgeInsets.all(3),
      gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
        childAspectRatio: size.width < 500 ? 0.85 : 1.1,
        crossAxisCount: 2,
      ),
      itemBuilder: (BuildContext gridviewcontext, int index) {
        Map<String, dynamic> _productLocation =
            product[index]["product_location"];
        String areaname = _productLocation["area"];
        String cityname = _productLocation["city"];
        String statename = _productLocation["state"];
        String countryname = _productLocation["country"];
        bool _featured = product[index]["featured"];
        return InkWell(
          onTap: () {
            Provider.of<BoolLoader>(this.context, listen: false)
                .boolLoader(status: true);
            Provider.of<ProductInformation>(this.context, listen: false)
                .getproductInformation(
              authtoken: widget.authtoken.isEmpty ? null : widget.authtoken,
              productid: product[index]["_id"],
            )
                .then(
              (value) {
                if (value["status"] == 200) {
                  Navigator.push(
                    this.context,
                    MaterialPageRoute(
                      builder: (_) => SpecificProduct(),
                    ),
                  ).then(
                    (value) {
                      if (value == "specificProduct") {
                        WidgetsBinding.instance?.addPostFrameCallback(
                          (duration) {
                            Provider.of<SearchProduct>(context, listen: false)
                                .searchproduct(
                              refresh: true,
                              name: searchcontroller.text.trim(),
                              authtoken: widget.authtoken,
                              categoryId: '',
                              latitude: latitude == "0.0"
                                  ? GetStoredInfo.latitude
                                  : latitude,
                              longitude: longitude == "0.0"
                                  ? GetStoredInfo.longitude
                                  : longitude,
                            );
                            // Provider.of<GetHome>(context, listen: false)
                            //     .clearProductsList();
                            Provider.of<GetHome>(context, listen: false)
                                .getProducts(
                              refresh: true,
                              authtoken: widget.authtoken,
                              lat: latitude == "0.0"
                                  ? GetStoredInfo.latitude
                                  : latitude,
                              long: longitude == "0.0"
                                  ? GetStoredInfo.longitude
                                  : longitude,
                            );
                          },
                        );
                      }
                    },
                  );
                }
                Provider.of<BoolLoader>(this.context, listen: false)
                    .boolLoader(status: false);
              },
            );
          },
          child: Padding(
            padding: const EdgeInsets.all(8.0),
            child: Container(
              decoration: BoxDecoration(
                boxShadow: [
                  BoxShadow(
                    color: Colors.grey.withOpacity(0.3),
                    spreadRadius: 0.7,
                    blurRadius: 2,
                    offset: Offset(0, 0), // changes position of shadow
                  ),
                ],
                color: Colors.white,
                borderRadius: BorderRadius.circular(10),
              ),
              child: Stack(
                children: [
                  Center(
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        //Product Image
                        product[index]["product_image"] == null
                            ? Icon(
                                Icons.person,
                                size: 50,
                                color: Colors.grey,
                              )
                            : CachedNetworkImage(
                                fit: BoxFit.cover,
                                height: size.height * 0.13,
                                imageUrl:
                                    "${Domain.url}${product[index]["product_image"]}",
                                placeholder: (context, url) => Icon(
                                  Icons.image,
                                  size: 50,
                                  color: Colors.grey,
                                ),
                                errorWidget: (context, url, error) =>
                                    new Icon(Icons.error),
                              ),
                        SizedBox(height: size.height * 0.01),
                        //Product Name
                        Text(
                          product[index]["product_name"],
                          style: TextStyle(
                            fontSize: size.width * 0.043,
                            fontWeight: FontWeight.w600,
                          ),
                        ),
                        SizedBox(height: size.height * 0.008),
                        //Product Price
                        Text(
                          product[index]["price"],
                          style: TextStyle(
                            fontSize: size.width * 0.038,
                          ),
                        ),
                        SizedBox(height: size.height * 0.01),
                        //Product uploaded Location
                        Row(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            SizedBox(width: 10),
                            Icon(
                              Icons.location_on,
                              // size: 20,
                              size: size.width * 0.032,
                            ),
                            Flexible(
                              child: Container(
                                child: Padding(
                                  padding: const EdgeInsets.only(right: 10),
                                  child: Text(
                                    (areaname.isEmpty &&
                                            cityname.isEmpty &&
                                            statename.isEmpty)
                                        ? countryname
                                        : (areaname.isEmpty && cityname.isEmpty)
                                            ? "$statename, $countryname"
                                            : (areaname.isEmpty)
                                                ? "$cityname, $statename"
                                                : "$areaname, $cityname",
                                    maxLines: 1,
                                    overflow: TextOverflow.ellipsis,
                                    softWrap: false,
                                    style: TextStyle(
                                      fontSize: size.width * 0.033,
                                    ),
                                  ),
                                ),
                              ),
                            ),
                          ],
                        ),
                      ],
                    ),
                  ),
                  // Wishlist
                  Align(
                    alignment: Alignment.topRight,
                    child: IconButton(
                      onPressed: () {
                        Provider.of<BoolLoader>(context, listen: false)
                            .boolLoader(status: false);
                        if (widget.authtoken.isEmpty) {
                          loginModalSheet.bottomModalSheet(context: context);
                        } else {
                          setState(() {
                            product[index]["wishlist"] =
                                !product[index]["wishlist"];
                          });
                          if (product[index]["wishlist"] == true) {
                            Provider.of<Wishlist>(context, listen: false)
                                .addWishslist(
                              productid: product[index]["_id"],
                              authtoken: widget.authtoken,
                            );
                          } else {
                            Provider.of<Wishlist>(context, listen: false)
                                .removeWishslist(
                              productid: product[index]["_id"],
                              authtoken: widget.authtoken,
                            );
                          }
                        }
                      },
                      icon: product[index]["wishlist"]
                          ? Icon(
                              Icons.favorite,
                              color: colorBlue,
                              size: 22,
                            )
                          : Container(
                              width: 25,
                              height: 25,
                              decoration: BoxDecoration(
                                borderRadius: BorderRadius.circular(50),
                                color: colorBlue.withOpacity(0.7),
                              ),
                              child: Icon(
                                Icons.favorite,
                                color: Colors.white,
                                size: 17,
                              ),
                            ),
                    ),
                  ),
                  // Featured
                  _featured
                      ? Container(
                          width: size.width * 0.20,
                          height: size.height * 0.030,
                          decoration: BoxDecoration(
                            borderRadius: BorderRadius.only(
                              bottomRight: Radius.circular(10),
                            ),
                            color: colorBlue,
                          ),
                          child: Center(
                            child: Text(
                              "Featured",
                              style: TextStyle(
                                fontSize: size.width * 0.035,
                                fontWeight: FontWeight.w500,
                                color: Colors.white,
                              ),
                            ),
                          ),
                        )
                      : Container(),
                ],
              ),
            ),
          ),
        );
      },
    );
  }

  onRefresh({
    required BuildContext context,
    required String authtoken,
    required String latitude,
    required String longitude,
  }) {
    Provider.of<SearchProduct>(context, listen: false)
        .searchproduct(
      refresh: true,
      authtoken: authtoken,
      categoryId: '',
      latitude: latitude == "0.0" ? GetStoredInfo.latitude : latitude,
      longitude: longitude == "0.0" ? GetStoredInfo.longitude : longitude,
      name: searchcontroller.text,
    )
        .then((value) {
      if (value["status"] == 200) {
        Map<String, dynamic> _response = value["response"];
        Map<String, dynamic> _data = _response["data"];
        Map<String, dynamic> _info = _data["info"];
        List _productdetails = _info["products"];
        if (_productdetails.isEmpty) {
          refreshController.refreshCompleted();
        } else {
          refreshController.refreshCompleted();
        }
      } else {
        refreshController.refreshFailed();
      }
    });
  }

  onLoading({
    required BuildContext context,
    required String authtoken,
    required String latitude,
    required String longitude,
  }) {
    Provider.of<SearchProduct>(context, listen: false)
        .searchproduct(
      refresh: false,
      authtoken: authtoken,
      categoryId: '',
      latitude: latitude == "0.0" ? GetStoredInfo.latitude : latitude,
      longitude: longitude == "0.0" ? GetStoredInfo.longitude : longitude,
      name: searchcontroller.text,
    )
        .then((value) {
      if (value["status"] == 200) {
        Map<String, dynamic> _response = value["response"];
        Map<String, dynamic> _data = _response["data"];
        Map<String, dynamic> _info = _data["info"];
        List _productdetails = _info["products"];
        if (_productdetails.isEmpty) {
          refreshController.loadComplete();
        } else {
          refreshController.loadComplete();
        }
      } else {
        refreshController.loadFailed();
      }
    });
  }
}
