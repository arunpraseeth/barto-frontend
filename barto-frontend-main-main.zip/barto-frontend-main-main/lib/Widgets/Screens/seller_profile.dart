import 'dart:io' show Platform;
import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/material.dart';
import 'package:india/Common/color.dart';
import 'package:india/Common/loading_bool.dart';
import 'package:india/Common/loading_widget.dart';
import 'package:india/Common/show_toast.dart';
import 'package:india/Model/location.dart';
import 'package:india/Model/shared_pref.dart';
import 'package:india/Services/domain.dart';
import 'package:india/Services/get_home.dart';
import 'package:india/Services/get_products.dart';
import 'package:india/Services/seller_details.dart';
import 'package:india/Services/user_data.dart';
import 'package:india/Services/wishlist.dart';
import 'package:india/Widgets/Authentication/Signin/login_bottommodal.dart';
import 'package:india/Widgets/Screens/bottom_navbar.dart';
import 'package:india/Widgets/Screens/specific_product.dart';
import 'package:provider/provider.dart';
import 'package:shared_preferences/shared_preferences.dart';
import "string_extension.dart";

// ignore: must_be_immutable
class SellerProfile extends StatefulWidget {
  String? userId;
  String? sellerId;
  SellerProfile({this.userId, this.sellerId});
  @override
  State<SellerProfile> createState() => _SellerProfileState();
}

class _SellerProfileState extends State<SellerProfile> {
  String? authToken;
  bool _loading = false;
  double maxradius = 68;
  LoginModalSheet loginModalSheet = LoginModalSheet();

  Future<String> getAuthToken() async {
    SharedPreferences sharedPreferences = await SharedPreferences.getInstance();
    authToken = sharedPreferences.getString("authtoken");
    // print('Auth token: $authToken');
    return authToken ?? '';
  }

  @override
  void initState() {
    getAuthToken();
    GetStoredInfo.getStoreInfo();
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    Size size = MediaQuery.of(context).size;
    Map<String, dynamic> sellerdetails =
        Provider.of<SellerDetails>(context).sellerDetail;
    List allDetails = sellerdetails["products"];
    String followerscount = sellerdetails["profile"]["followers"];
    String username = Provider.of<UserData>(context).username.toString();
    String latitude = Provider.of<StoreLocation>(context).latitude.toString();
    String longitude = Provider.of<StoreLocation>(context).longitude.toString();

    // followBool = sellerdetails["profile"]["isFollowing"];
    // print("Following count = $followerscount");
    // print("Following Bool = $followBool");
    // int followerscount = sellerdetails["profile"]["isFollowing"];
    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
        centerTitle: true,
        elevation: 2,
        backgroundColor: Color(0xFFF9F9F9),
        leading: IconButton(
          onPressed: () {
            Provider.of<BoolLoader>(context, listen: false)
                .boolLoader(status: false);
            Navigator.of(context).pop("SellerProfile");
          },
          icon: Icon(
            Platform.isAndroid ? Icons.arrow_back : Icons.arrow_back_ios,
          ),
        ),
        title: Text('Seller Profile'),
        actions: [
          PopupMenuButton(
            icon: Icon(Icons.more_vert),
            onSelected: (value) {
              setState(() {
                switch (value) {
                  case 1:
                    Provider.of<BoolLoader>(context, listen: false)
                        .boolLoader(status: false);
                    if (authToken == null) {
                      loginModalSheet.bottomModalSheet(context: context);
                    } else {
                      if (widget.userId != widget.sellerId) {
                        setState(() {
                          _loading = true;
                        });
                        SellerDetails.blockuser(
                          username: sellerdetails["profile"]["user_name"],
                          authtoken: authToken,
                        ).then((value) {
                          if (value["status"] == 200) {
                            // Provider.of<GetHome>(context, listen: false)
                            //     .clearProductsList();
                            filterbasedonLocation(
                              username: username,
                              latitude: latitude,
                              longitude: longitude,
                            );
                          } else {
                            setState(() {
                              _loading = false;
                            });
                            ShowToast.showToast(context,
                                exception: "Try again later");
                          }
                        });
                      } else {
                        ShowToast.showToast(context,
                            exception: "You cannot block yourself.");
                      }
                    }
                    break;
                }
              });
            },
            itemBuilder: (context) => [
              PopupMenuItem(
                value: 1,
                child: Text(
                  "Block",
                  style: TextStyle(fontWeight: FontWeight.w500, fontSize: 18),
                ),
              ),
            ],
          ),
        ],
      ),
      body: _loading
          ? LoadingWidget()
          : SingleChildScrollView(
              child: InkWell(
                onTap: () {
                  setState(() {
                    maxradius = 68;
                  });
                },
                child: Container(
                  child: Column(
                    children: [
                      SizedBox(height: 20),
                      Center(
                        child: InkWell(
                          onTap: () {
                            setState(() {
                              maxradius = 150;
                            });
                          },
                          // Profile Image
                          child: CircleAvatar(
                            radius: maxradius,
                            backgroundColor: Colors.grey[200],
                            child: ClipOval(
                              child: SizedBox(
                                child: AspectRatio(
                                  aspectRatio: 1 / 1,
                                  child: sellerdetails["profile"]["avatar"] ==
                                          null
                                      ? Icon(Icons.person, size: 100)
                                      : CachedNetworkImage(
                                          fit: BoxFit.cover,
                                          imageUrl:
                                              "${Domain.url}${sellerdetails["profile"]["avatar"]}",
                                          placeholder: (context, url) =>
                                              new CircularProgressIndicator(),
                                          errorWidget: (context, url, error) =>
                                              new Icon(Icons.error),
                                        ),
                                ),
                              ),
                            ),
                          ),
                        ),
                      ),
                      SizedBox(height: 20),
                      // User name
                      Text(
                        "${sellerdetails["profile"]["name"]}".capitalize(),
                        style: TextStyle(
                          fontSize: 25,
                          fontWeight: FontWeight.w600,
                        ),
                      ),
                      SizedBox(height: 10),
                      //Follow / Unfollow
                      Container(
                        decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(5),
                          color: colorBlue,
                          // color: Color(0xFFEAEAEA),
                        ),
                        child: Padding(
                          padding: const EdgeInsets.symmetric(
                            horizontal: 10,
                            vertical: 5,
                          ),
                          child: InkWell(
                            onTap: () {
                              Provider.of<BoolLoader>(context, listen: false)
                                  .boolLoader(status: false);
                              if (authToken == null) {
                                loginModalSheet.bottomModalSheet(
                                    context: context);
                              } else {
                                if ((widget.userId != widget.sellerId)) {
                                  Provider.of<SellerDetails>(context,
                                          listen: false)
                                      .followUser();
                                  Provider.of<SellerDetails>(context,
                                          listen: false)
                                      .followUnFollow(
                                    username: sellerdetails["profile"]
                                        ["user_name"],
                                    followstatus: Provider.of<SellerDetails>(
                                                context,
                                                listen: false)
                                            .followOrUnfollow
                                        ? "Follow"
                                        : "UnFollow",
                                    authtoken: authToken,
                                  )
                                      .then((value) {
                                    if (value["status"] == 400 &&
                                        value["error"]["message"] ==
                                            "You cannot follow/unfollow yourself") {
                                      ShowToast.showToast(context,
                                          exception:
                                              "You cannot follow/unfollow yourself");
                                    } else if (value["status"] == 200) {
                                      Provider.of<SellerDetails>(context,
                                              listen: false)
                                          .getsellerDetails(
                                        authtoken: authToken,
                                        username: sellerdetails["profile"]
                                            ["user_name"],
                                      );
                                    }
                                  });
                                } else {
                                  ShowToast.showToast(
                                    context,
                                    exception: 'You cannot follow yourself',
                                  );
                                }
                              }
                            },
                            child: Text(
                              Provider.of<SellerDetails>(context)
                                      .followOrUnfollow
                                  ? "Unfollow"
                                  : "Follow",
                              style: TextStyle(
                                  fontWeight: FontWeight.w500, fontSize: 16),
                            ),
                          ),
                        ),
                      ),
                      SizedBox(height: 10),
                      Padding(
                        padding: const EdgeInsets.symmetric(horizontal: 100),
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            // Followers
                            followContainer(
                              number:
                                  followerscount == "0" ? "0" : followerscount,
                              text: "Followers",
                            ),
                            // Posts
                            followContainer(
                              number: "${sellerdetails["total_products"]}",
                              text: "Posts",
                            ),
                          ],
                        ),
                      ),
                      SizedBox(height: 15),
                      Padding(
                        padding: const EdgeInsets.symmetric(horizontal: 10),
                        child: Divider(),
                      ),
                      GridView.builder(
                        shrinkWrap: true,
                        physics: ScrollPhysics(),
                        itemCount: allDetails.length,
                        padding: EdgeInsets.all(3),
                        gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                          childAspectRatio: size.width < 500 ? 0.85 : 1.1,
                          crossAxisCount: 2,
                        ),
                        itemBuilder: (BuildContext gridviewcontext, int index) {
                          Map<String, dynamic> _sellerDetails =
                              allDetails[index];
                          Map<String, dynamic> location =
                              _sellerDetails["product_location"];
                          String areaname = location["area"];
                          String cityname = location["city"];
                          String statename = location["state"];
                          String countryname = location["country"];
                          bool _featured = _sellerDetails["featured"];
                          return InkWell(
                            onTap: () {
                              setState(() {
                                _loading = true;
                              });
                              Provider.of<ProductInformation>(context,
                                      listen: false)
                                  .getproductInformation(
                                authtoken: authToken,
                                productid: _sellerDetails["_id"],
                              )
                                  .then((value) {
                                setState(() {
                                  _loading = false;
                                });
                                if (value["status"] == 200) {
                                  Navigator.push(
                                    this.context,
                                    MaterialPageRoute(
                                      builder: (_) => SpecificProduct(),
                                    ),
                                  ).then((value) {
                                    if (value == "specificProduct") {
                                      WidgetsBinding.instance
                                          ?.addPostFrameCallback(
                                        (duration) {
                                          Provider.of<SellerDetails>(context,
                                                  listen: false)
                                              .getsellerDetails(
                                                  authtoken: authToken,
                                                  username:
                                                      sellerdetails["profile"]
                                                          ["user_name"]);
                                          // Provider.of<GetHome>(context,
                                          //         listen: false)
                                          //     .clearProductsList();
                                          Provider.of<GetHome>(context,
                                                  listen: false)
                                              .getProducts(
                                            refresh: true,
                                            authtoken: authToken ?? '',
                                            lat: latitude == "0.0"
                                                ? GetStoredInfo.latitude
                                                : latitude,
                                            long: longitude == "0.0"
                                                ? GetStoredInfo.longitude
                                                : longitude,
                                          );
                                        },
                                      );
                                    }
                                  });
                                }
                              });
                            },
                            child: Padding(
                              padding: const EdgeInsets.all(8.0),
                              child: Container(
                                decoration: BoxDecoration(
                                  borderRadius: BorderRadius.circular(10),
                                  color: Colors.white,
                                  boxShadow: [
                                    BoxShadow(
                                      color: Colors.grey.withOpacity(0.3),
                                      spreadRadius: 0.7,
                                      blurRadius: 2,
                                      offset: Offset(
                                          0, 0), // changes position of shadow
                                    ),
                                  ],
                                ),
                                child: Stack(
                                  children: [
                                    Center(
                                      child: Column(
                                        mainAxisAlignment:
                                            MainAxisAlignment.center,
                                        children: [
                                          // Product image
                                          _sellerDetails["product_image"] ==
                                                  null
                                              ? Icon(
                                                  Icons.person,
                                                  size: 50,
                                                  color: Colors.grey,
                                                )
                                              : CachedNetworkImage(
                                                  fit: BoxFit.cover,
                                                  height: 100,
                                                  imageUrl:
                                                      "${Domain.url}${_sellerDetails["product_image"]}",
                                                  placeholder: (context, url) =>
                                                      Icon(
                                                    Icons.image,
                                                    size: 50,
                                                    color: Colors.grey,
                                                  ),
                                                  errorWidget:
                                                      (context, url, error) =>
                                                          new Icon(Icons.error),
                                                ),
                                          SizedBox(height: size.height * 0.01),
                                          //Product Name
                                          Text(
                                            _sellerDetails["product_name"],
                                            style: TextStyle(
                                              fontSize: size.width * 0.050,
                                              fontWeight: FontWeight.w600,
                                            ),
                                          ),
                                          SizedBox(height: size.height * 0.008),
                                          //Product Price
                                          Text(
                                            _sellerDetails["price"],
                                            style: TextStyle(
                                                fontSize: size.width * 0.040),
                                          ),
                                          SizedBox(height: size.height * 0.01),
                                          Row(
                                            mainAxisAlignment:
                                                MainAxisAlignment.center,
                                            children: [
                                              SizedBox(width: 10),
                                              Icon(
                                                Icons.location_on,
                                                size: size.height * 0.02,
                                              ),
                                              Flexible(
                                                child: Container(
                                                  child: Padding(
                                                    padding:
                                                        const EdgeInsets.only(
                                                            right: 10),
                                                    child: Text(
                                                      (areaname.isEmpty &&
                                                              cityname
                                                                  .isEmpty &&
                                                              statename.isEmpty)
                                                          ? countryname
                                                          : (areaname.isEmpty &&
                                                                  cityname
                                                                      .isEmpty)
                                                              ? "$statename, $countryname"
                                                              : (areaname
                                                                      .isEmpty)
                                                                  ? "$cityname, $statename"
                                                                  : "$areaname, $cityname",
                                                      maxLines: 1,
                                                      overflow:
                                                          TextOverflow.ellipsis,
                                                      softWrap: false,
                                                      style: TextStyle(
                                                        fontSize:
                                                            size.width * 0.033,
                                                      ),
                                                    ),
                                                  ),
                                                ),
                                              ),
                                            ],
                                          ),
                                        ],
                                      ),
                                    ),
                                    // Wishlist
                                    Align(
                                      alignment: Alignment.topRight,
                                      child: IconButton(
                                        onPressed: () {
                                          Provider.of<BoolLoader>(context,
                                                  listen: false)
                                              .boolLoader(status: false);
                                          if (authToken == null) {
                                            loginModalSheet.bottomModalSheet(
                                                context: context);
                                          } else {
                                            setState(() {
                                              sellerdetails["products"][index]
                                                      ["wishlist"] =
                                                  !sellerdetails["products"]
                                                      [index]["wishlist"];
                                            });
                                            if (sellerdetails["products"][index]
                                                    ["wishlist"] ==
                                                true) {
                                              Provider.of<Wishlist>(context,
                                                      listen: false)
                                                  .addWishslist(
                                                productid:
                                                    sellerdetails["products"]
                                                        [index]["_id"],
                                                authtoken: authToken!,
                                              );
                                            } else {
                                              Provider.of<Wishlist>(context,
                                                      listen: false)
                                                  .removeWishslist(
                                                productid:
                                                    sellerdetails["products"]
                                                        [index]["_id"],
                                                authtoken: authToken!,
                                              );
                                            }
                                          }
                                        },
                                        icon: sellerdetails["products"][index]
                                                    ["wishlist"] ==
                                                false
                                            ? Container(
                                                width: 25,
                                                height: 25,
                                                decoration: BoxDecoration(
                                                  borderRadius:
                                                      BorderRadius.circular(50),
                                                  color: colorBlue
                                                      .withOpacity(0.7),
                                                ),
                                                child: Icon(
                                                  Icons.favorite,
                                                  color: Colors.white,
                                                  size: 17,
                                                ),
                                              )
                                            : Icon(
                                                Icons.favorite,
                                                color: colorBlue,
                                                size: 17,
                                              ),
                                      ),
                                    ),
                                    // Featured
                                    _featured
                                        ? Container(
                                            width: size.width * 0.20,
                                            height: size.height * 0.030,
                                            decoration: BoxDecoration(
                                              borderRadius: BorderRadius.only(
                                                bottomRight:
                                                    Radius.circular(10),
                                              ),
                                              color: colorBlue,
                                            ),
                                            child: Center(
                                              child: Text(
                                                "Featured",
                                                style: TextStyle(
                                                  fontSize: size.width * 0.035,
                                                  fontWeight: FontWeight.w500,
                                                  color: Colors.white,
                                                ),
                                              ),
                                            ),
                                          )
                                        : Container(),
                                  ],
                                ),
                              ),
                            ),
                          );
                        },
                      ),
                    ],
                  ),
                ),
              ),
            ),
    );
  }

  filterbasedonLocation({
    required String username,
    required String latitude,
    required String longitude,
  }) {
    Provider.of<GetHome>(this.context, listen: false)
        .getProducts(
      authtoken: authToken ?? '',
      lat: latitude == "0.0" ? GetStoredInfo.latitude : latitude,
      long: longitude == "0.0" ? GetStoredInfo.longitude : longitude,
      refresh: true,
    )
        .then((value) {
      setState(() {
        _loading = false;
      });
      if (value['status'] == 200) {
        ShowToast.showToast(context, exception: "Successfully blocked");
        Provider.of<UserData>(context, listen: false).following(
          authtoken: authToken ?? '',
          userprofilename: username,
        );
        Navigator.of(context).push(
          MaterialPageRoute(
            builder: (_) => CustomBottomNavBar(chooseIndex: 0),
          ),
        );
      }
    });
  }

  Column followContainer({
    required String number,
    required String text,
  }) {
    return Column(
      children: [
        Container(
          width: 50,
          height: 30,
          // color: colorBlue,
          child: Center(
            child: Text(
              number,
              style: TextStyle(
                fontSize: 18,
                fontWeight: FontWeight.w500,
              ),
            ),
          ),
        ),
        Text(
          text,
          style: TextStyle(
            fontSize: 15,
            fontWeight: FontWeight.w500,
          ),
        ),
      ],
    );
  }

  Widget followerChat({
    required String text,
    required Size size,
    required VoidCallback ontap,
  }) {
    return InkWell(
      onTap: ontap,
      child: Container(
        width: size.width / 3,
        height: size.height / 17,
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(5),
          color: colorBlue,
        ),
        child: Center(
          child: Text(
            text,
            style: TextStyle(
              fontSize: size.height / 35,
              fontWeight: FontWeight.w500,
            ),
          ),
        ),
      ),
    );
  }
}
