import 'dart:async';
import 'dart:io' show Platform;
import 'package:cached_network_image/cached_network_image.dart';
import 'package:carousel_slider/carousel_slider.dart';
import 'package:flutter/material.dart';
import 'package:flutter_svg/svg.dart';
import 'package:india/Common/color.dart';
import 'package:india/Common/loading_bool.dart';
import 'package:india/Common/loading_widget.dart';
import 'package:india/Common/show_toast.dart';
import 'package:india/Services/chat_firestore.dart';
import 'package:india/Services/domain.dart';
import 'package:india/Services/get_products.dart';
import 'package:india/Services/reportad.dart';
import 'package:india/Services/seller_details.dart';
import 'package:india/Services/user_data.dart';
import 'package:india/Services/wishlist.dart';
import 'package:india/Widgets/Authentication/Signin/login_bottommodal.dart';
import 'package:india/Widgets/Screens/conversation_screen.dart';
import 'package:india/Widgets/Screens/seller_profile.dart';
import 'package:provider/provider.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:smooth_page_indicator/smooth_page_indicator.dart';
import "string_extension.dart";

class SpecificProduct extends StatefulWidget {
  @override
  _SpecificProductState createState() => _SpecificProductState();
}

class _SpecificProductState extends State<SpecificProduct> {
  int activeIndex = 0;
  String userId = '';
  String sellerId = '';
  String sellername = '';
  String sellerpicture = '';
  String sellerusername = '';
  bool _loading = false;
  bool _addloading = false;
  String? authToken;
  late String countryname;
  late String statename;
  late String cityname;
  late String areaname;
  late String adId;
  List productImageLength = [];
  var _timestamp;
  LoginModalSheet loginModalSheet = LoginModalSheet();

  Future<String> getAuthToken() async {
    SharedPreferences sharedPreferences = await SharedPreferences.getInstance();
    authToken = sharedPreferences.getString("authtoken");
    // print('Auth token: $authToken');
    return authToken ?? '';
  }

  @override
  void initState() {
    getAuthToken();
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    Size size = MediaQuery.of(context).size;
    userId = Provider.of<UserData>(context).userId;
    Map<String, dynamic> productinfo =
        Provider.of<ProductInformation>(context).productinfo;
    if (productinfo.isNotEmpty) {
      Map<String, dynamic> userinfo = productinfo["user_info"];
      productImageLength = productinfo["product_image"];
      sellerId = userinfo["_id"];
      sellername = userinfo["name"];
      sellerpicture = userinfo["avatar"] ?? '';
      sellerusername = userinfo["user_name"];
      _timestamp = productinfo["timestamp"];
      Map<String, dynamic> _geolocation = productinfo["product_location"];
      countryname = _geolocation["country"];
      statename = _geolocation["state"];
      cityname = _geolocation["city"];
      areaname = _geolocation["area"];
      adId = "${productinfo["product_UUID"]}";
    }
    DateTime datetime = new DateTime.fromMillisecondsSinceEpoch(_timestamp);
    int year = datetime.year;
    int month = datetime.month;
    int day = datetime.day;
    String dateposted = "$day-$month-$year";
    List chatroomUserid = Provider.of<ChatFirestore>(context).chatListUserId;
    Map<String, String> mapchatroomid =
        Provider.of<ChatFirestore>(context).mapchatroomId;
    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
        centerTitle: true,
        elevation: 2,
        backgroundColor: Color(0xFFF9F9F9),
        title: Text("${productinfo["product_name"]}".capitalize()),
        leading: IconButton(
          onPressed: () {
            Navigator.of(context).pop("specificProduct");
          },
          icon: Icon(
            Platform.isAndroid ? Icons.arrow_back : Icons.arrow_back_ios,
          ),
        ),
        actions: [
          // ! Share product to whatsapp with dynamic link
          // IconButton(
          //   onPressed: () {},
          //   icon: Icon(Icons.share),
          // ),
        ],
      ),
      body: _addloading
          ? ThankyouLoader()
          : _loading
              ? LoadingWidget()
              : SingleChildScrollView(
                  child: Container(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Center(
                          child: Container(
                            width: size.width * 0.9,
                            height: size.height * 0.4,
                            child: Column(
                              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                              children: [
                                CarouselSlider.builder(
                                  options: CarouselOptions(
                                    autoPlay: true,
                                    enableInfiniteScroll: false,
                                    // height: size.height / 2,
                                    onPageChanged: (index, reason) {
                                      setState(() {
                                        activeIndex = index;
                                      });
                                    },
                                  ),
                                  itemCount: productImageLength.length,
                                  itemBuilder: (context, index, realIndex) {
                                    return CachedNetworkImage(
                                      imageUrl:
                                          "${Domain.url}${productinfo["product_image"][index]}",
                                      placeholder: (context, url) => Icon(
                                        Icons.image,
                                        size: 50,
                                        color: Colors.grey,
                                      ),
                                      errorWidget: (context, url, error) =>
                                          new Icon(Icons.error),
                                    );
                                  },
                                ),
                                dotIndicator(productinfo: productinfo),
                              ],
                            ),
                          ),
                        ),
                        Padding(
                          padding: const EdgeInsets.symmetric(horizontal: 20),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Divider(),
                              Row(
                                mainAxisAlignment:
                                    MainAxisAlignment.spaceBetween,
                                children: [
                                  Text(
                                    "Details:",
                                    style: TextStyle(
                                      fontSize: size.height * 0.02,
                                      fontWeight: FontWeight.w500,
                                    ),
                                  ),
                                  // Wishlist
                                  IconButton(
                                    onPressed: () {
                                      // Provider.of<BoolLoader>(context,listen: false).boolLoader(status: false);
                                      if (authToken == null) {
                                        loginModalSheet.bottomModalSheet(
                                            context: context);
                                      } else if (userId.isNotEmpty) {
                                        setState(() {
                                          productinfo["wishlist"] =
                                              !productinfo["wishlist"];
                                          // _loading = true;
                                        });
                                        if (productinfo["wishlist"] == true) {
                                          Provider.of<Wishlist>(context,
                                                  listen: false)
                                              .addWishslist(
                                            productid: productinfo["_id"],
                                            authtoken: authToken!,
                                          )
                                              .then((value) {
                                            if (value == "Added to wishlist") {
                                              setState(() {
                                                // _loading = false;
                                              });
                                            }
                                          });
                                        } else {
                                          Provider.of<Wishlist>(context,
                                                  listen: false)
                                              .removeWishslist(
                                            productid: productinfo["_id"],
                                            authtoken: authToken!,
                                          )
                                              .then((value) {
                                            setState(() {
                                              _loading = false;
                                            });
                                          });
                                        }
                                        // Provider.of<GetHome>(context,
                                        //         listen: false)
                                        //     .getProducts(
                                        //   authtoken: authtoken,
                                        //   refresh: true,
                                        //   lat: GetStoredInfo.latitude,
                                        //   long: GetStoredInfo.longitude,
                                        // );
                                      } else {
                                        Provider.of<BoolLoader>(context,
                                                listen: false)
                                            .boolLoader(status: false);
                                        loginModalSheet.bottomModalSheet(
                                            context: context);
                                      }
                                    },
                                    icon: (userId.isNotEmpty &&
                                            productinfo["wishlist"] == true)
                                        ? Icon(
                                            Icons.favorite,
                                            size: 25,
                                            color: colorBlue,
                                          )
                                        : (userId.isNotEmpty &&
                                                productinfo["wishlist"] ==
                                                    false)
                                            ? Icon(
                                                Icons.favorite_border,
                                                size: 25,
                                              )
                                            : Icon(
                                                Icons.favorite_border,
                                                color: colorBlue,
                                                size: 25,
                                              ),
                                  ),
                                ],
                              ),
                              SizedBox(height: 10),
                              Container(
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Row(
                                      mainAxisAlignment:
                                          MainAxisAlignment.spaceBetween,
                                      children: [
                                        // Product name
                                        Text(
                                          "${productinfo["product_name"]}"
                                              .capitalize(),
                                          style: TextStyle(
                                            fontSize: size.height * 0.025,
                                            fontWeight: FontWeight.w500,
                                          ),
                                        ),
                                        // Posted on
                                        Padding(
                                          padding:
                                              const EdgeInsets.only(right: 5),
                                          child: Text(
                                            "Posted on: $dateposted",
                                            style: TextStyle(fontSize: 16),
                                          ),
                                        ),
                                      ],
                                    ),
                                    SizedBox(height: 15),
                                    Row(
                                      mainAxisAlignment:
                                          MainAxisAlignment.spaceBetween,
                                      children: [
                                        // Product Price
                                        Text(
                                          productinfo["price"],
                                          style: TextStyle(
                                              fontSize: size.height * 0.02),
                                        ),
                                        // Posted on
                                        Padding(
                                          padding:
                                              const EdgeInsets.only(right: 5),
                                          child: Text(
                                            "AD ID: $adId",
                                            style: TextStyle(
                                              fontSize: 16,
                                              fontWeight: FontWeight.w800,
                                            ),
                                          ),
                                        ),
                                      ],
                                    ),
                                    SizedBox(height: 15),
                                    // Product Location
                                    Row(
                                      mainAxisAlignment:
                                          MainAxisAlignment.start,
                                      children: [
                                        Icon(
                                          Icons.location_on,
                                          size: size.height * 0.02,
                                          color: Colors.grey[800],
                                        ),
                                        Text(
                                          (areaname.isEmpty &&
                                                  cityname.isEmpty &&
                                                  statename.isEmpty)
                                              ? countryname
                                              : (areaname.isEmpty &&
                                                      cityname.isEmpty)
                                                  ? "$statename, $countryname"
                                                  : (areaname.isEmpty)
                                                      ? "$cityname, $statename"
                                                      : "$areaname, $cityname",
                                          style: TextStyle(
                                              fontSize: size.height * 0.02),
                                        ),
                                      ],
                                    ),
                                  ],
                                ),
                              ),
                              SizedBox(height: 20),
                              // Divider(),
                              // Chat
                              Center(
                                child: GestureDetector(
                                  onTap: () {
                                    Provider.of<BoolLoader>(context,
                                            listen: false)
                                        .boolLoader(status: false);
                                    if (authToken == null) {
                                      loginModalSheet.bottomModalSheet(
                                          context: context);
                                    } else if (userId.isNotEmpty) {
                                      if (userId != sellerId) {
                                        setState(() {
                                          _loading = true;
                                        });
                                        Provider.of<ChatFirestore>(context,
                                                listen: false)
                                            .getUserProfile(userId: sellerId)
                                            .then((value) {
                                          if (value == 200) {
                                            // Provider.of<ChatFirestore>(context,
                                            //         listen: false)
                                            //     .checkChatroomId(
                                            //   myid: userId,
                                            //   secondId: sellerId,
                                            // );
                                            Timer(Duration(milliseconds: 500),
                                                () {
                                              setState(() {
                                                _loading = false;
                                              });
                                              Provider.of<SellerDetails>(
                                                      context,
                                                      listen: false)
                                                  .getsellerDetails(
                                                      username: sellerusername,
                                                      authtoken: authToken)
                                                  .then((value) {
                                                Navigator.push(
                                                  context,
                                                  MaterialPageRoute(
                                                    builder: (_) =>
                                                        ConversationScreen(
                                                      personName: sellername,
                                                      personAvatar:
                                                          sellerpicture,
                                                      productId:
                                                          productinfo["_id"],
                                                      username: sellerusername,
                                                      sellerid: sellerId,
                                                      // chatpersonUserid: sellerId,
                                                      // chatlistuserId: ,
                                                      myid: userId,
                                                      mapchatroomlist: sellerId,
                                                      // userId2: sellerId,
                                                      chatroomUserid:
                                                          chatroomUserid,
                                                      mapchatroomid:
                                                          mapchatroomid,
                                                    ),
                                                  ),
                                                );
                                                if (value["status"] == 200) {}
                                              });
                                            });
                                          } else {
                                            setState(() {
                                              _loading = false;
                                            });
                                          }
                                        });
                                      } else {
                                        setState(() {
                                          _loading = false;
                                        });
                                        ShowToast.showToast(
                                          context,
                                          exception:
                                              'You cannot chat with yourself',
                                        );
                                      }
                                    } else {
                                      Provider.of<BoolLoader>(context,
                                              listen: false)
                                          .boolLoader(status: false);
                                      loginModalSheet.bottomModalSheet(
                                          context: context);
                                    }
                                  },
                                  child: Container(
                                    width: 200,
                                    height: 50,
                                    decoration: BoxDecoration(
                                      borderRadius: BorderRadius.circular(8),
                                      color: colorBlue,
                                    ),
                                    child: Center(
                                      child: Row(
                                        mainAxisAlignment:
                                            MainAxisAlignment.center,
                                        children: [
                                          Icon(
                                            Icons.chat,
                                            color: Colors.indigo[900],
                                          ),
                                          SizedBox(width: 10),
                                          Text(
                                            'Chat',
                                            textHeightBehavior:
                                                TextHeightBehavior(
                                              applyHeightToLastDescent: true,
                                            ),
                                            textAlign: TextAlign.center,
                                            style: TextStyle(
                                              fontSize: 25,
                                              fontWeight: FontWeight.w500,
                                              color: Colors.indigo[900],
                                            ),
                                          ),
                                        ],
                                      ),
                                    ),
                                  ),
                                ),
                              ),
                              SizedBox(height: 15),
                              Divider(),
                              SizedBox(height: 10),
                              Text(
                                "Description:",
                                style: TextStyle(
                                  fontSize: size.height * 0.02,
                                  fontWeight: FontWeight.w500,
                                ),
                              ),
                              SizedBox(height: 10),
                              Wrap(
                                children: [
                                  Text(
                                    productinfo["product_description"],
                                    style: TextStyle(
                                      fontSize: size.height * 0.02,
                                    ),
                                  ),
                                ],
                              ),
                              SizedBox(height: 10),
                              Divider(),
                              SizedBox(height: 15),
                              Row(
                                mainAxisAlignment:
                                    MainAxisAlignment.spaceBetween,
                                children: [
                                  SizedBox(width: 10),
                                  productinfo["user_info"]["avatar"] == null
                                      ? CircleAvatar(
                                          maxRadius: 40,
                                        )
                                      : CircleAvatar(
                                          maxRadius: 40,
                                          backgroundColor: Colors.grey[200],
                                          child: CachedNetworkImage(
                                            fit: BoxFit.cover,
                                            imageUrl:
                                                "${Domain.url}${productinfo["user_info"]["avatar"]}",
                                            placeholder: (context, url) => Icon(
                                              Icons.person,
                                              size: 50,
                                              color: Colors.grey,
                                            ),
                                            errorWidget:
                                                (context, url, error) =>
                                                    new Icon(Icons.error),
                                          ),
                                        ),
                                  Column(
                                    children: [
                                      Text(
                                        "${productinfo["user_info"]["name"]}"
                                            .capitalize(),
                                        maxLines: 1,
                                        overflow: TextOverflow.ellipsis,
                                        softWrap: false,
                                        style: TextStyle(
                                          fontSize: size.height * 0.02,
                                          fontWeight: FontWeight.bold,
                                        ),
                                      ),
                                      SizedBox(height: 10),
                                      InkWell(
                                        onTap: () {
                                          setState(() {
                                            _loading = true;
                                          });
                                          Provider.of<SellerDetails>(context,
                                                  listen: false)
                                              .getsellerDetails(
                                            authtoken: authToken,
                                            username: productinfo["user_info"]
                                                ["user_name"],
                                          )
                                              .then((value) {
                                            if (value["status"] == 200) {
                                              Navigator.push(
                                                context,
                                                MaterialPageRoute(
                                                  builder: (_) => SellerProfile(
                                                    userId: userId,
                                                    sellerId: sellerId,
                                                  ),
                                                ),
                                              ).then((value) {
                                                if (value == "SellerProfile") {
                                                  WidgetsBinding.instance
                                                      ?.addPostFrameCallback(
                                                    (duration) {
                                                      Provider.of<ProductInformation>(
                                                              this.context,
                                                              listen: false)
                                                          .getproductInformation(
                                                        authtoken: authToken,
                                                        productid:
                                                            productinfo["_id"],
                                                      );
                                                    },
                                                  );
                                                }
                                              });
                                              setState(() {
                                                _loading = false;
                                              });
                                            } else {
                                              setState(() {
                                                _loading = false;
                                              });
                                              ShowToast.showToast(context,
                                                  exception:
                                                      "Kindly try again later");
                                            }
                                          });
                                        },
                                        child: Container(
                                          height: size.height * 0.05,
                                          width: size.width * 0.3,
                                          decoration: BoxDecoration(
                                            color: colorBlue,
                                            borderRadius:
                                                BorderRadius.circular(5),
                                          ),
                                          child: Center(
                                            child: Text(
                                              "View Profile",
                                              style: TextStyle(
                                                  fontSize: size.height * 0.02,
                                                  fontWeight: FontWeight.w500),
                                            ),
                                          ),
                                        ),
                                      ),
                                    ],
                                  ),
                                  SizedBox(width: 10),
                                ],
                              ),
                            ],
                          ),
                        ),
                        SizedBox(height: 30),
                      ],
                    ),
                  ),
                ),
    );
  }

  Future<dynamic> bottomModalSheet({
    required Map<String, dynamic> productinfo,
  }) {
    return showModalBottomSheet(
      isScrollControlled: true,
      backgroundColor: Colors.white,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(
          top: Radius.circular(20),
        ),
      ),
      context: this.context,
      builder: (context) {
        return StatefulBuilder(
          builder: (buildercontext, builderState) {
            return Padding(
              padding: MediaQuery.of(context).viewInsets,
              child: SingleChildScrollView(
                child: Container(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      SizedBox(height: 10),
                      Center(
                        child: Text(
                          'Why you want to report?',
                          style: TextStyle(
                            color: Colors.black,
                            fontSize: 20,
                            fontWeight: FontWeight.w500,
                          ),
                        ),
                      ),
                      SizedBox(height: 5),
                      Padding(
                        padding: const EdgeInsets.symmetric(horizontal: 10),
                        child: Divider(),
                      ),
                      SizedBox(height: 5),
                      InkWell(
                        onTap: () {
                          if (userId != sellerId) {
                            Navigator.pop(this.context);
                            setState(() {
                              _addloading = true;
                            });
                            // Loader.show(
                            //   context,
                            //   progressIndicator: Column(
                            //     children: [
                            //       SvgPicture.asset(
                            //         "assets/placeholders/thankyou.svg",
                            //         height: 200,
                            //       ),
                            //       Text(
                            //         "Thank you for letting us know",
                            //         style: TextStyle(fontSize: 20),
                            //       ),
                            //     ],
                            //   ),
                            // );
                            ReportAd.reportad(
                              productid: productinfo["_id"],
                              report: "It's a spam",
                              authtoken: authToken ?? '',
                            ).then((value) {
                              if (value["status"] == 200 &&
                                  value["response"]["data"]["info"]
                                          ["reported"] ==
                                      true) {
                                // filterbasedonLocation();
                                setState(() {
                                  _addloading = false;
                                });
                              } else {
                                setState(() {
                                  _addloading = false;
                                });
                              }
                            });
                          } else {
                            Navigator.pop(this.context);
                            ShowToast.showToast(
                              this.context,
                              exception: "You cannot report your own post",
                            );
                          }
                        },
                        child: Padding(
                          padding: const EdgeInsets.all(10.0),
                          child: Container(
                            width: double.infinity,
                            child: Text(
                              "It's a spam",
                              style: TextStyle(
                                fontSize: 18,
                                fontWeight: FontWeight.w400,
                              ),
                            ),
                          ),
                        ),
                      ),
                      SizedBox(height: 15),
                      InkWell(
                        onTap: () {
                          if (userId != sellerId) {
                            ReportAd.reportad(
                              productid: productinfo["_id"],
                              report: "I feel it's offensive",
                              authtoken: authToken ?? '',
                            ).then((value) {});
                          } else {
                            Navigator.pop(context);
                            ShowToast.showToast(
                              context,
                              exception: "You cannot report your own post",
                            );
                          }
                        },
                        child: Padding(
                          padding: const EdgeInsets.all(10.0),
                          child: Container(
                            width: double.infinity,
                            child: Text(
                              "I feel it's offensive",
                              style: TextStyle(
                                fontSize: 18,
                                fontWeight: FontWeight.w400,
                              ),
                            ),
                          ),
                        ),
                      ),
                      SizedBox(height: 15),
                      InkWell(
                        onTap: () {
                          if (userId != sellerId) {
                            ReportAd.reportad(
                              productid: productinfo["_id"],
                              report: "It's misleading",
                              authtoken: authToken ?? '',
                            ).then((value) {});
                          } else {
                            Navigator.pop(context);
                            ShowToast.showToast(
                              context,
                              exception: "You cannot report your own post",
                            );
                          }
                        },
                        child: Padding(
                          padding: const EdgeInsets.all(10.0),
                          child: Container(
                            width: double.infinity,
                            child: Text(
                              "It's misleading",
                              style: TextStyle(
                                fontSize: 18,
                                fontWeight: FontWeight.w400,
                              ),
                            ),
                          ),
                        ),
                      ),
                      SizedBox(height: 15),
                      InkWell(
                        onTap: () {
                          if (userId != sellerId) {
                            ReportAd.reportad(
                              productid: productinfo["_id"],
                              report: "It's sexually inappropriate",
                              authtoken: authToken ?? '',
                            ).then((value) {});
                          } else {
                            Navigator.pop(context);
                            ShowToast.showToast(
                              context,
                              exception: "You cannot report your own post",
                            );
                          }
                        },
                        child: Padding(
                          padding: const EdgeInsets.all(10.0),
                          child: Container(
                            width: double.infinity,
                            child: Text(
                              "It's sexually inappropriate",
                              style: TextStyle(
                                fontSize: 18,
                                fontWeight: FontWeight.w400,
                              ),
                            ),
                          ),
                        ),
                      ),
                      SizedBox(height: 15),
                    ],
                  ),
                ),
              ),
            );
          },
        );
      },
    );
  }

  // filterbasedonLocation() {
  //   if (areaId == '') {
  //     Map<String, String> locationmap = {
  //       "country": countryId ?? '',
  //       "state": stateId ?? '',
  //       "city": cityId ?? '',
  //     };
  //     Provider.of<GetHome>(this.context, listen: false)
  //         .getProducts(
  //       authtoken: authToken ?? '',
  //       locationmap: locationmap,
  //       refresh: true,
  //     )
  //         .then((value) {
  //       if (value["status"] == 200) {
  //         Navigator.pushAndRemoveUntil(
  //           this.context,
  //           MaterialPageRoute(
  //             builder: (context) => HomeScreen(),
  //           ),
  //           (route) => false,
  //         );
  //       }
  //     });
  //   } else {
  //     Map<String, String> locationmap = {
  //       "country": countryId ?? '',
  //       "state": stateId ?? '',
  //       "city": cityId ?? '',
  //       "area": areaId ?? '',
  //     };
  //     Provider.of<GetHome>(this.context, listen: false)
  //         .getProducts(
  //       authtoken: authToken ?? '',
  //       locationmap: locationmap,
  //       refresh: true,
  //     )
  //         .then((value) {
  //       if (value["status"] == 200) {
  //         Navigator.pushAndRemoveUntil(
  //           this.context,
  //           MaterialPageRoute(
  //             builder: (context) => HomeScreen(),
  //           ),
  //           (route) => false,
  //         );
  //       }
  //     });
  //   }
  // }

  dotIndicator({required Map<String, dynamic> productinfo}) {
    return AnimatedSmoothIndicator(
      activeIndex: activeIndex,
      count: productinfo["product_image"].length,
      effect: SlideEffect(
        dotWidth: 11,
        dotHeight: 11,
        activeDotColor: Color(0xFF30BFFD),
      ),
    );
  }
}

class ThankyouLoader extends StatelessWidget {
  const ThankyouLoader({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Container(
      color: Colors.white.withOpacity(0.1),
      width: double.infinity,
      height: double.infinity,
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          SvgPicture.asset(
            "assets/placeholders/thankyou.svg",
            height: 200,
          ),
          Text(
            "Thank you for letting us know",
            style: TextStyle(fontSize: 20),
          ),
        ],
      ),
    );

    // Scaffold(

    //   body: Center(
    //     child:
    //   ),
    // );
  }
}

// Row(
//   children: [
//     Column(
//       children: [
//         Container(
//           width: 50,
//           height: 30,
//           // color: colorBlue,
//           child: Center(
//             child: Text(
//               productinfo["user_info"]
//                   ["followers"],
//               style:
//                   TextStyle(fontSize: 20),
//             ),
//           ),
//         ),
//         SizedBox(height: 5),
//         Text(
//           "Followers",
//           style: TextStyle(
//             fontSize: 12,
//             fontWeight: FontWeight.w700,
//           ),
//         ),
//       ],
//     ),
//     SizedBox(width: 30),
//     Column(
//       children: [
//         Container(
//           width: 50,
//           height: 30,
//           // color: colorBlue,
//           child: Center(
//             child: Text(
//               "${productinfo["total_products"]}",
//               style:
//                   TextStyle(fontSize: 20),
//             ),
//           ),
//         ),
//         SizedBox(height: 5),
//         Text(
//           "Posts",
//           style: TextStyle(
//             fontSize: 12,
//             fontWeight: FontWeight.w700,
//           ),
//         ),
//       ],
//     ),
//   ],
// ),
// SizedBox(height: 10),
