import 'package:flutter/material.dart';
import 'package:india/Common/loading_bool.dart';
import 'package:india/Common/loading_widget.dart';
import 'package:india/Services/filter.dart';
import 'package:india/Widgets/Screens/products.dart';
import 'package:provider/provider.dart';
import "string_extension.dart";

// ignore: must_be_immutable
class SubCatProducts extends StatefulWidget {
  List subcategoryList;
  String authtoken;
  String countryname;
  String statename;
  String cityname;
  String areaname;
  SubCatProducts({
    required this.subcategoryList,
    required this.authtoken,
    required this.countryname,
    required this.statename,
    required this.cityname,
    required this.areaname,
  });

  @override
  State<SubCatProducts> createState() => _SubCatProductsState();
}

class _SubCatProductsState extends State<SubCatProducts> {
  String filteroptions = '';

  String sortoptions = '';

  late Map<String, String> body;

  @override
  Widget build(BuildContext context) {
    bool _loading = Provider.of<BoolLoader>(context).loadingStatus;
    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
        centerTitle: true,
        elevation: 2,
        title: Text("Sub category"),
        backgroundColor: Colors.white,
      ),
      body: _loading
          ? LoadingWidget()
          : Container(
              padding: EdgeInsets.only(top: 10),
              child: ListView.builder(
                itemCount: widget.subcategoryList.length,
                itemBuilder: (listviewcontext, index) {
                  return Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 10),
                    child: InkWell(
                      onTap: () {
                        Provider.of<BoolLoader>(context, listen: false)
                            .boolLoader(status: true);
                        Provider.of<FilterProducts>(context, listen: false)
                            .filterbyCategories(
                          refresh: true,
                          authtoken: widget.authtoken,
                          categoryId: widget.subcategoryList[index]["_id"],
                          country: widget.countryname,
                          state: widget.statename,
                          city: widget.cityname,
                          area: widget.areaname,
                          filters: "{}",
                          sort: "{}",
                        )
                            .then(
                          (value) {
                            if (value["status"] == 200) {
                              Provider.of<BoolLoader>(this.context,
                                      listen: false)
                                  .boolLoader(status: false);
                              Navigator.push(
                                this.context,
                                MaterialPageRoute(
                                  builder: (_) => Products(
                                    categoryId: widget.subcategoryList[index]
                                        ["_id"],
                                    title:
                                        "${widget.subcategoryList[index]["name"]}"
                                            .capitalize(),
                                    countryname: widget.countryname,
                                    statename: widget.statename,
                                    cityname: widget.cityname,
                                    areaname: widget.areaname,
                                  ),
                                ),
                              );
                            } else {
                              Provider.of<BoolLoader>(this.context,
                                      listen: false)
                                  .boolLoader(status: false);
                            }
                          },
                        );
                      },
                      child: Padding(
                        padding: const EdgeInsets.symmetric(vertical: 5),
                        child: Container(
                          decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(5),
                            color: Colors.white,
                            boxShadow: [
                              BoxShadow(
                                color: Colors.grey.withOpacity(0.3),
                                spreadRadius: 0.7,
                                blurRadius: 2,
                                offset:
                                    Offset(0, 0), // changes position of shadow
                              ),
                            ],
                          ),
                          child: ListTile(
                            title: Text(
                              widget.subcategoryList[index]["name"]
                                  .toString()
                                  .capitalize(),
                              style: TextStyle(fontSize: 20),
                            ),
                          ),
                        ),
                      ),
                    ),
                  );
                },
              ),
            ),
    );
  }
}
