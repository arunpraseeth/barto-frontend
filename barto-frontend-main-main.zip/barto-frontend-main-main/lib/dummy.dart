// import 'package:flutter/material.dart';
// import 'package:india/Services/search_places.dart';
// import 'package:mapbox_search/mapbox_search.dart';
// import 'package:provider/provider.dart';

// // ignore: must_be_immutable
// class Dummy extends StatelessWidget {
//   TextEditingController searchcontroller = TextEditingController();
//   @override
//   Widget build(BuildContext context) {
//     return Scaffold(
//       body: SafeArea(
//         child: Column(
//           children: [
//             Padding(
//               padding: const EdgeInsets.symmetric(horizontal: 15),
//               child: Container(
//                 decoration: BoxDecoration(
//                   borderRadius: BorderRadius.circular(5),
//                   color: Colors.white,
//                   boxShadow: [
//                     BoxShadow(
//                       color: Colors.grey.withOpacity(0.3),
//                       spreadRadius: 0.7,
//                       blurRadius: 2,
//                       offset: Offset(0, 0), // changes position of shadow
//                     ),
//                   ],
//                 ),
//                 child: ListTile(
//                   title: TextFormField(
//                     style: TextStyle(fontSize: 20),
//                     controller: searchcontroller,
//                     decoration: InputDecoration(
//                       hintText: "Search...",
//                       border: InputBorder.none,
//                     ),
//                     onChanged: (String value) {
//                       if (value.isNotEmpty) {
//                         Provider.of<SearchPlaces>(context, listen: false)
//                             .searchPlaces(placeName: value);
//                       } else {
//                         Provider.of<SearchPlaces>(context, listen: false)
//                             .clearPlaceName();
//                       }
//                     },
//                   ),
//                   trailing: Transform.translate(
//                     offset: Offset(10, 0),
//                     child: IconButton(
//                       onPressed: () {
//                         Provider.of<SearchPlaces>(context, listen: false)
//                             .clearPlaceName();
//                       },
//                       icon: Icon(Icons.clear, size: 25),
//                     ),
//                   ),
//                 ),
//               ),
//             ),
//             SizedBox(height: 5),
//             Provider.of<SearchPlaces>(context).placename.isNotEmpty
//                 ? Padding(
//                     padding: const EdgeInsets.symmetric(horizontal: 15),
//                     child: Container(
//                       decoration: BoxDecoration(
//                         borderRadius: BorderRadius.circular(5),
//                         color: Colors.white,
//                         boxShadow: [
//                           BoxShadow(
//                             color: Colors.grey.withOpacity(0.3),
//                             spreadRadius: 0.7,
//                             blurRadius: 2,
//                             offset:
//                                 Offset(0, 0), // changes position of shadow
//                           ),
//                         ],
//                       ),
//                       child: ListView.builder(
//                         shrinkWrap: true,
//                         itemCount: Provider.of<SearchPlaces>(context)
//                             .placename
//                             .length,
//                         itemBuilder: (context, index) {
//                           return Container(
//                             child: Padding(
//                               padding: const EdgeInsets.all(13.0),
//                               child: InkWell(
//                                 child: Text(
//                                   Provider.of<SearchPlaces>(context)
//                                       .placename[index],
//                                   style: TextStyle(fontSize: 20),
//                                 ),
//                                 onTap: () {
//                                   print(Provider.of<SearchPlaces>(context,
//                                           listen: false)
//                                       .placelatlong[index]);
//                                 },
//                               ),
//                             ),
//                           );
//                         },
//                       ),
//                     ),
//                   )
//                 : Container(),
//           ],
//         ),
//       ),
//     );
//   }
// }
