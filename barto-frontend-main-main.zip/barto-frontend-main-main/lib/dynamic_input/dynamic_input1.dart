// import 'package:flutter/foundation.dart';
// import 'package:flutter/material.dart';

// class DynamicInput extends StatelessWidget {
//   final String type;
//   final ValueChanged<dynamic> onChanged;
//   DynamicInput({required this.type, required this.onChanged});
//   @override
//   Widget build(BuildContext context) {
//     if (type == "number") {
//       TextBartoInput input = TextBartoInput(keyboardType: TextInputType.number);
//       input.controller.addListener(() {
//         onChanged(input.controller.text);
//       });
//       return input;
//     } else if (type == "text") {
//       TextBartoInput input = TextBartoInput(keyboardType: TextInputType.text);
//       input.controller.addListener(() {
//         onChanged(input.controller.text);
//       });
//       return input;
//     } else if (type == "radio") {
//       Radio input = Radio(value: 1, groupValue: 1, onChanged: onChanged);
//       return input;
//     } else if (type == "checkbox") {
//       Checkbox input = Checkbox(value: true, onChanged: onChanged);
//       return input;
//     } else {
//       return const SizedBox();
//     }
//   }
// }

// class TextBartoInput extends StatelessWidget {
//   final TextEditingController controller = TextEditingController();
//   final TextInputType keyboardType;
//   TextBartoInput({required this.keyboardType});
//   @override
//   build(BuildContext context) {
//     return TextFormField(
//       keyboardType: this.keyboardType,
//       style: TextStyle(fontSize: 20),
//       controller: controller,
//     );
//   }
// }

// class ServiceResult {
//   late ServiceResponse response;
//   int status = 0;
//   ServiceResult({required this.response});

//   ServiceResult.fromJson(Map<String, dynamic> json) {
//     response = ServiceResponse.fromJson(json['response']);
//     status = json['status'];
//   }

//   Map<String, dynamic> toJson() {
//     final Map<String, dynamic> json = <String, dynamic>{};
//     status = int.tryParse(json['status']) ?? 0;
//     json['response'] = response.toJson();
//     return json;
//   }
// }

// class ServiceResultData {
//   late ServiceFormResponse info;
//   ServiceResultData({required this.info});

//   ServiceResultData.fromJson(Map<String, dynamic> json) {
//     info = ServiceFormResponse.fromJson(json['info']);
//   }

//   Map<String, dynamic> toJson() {
//     final Map<String, dynamic> json = <String, dynamic>{};
//     json['info'] = info.toJson();
//     return json;
//   }
// }

// class ServiceFormResponse {
//   List<ServiceFormData> form = [];
//   ServiceFormResponse({required this.form});

//   ServiceFormResponse.fromJson(Map<String, dynamic> json) {
//     if (json['form'] is List) {
//       form = (json['form'] as List)
//           .map((i) => ServiceFormData.fromJson(i))
//           .toList();
//     }
//   }

//   Map<String, dynamic> toJson() {
//     final Map<String, dynamic> json = <String, dynamic>{};
//     json['form'] = form.map((e) => e.toJson()).toList();
//     return json;
//   }
// }

// class ServiceFormData {
//   late List<Map<String, dynamic>> fields;
//   ServiceFormData({required this.fields});

//   ServiceFormData.fromJson(Map<String, dynamic> json) {
//     print("JSON :=> ${json}");
//     fields =
//         (json['fields'] as List).map((e) => e as Map<String, dynamic>).toList();
//   }

//   Map<String, dynamic> toJson() {
//     final Map<String, dynamic> json = <String, dynamic>{};
//     json['fields'] = fields;
//     return json;
//   }
// }

// class ServiceResponse {
//   late String resource = "unknown";
//   String? message;
//   late ServiceResultData data;

//   ServiceResponse({
//     required this.resource,
//     this.message,
//     required this.data,
//   });

//   ServiceResponse.fromJson(Map<String, dynamic> json) {
//     resource = json['resource'].toString();
//     message = json['message'].toString();
//     print("json: $json");
//     data = ServiceResultData.fromJson(json['data']);
//   }

//   Map<String, dynamic> toJson() {
//     final Map<String, dynamic> json = <String, dynamic>{};
//     json['resource'] = resource;
//     json['message'] = message;
//     json['data'] = data;
//     return json;
//   }

//   @override
//   toString() => toJson().toString();
// }

// class DynamicInputData {
//   late bool filterable;
//   late bool mandatory;
//   late String sId;
//   late String name;
//   late String displayText;
//   late String type;
//   late String label;
//   late CodeGroup codeGroup;
//   late String dependent;

//   DynamicInputData({
//     required this.filterable,
//     required this.mandatory,
//     required this.sId,
//     required this.name,
//     required this.displayText,
//     required this.type,
//     required this.label,
//     required this.codeGroup,
//     required this.dependent,
//   });

//   DynamicInputData.fromJson(Map<String, dynamic> json) {
//     filterable = json['filterable'];
//     mandatory = json['mandatory'];
//     sId = json['_id'];
//     name = json['name'];
//     displayText = json['displayText'];
//     type = json['type'];
//     label = json['label'];
//     codeGroup = 
//     dependent = json['dependent'];
//   }

//   Map<String, dynamic> toJson() {
//     final Map<String, dynamic> data = new Map<String, dynamic>();
//     data['filterable'] = this.filterable;
//     data['mandatory'] = this.mandatory;
//     data['_id'] = this.sId;
//     data['name'] = this.name;
//     data['displayText'] = this.displayText;
//     data['type'] = this.type;
//     data['label'] = this.label;
//     if (this.codeGroup != null) {
//       data['codeGroup'] = this.codeGroup.toJson();
//     }
//     data['dependent'] = this.dependent;
//     return data;
//   }
// }

// class CodeGroup {
//   late String sId;
//   late String name;
//   late List<Null> codeValues;

//   CodeGroup({required this.sId, required this.name, required this.codeValues});

//   CodeGroup.fromJson(Map<String, dynamic> json) {
//     sId = json['_id'];
//     name = json['name'];
//     if (json['codeValues'] != null) {
//       codeValues = <Null>[];
//       json['codeValues'].forEach((v) {});
//     }
//   }

//   Map<String, dynamic> toJson() {
//     final Map<String, dynamic> data = new Map<String, dynamic>();
//     data['_id'] = this.sId;
//     data['name'] = this.name;
//     if (this.codeValues != null) {
//       data['codeValues'] = [];
//     }
//     return data;
//   }
// }
