import 'dart:io';
import 'package:firebase_messaging/firebase_messaging.dart';
import 'package:flutter/material.dart';
import 'package:flutter_svg/svg.dart';
import 'package:india/Common/color.dart';
import 'package:india/Common/loading_bool.dart';
import 'package:india/Common/loading_widget.dart';
import 'package:india/Common/show_toast.dart';
import 'package:india/Model/location.dart';
import 'package:india/Model/shared_pref.dart';
import 'package:india/Services/chat_firestore.dart';
import 'package:india/Services/fcm_token.dart';
import 'package:india/Services/get_home.dart';
import 'package:india/Services/get_products.dart';
import 'package:india/Services/my_postapi.dart';
import 'package:india/Services/sell_form.dart';
import 'package:india/Services/user_data.dart';
import 'package:india/Widgets/Screens/bottom_navbar.dart';
import 'package:india/Widgets/Screens/filterby_location.dart';
import 'package:india/Widgets/Screens/specific_product.dart';
import 'package:provider/provider.dart';
import 'package:shared_preferences/shared_preferences.dart';

// ignore: must_be_immutable
class NetworkError extends StatelessWidget {
  String? authToken;
  String? fcmtoken;
  Future<String> getAuthToken() async {
    SharedPreferences sharedPreferences = await SharedPreferences.getInstance();
    authToken = sharedPreferences.getString("authtoken");
    fcmtoken = sharedPreferences.getString("fcmtoken");
    // print('Auth token: $authToken');
    return authToken ?? '';
  }

  @override
  Widget build(BuildContext context) {
    Size size = MediaQuery.of(context).size;
    bool _loading = Provider.of<BoolLoader>(context).loadingStatus;
    String latitude = Provider.of<StoreLocation>(context).latitude.toString();
    String longitude = Provider.of<StoreLocation>(context).longitude.toString();
    return Scaffold(
      backgroundColor: Colors.white,
      body: _loading
          ? LoadingWidget()
          : Column(
              children: [
                SizedBox(
                  height: size.height * 0.3,
                ),
                Center(
                  child: Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 15),
                    child: SvgPicture.asset(
                      "assets/placeholders/networkerror.svg",
                      height: 250,
                    ),
                  ),
                ),
                SizedBox(height: 20),
                Container(
                  decoration: BoxDecoration(
                      color: colorBlue, borderRadius: BorderRadius.circular(5)),
                  child: TextButton(
                    onPressed: () async {
                      try {
                        final result =
                            await InternetAddress.lookup("bartoindia.com");
                        if (result.isNotEmpty &&
                            result[0].rawAddress.isNotEmpty) {
                          // All connections for the app initialised here.
                          Provider.of<BoolLoader>(context, listen: false)
                              .boolLoader(status: true);
                          FcmToken.getToken();
                          // ! change below line from main
                          // LocalNotificationService.initialize(context: context);
                          FirebaseMessaging.instance.getInitialMessage();
                          // FirebaseMessaging.instance.subscribeToTopic("events"); // ! Place this to follow people
                          FirebaseMessaging.onMessage.listen((message) {
                            var firebaseNotification = message.notification;
                            if (firebaseNotification != null) {
                              // ! change below line from main
                              // LocalNotificationService.display(message);
                            }
                            print("Notification data3: ${message.data}");
                          });
                          FirebaseMessaging.onMessageOpenedApp
                              .listen((message) {
                            print("Notification data4: ${message.data}");
                            var productId = message.data['productId'];
                            var route = message.data['click_action'];
                            if (route == "product_uploaded") {
                              Provider.of<BoolLoader>(context, listen: false)
                                  .boolLoader(status: false);
                              Provider.of<ProductInformation>(context,
                                      listen: false)
                                  .getproductInformation(
                                authtoken: authToken,
                                productid: productId,
                              )
                                  .then((value) {
                                if (value["status"] == 200) {
                                  Navigator.push(
                                    context,
                                    MaterialPageRoute(
                                      builder: (_) => SpecificProduct(),
                                    ),
                                  );
                                }
                                Provider.of<BoolLoader>(context, listen: false)
                                    .boolLoader(status: false);
                              });
                            }
                          });
                          Provider.of<SellForm>(context, listen: false)
                              .getCategory();
                          Provider.of<GetHome>(context, listen: false)
                              .getCategories();
                          if (GetStoredInfo.latitude.isEmpty) {
                            Navigator.pushAndRemoveUntil(
                              context,
                              MaterialPageRoute(
                                builder: (_) => FilterProductLocation(
                                  savedlat: GetStoredInfo.latitude,
                                  savedlong: GetStoredInfo.longitude,
                                  page: 1,
                                ),
                              ),
                              (route) => false,
                            );
                            Provider.of<BoolLoader>(context, listen: false)
                                .boolLoader(status: false);
                          } else {
                            getAuthToken().then(
                              (value) {
                                if (value.isNotEmpty) {
                                  filterbasedonLocationTokenNotEmpty(
                                    lat: latitude == "0.0"
                                        ? GetStoredInfo.latitude
                                        : latitude,
                                    long: longitude == "0.0"
                                        ? GetStoredInfo.longitude
                                        : longitude,
                                    context: context,
                                  );
                                  Provider.of<MyPostApi>(context, listen: false)
                                      .nonpaid(authtoken: authToken ?? '');
                                  Provider.of<MyPostApi>(context, listen: false)
                                      .paid(authtoken: authToken ?? '');
                                  Provider.of<UserData>(context, listen: false)
                                      .getUserData(authtoken: authToken ?? '')
                                      .then((value) {
                                    if (value["status"] == 200) {
                                      Provider.of<ChatFirestore>(context,
                                              listen: false)
                                          .getChatList(
                                        userId: value["response"]["data"]
                                            ["info"]["profile"]["userId"],
                                      );
                                      Future.delayed(
                                        Duration(seconds: 2),
                                        () {
                                          Navigator.pushAndRemoveUntil(
                                            context,
                                            MaterialPageRoute(
                                              builder: (_) =>
                                                  CustomBottomNavBar(
                                                chooseIndex: 0,
                                              ),
                                            ),
                                            (route) => false,
                                          );
                                          Provider.of<BoolLoader>(context,
                                                  listen: false)
                                              .boolLoader(status: false);
                                        },
                                      );
                                    }
                                  });
                                } else {
                                  filterbasedonLocationTokenEmpty(
                                    lat: latitude == "0.0"
                                        ? GetStoredInfo.latitude
                                        : latitude,
                                    long: longitude == "0.0"
                                        ? GetStoredInfo.longitude
                                        : longitude,
                                    context: context,
                                  );
                                }
                              },
                            );
                          }
                        }
                      } on SocketException catch (_) {
                        Provider.of<BoolLoader>(context, listen: false)
                            .boolLoader(status: false);
                      }
                    },
                    child: Text(
                      "Try again",
                      style: TextStyle(
                        fontSize: 20,
                        color: Colors.white,
                      ),
                    ),
                  ),
                ),
              ],
            ),
    );
  }

  filterbasedonLocationTokenNotEmpty({
    required String lat,
    required String long,
    required BuildContext context,
  }) {
    Provider.of<GetHome>(context, listen: false).getProducts(
      authtoken: authToken ?? '',
      lat: lat,
      long: long,
      refresh: true,
    );
  }

  filterbasedonLocationTokenEmpty({
    required String lat,
    required String long,
    required BuildContext context,
  }) {
    Provider.of<GetHome>(context, listen: false)
        .getProducts(
      authtoken: authToken ?? '',
      lat: lat,
      long: long,
      refresh: true,
    )
        .then(
      (value) {
        if (value["status"] == 200 &&
            value["response"]["data"]["info"]["products"].isNotEmpty) {
          Navigator.pushAndRemoveUntil(
            context,
            MaterialPageRoute(
              builder: (_) => CustomBottomNavBar(
                chooseIndex: 0,
              ),
            ),
            (route) => false,
          );
        } else if (value["status"] == 200 &&
            value["response"]["data"]["info"]["products"].isEmpty) {
          Navigator.pushAndRemoveUntil(
            context,
            MaterialPageRoute(
              builder: (_) => CustomBottomNavBar(
                chooseIndex: 0,
              ),
            ),
            (route) => false,
          );
          ShowToast.showToast(context,
              exception: "Currently no products available in this area");
        }
      },
    );
  }
}
