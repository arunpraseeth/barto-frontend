import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'package:firebase_core/firebase_core.dart';
import 'package:firebase_messaging/firebase_messaging.dart';
import 'package:flutter/material.dart';
import 'package:flutter_dotenv/flutter_dotenv.dart';
import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:geolocator/geolocator.dart';
import 'package:india/Common/color.dart';
import 'package:india/Common/loading_bool.dart';
import 'package:india/Model/location.dart';
import 'package:india/Model/shared_pref.dart';
import 'package:india/Services/chat_firestore.dart';
import 'package:india/Services/chat_module.dart';
import 'package:india/Services/donate.dart';
import 'package:india/Services/fcm_token.dart';
import 'package:india/Services/filter.dart';
import 'package:india/Services/get_home.dart';
import 'package:india/Services/get_products.dart';
import 'package:india/Services/my_postapi.dart';
import 'package:india/Services/notification.dart';
import 'package:india/Services/search_places.dart';
import 'package:india/Services/search_product.dart';
import 'package:india/Services/sell_form.dart';
import 'package:india/Services/seller_details.dart';
import 'package:india/Services/user_data.dart';
import 'package:india/Services/wishlist.dart';
import 'package:india/Widgets/Screens/Profile/feedback.dart';
import 'package:india/Widgets/Screens/bottom_navbar.dart';
import 'package:india/Widgets/Screens/filterby_location.dart';
import 'package:india/Widgets/Screens/specific_product.dart';
import 'package:india/home_page/network_error.dart';
import 'package:provider/provider.dart';
import 'package:shared_preferences/shared_preferences.dart';

// Future<void> _messageHandler(RemoteMessage message) async {
//   print("Notification data: ${message.data}");
//   String productId = message.data['productId'];
//   String route = message.data['click_action'];
//   // if (route == "product_uploaded") {
//   //   Provider.of<ProductInformation>(_scaffoldKey.currentContext ?? context,
//   //           listen: false)
//   //       .getproductInformation(
//   //     authtoken: authToken,
//   //     productid: productId,
//   //   );
//   // }
//     if (route == "product_uploaded") {
//       Provider.of<BoolLoader>(this.context, listen: false).boolLoader(status: false);
//       Provider.of<ProductInformation>(this.context, listen: false)
//           .getproductInformation(
//         authtoken: authToken,
//         productid: productId,
//       )
//           .then((value) {
//         if (value["status"] == 200) {
//           Navigator.push(
//             this.context,
//             MaterialPageRoute(
//               builder: (_) => SpecificProduct(),
//             ),
//           );
//         }
//         Provider.of<BoolLoader>(this.context, listen: false).boolLoader(status: false);
//       });
//     }
// }

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp();
  // ? When App is closed or terminated, this works
  // FirebaseMessaging.onBackgroundMessage(_messageHandler);
  await dotenv.load(fileName: ".env");
  runApp(MyApp());
}

MaterialColor createMaterialColor(Color color) {
  List strengths = <double>[.05];
  final swatch = <int, Color>{};
  final int r = color.red, g = color.green, b = color.blue;

  for (int i = 1; i < 10; i++) {
    strengths.add(0.1 * i);
  }
  strengths.forEach((strength) {
    final double ds = 0.5 - strength;
    swatch[(strength * 1000).round()] = Color.fromRGBO(
      r + ((ds < 0 ? r : (255 - r)) * ds).round(),
      g + ((ds < 0 ? g : (255 - g)) * ds).round(),
      b + ((ds < 0 ? b : (255 - b)) * ds).round(),
      1,
    );
  });
  return MaterialColor(color.value, swatch);
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MultiProvider(
      providers: [
        ChangeNotifierProvider(create: (context) => ChatFirestore()),
        ChangeNotifierProvider(create: (context) => ChatModule()),
        ChangeNotifierProvider(create: (context) => UserData()),
        ChangeNotifierProvider(create: (context) => SellForm()),
        ChangeNotifierProvider(create: (context) => GetHome()),
        ChangeNotifierProvider(create: (context) => Wishlist()),
        ChangeNotifierProvider(create: (context) => FilterProducts()),
        ChangeNotifierProvider(create: (context) => ProductInformation()),
        ChangeNotifierProvider(create: (context) => MyPostApi()),
        ChangeNotifierProvider(create: (context) => SellerDetails()),
        ChangeNotifierProvider(create: (context) => SearchProduct()),
        ChangeNotifierProvider(create: (context) => BoolLoader()),
        ChangeNotifierProvider(create: (context) => StoreLocation()),
        ChangeNotifierProvider(create: (context) => SearchPlaces()),
        ChangeNotifierProvider(create: (context) => FeedbackProvider()),
        ChangeNotifierProvider(create: (context) => Donate()),
        ChangeNotifierProvider(create: (context) => NotificationApi()),
      ],
      child: MaterialApp(
        debugShowCheckedModeBanner: false,
        title: 'Barto',
        theme: ThemeData(
          primarySwatch: createMaterialColor(Color(0xFF30BFFD)),
        ),
        home: MyHomePage(),
      ),
    );
  }
}

class MyHomePage extends StatefulWidget {
  @override
  _MyHomePageState createState() => _MyHomePageState();
}

class _MyHomePageState extends State<MyHomePage> {
  String? fcmtoken;
  String? authToken;
  late String areaId;
  String? areaname;
  late SharedPreferences sharedPreferences;
  static final FlutterLocalNotificationsPlugin _notificationsPlugin =
      FlutterLocalNotificationsPlugin();

  Future<String> getAuthToken() async {
    sharedPreferences = await SharedPreferences.getInstance();
    authToken = sharedPreferences.getString("authtoken");
    fcmtoken = sharedPreferences.getString("fcmtoken");
    // print('Auth token: $authToken');
    return authToken ?? '';
  }

  @override
  void initState() {
    GetStoredInfo.getStoreInfo();
    getLocationPermission(context: context);
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Center(
        child: SvgPicture.asset(
          'assets/logo/logo.svg',
          height: 200,
        ),
      ),
    );
  }

  filterbasedonLocationTokenNotEmpty({
    required String lat,
    required String long,
  }) {
    Provider.of<GetHome>(this.context, listen: false).getProducts(
      authtoken: authToken ?? '',
      lat: lat,
      long: long,
      refresh: true,
    );
  }

  filterbasedonLocationTokenEmpty({
    required String lat,
    required String long,
  }) {
    Provider.of<GetHome>(this.context, listen: false)
        .getProducts(
      authtoken: authToken ?? '',
      lat: lat,
      long: long,
      refresh: true,
    )
        .then(
      (value) {
        if (value["status"] == 200) {
          Navigator.pushAndRemoveUntil(
            context,
            MaterialPageRoute(
              builder: (_) => CustomBottomNavBar(
                chooseIndex: 0,
              ),
            ),
            (route) => false,
          );
        } else {
          Navigator.pushAndRemoveUntil(
            context,
            MaterialPageRoute(
              builder: (_) => NetworkError(),
            ),
            (route) => false,
          );
        }
      },
    );
  }

  Future getLocationPermission({required BuildContext context}) async {
    bool serviceEnabled = await Geolocator.isLocationServiceEnabled();
    LocationPermission permission;
    // print('Geolocation service: $serviceEnabled');
    if (!serviceEnabled) {
      // showAlertDialog(context);
      checkInternet();
      // return Future.error('Location services are disabled.');
    } else {
      permission = await Geolocator.checkPermission();
      // print('Permission1: $permission');
      if (permission == LocationPermission.denied ||
          permission == LocationPermission.deniedForever) {
        // print('Permission denied initially');
        permission = await Geolocator.requestPermission();
        if (permission == LocationPermission.denied ||
            permission == LocationPermission.deniedForever) {
          // print('Permission denied secondary');
          checkInternet();
        } else {
          checkInternet();
        }
      } else if (permission == LocationPermission.whileInUse ||
          permission == LocationPermission.always) {
        // print('Permission granted initially');
        checkInternet();
      } else {
        return Future.error(
          'Location permissions are permanently denied, we cannot request permissions.',
        );
      }
    }
  }

  Future showAlertDialog(BuildContext context) async {
    // set up the AlertDialog
    AlertDialog alert = AlertDialog(
      content: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Text("Kindly turn on your location services"),
          Padding(
            padding: EdgeInsets.symmetric(horizontal: 5, vertical: 5),
            child: Divider(),
          ),
          TextButton(
            onPressed: () {
              Geolocator.openLocationSettings();
            },
            child: Text(
              "Open app settings",
              style: TextStyle(
                fontSize: 16,
                fontWeight: FontWeight.w600,
                color: colorBlue,
              ),
            ),
          ),
        ],
      ),
    );
    // show the dialog
    await showDialog(
      context: context,
      builder: (BuildContext context) {
        return alert;
      },
    );
  }

  checkInternet() async {
    Provider.of<BoolLoader>(context, listen: false).boolLoader(status: false);
    try {
      final result = await InternetAddress.lookup("bartoindia.com");
      if (result.isNotEmpty && result[0].rawAddress.isNotEmpty) {
        // All connections for the app initialised here.
        FcmToken.getToken();
        initializeLocalNotification();
        FirebaseMessaging.instance.getInitialMessage();
        // FirebaseMessaging.instance.subscribeToTopic("events"); // ! Place this to follow people
        // ? Works when app is in foreground or opened
        FirebaseMessaging.onMessage.listen((message) {
          displayLocalNotification(message);
        });
        // ? When App is opened, this works
        FirebaseMessaging.onMessageOpenedApp.listen(_handleMessage);
        Provider.of<SellForm>(context, listen: false).getCategory();
        Provider.of<GetHome>(context, listen: false).getCategories();
        GetStoredInfo.latitude.isEmpty
            ? Navigator.pushAndRemoveUntil(
                context,
                MaterialPageRoute(
                  builder: (_) => FilterProductLocation(
                    savedlat: GetStoredInfo.latitude,
                    savedlong: GetStoredInfo.longitude,
                    page: 1,
                  ),
                ),
                (route) => false,
              )
            : getAuthToken().then(
                (value) {
                  if (value.isNotEmpty) {
                    filterbasedonLocationTokenNotEmpty(
                      lat: GetStoredInfo.latitude,
                      long: GetStoredInfo.longitude,
                    );
                    Provider.of<MyPostApi>(context, listen: false)
                        .nonpaid(authtoken: authToken ?? '');
                    Provider.of<MyPostApi>(context, listen: false)
                        .paid(authtoken: authToken ?? '');
                    Provider.of<UserData>(context, listen: false)
                        .getUserData(authtoken: authToken ?? '')
                        .then((value) {
                      if (value["status"] == 200) {
                        Map<String, dynamic> _response = value["response"];
                        Map<String, dynamic> _data = _response["data"];
                        Map<String, dynamic> _info = _data["info"];
                        Map<String, dynamic> _profile = _info["profile"];
                        String _userId = _profile["userId"];
                        Provider.of<ChatFirestore>(context, listen: false)
                            .getChatList(
                          userId: _userId,
                        );
                        Future.delayed(Duration(seconds: 2), () {
                          Navigator.push(
                            this.context,
                            MaterialPageRoute(
                              builder: (_) =>
                                  CustomBottomNavBar(chooseIndex: 0),
                            ),
                          );
                        });
                      }
                    });
                  } else {
                    filterbasedonLocationTokenEmpty(
                      lat: GetStoredInfo.latitude,
                      long: GetStoredInfo.longitude,
                    );
                  }
                },
              );
      }
    } on SocketException catch (_) {
      Provider.of<BoolLoader>(context, listen: false).boolLoader(status: false);
      Navigator.pushAndRemoveUntil(
        context,
        MaterialPageRoute(
          builder: (_) => NetworkError(),
        ),
        (route) => false,
      );
    }
  }

  void initializeLocalNotification() async {
    final IOSInitializationSettings initializationSettingsIOS =
        IOSInitializationSettings(
      requestSoundPermission: true,
      requestBadgePermission: false,
      requestAlertPermission: true,
    );

    final InitializationSettings initializationSettings =
        InitializationSettings(
      android: AndroidInitializationSettings("@mipmap/ic_barto"),
      iOS: initializationSettingsIOS,
    );
    await _notificationsPlugin.initialize(initializationSettings,
        onSelectNotification: (String? payload) async {
      if (payload != null) {
        Map<String, dynamic> payLoad = json.decode(payload);
        if (payLoad["click_action"] == "product_uploaded") {
          Provider.of<BoolLoader>(this.context, listen: false)
              .boolLoader(status: false);
          Provider.of<ProductInformation>(this.context, listen: false)
              .getproductInformation(
            authtoken: authToken,
            productid: payLoad['productId'],
          )
              .then((value) {
            if (value["status"] == 200) {
              Navigator.push(
                this.context,
                MaterialPageRoute(
                  builder: (_) => SpecificProduct(),
                ),
              );
            }
            Provider.of<BoolLoader>(this.context, listen: false)
                .boolLoader(status: false);
          });
        }
      } else {
        Navigator.push(
          this.context,
          MaterialPageRoute(
            builder: (_) => CustomBottomNavBar(chooseIndex: 0),
          ),
        );
      }
    });
  }

  void displayLocalNotification(var message) async {
    try {
      final NotificationDetails notificationDetails = NotificationDetails(
        android: AndroidNotificationDetails(
          "Barto", //id
          "Barto channel",
          channelDescription: "Barto India",
          importance: Importance.max,
          priority: Priority.high,
          playSound: true,
        ),
        iOS: IOSNotificationDetails(
          presentAlert:
              true, // Present an alert when the notification is displayed and the application is in the foreground (only from iOS 10 onwards)
          presentBadge:
              false, // Present the badge number when the notification is displayed and the application is in the foreground (only from iOS 10 onwards)
          presentSound:
              true, // Play a sound when the notification is displayed and the application is in the foreground (only from iOS 10 onwards)
          //sound: String?,  // Specifics the file path to play (only from iOS 10 onwards)
          //badgeNumber: int?, // The application's icon badge number
          //attachments: List<IOSNotificationAttachment>?, (only from iOS 10 onwards)
          subtitle:
              "Barto Notification", //Secondary description  (only from iOS 10 onwards)
          // threadIdentifier: String?,
        ),
      );

      if (message.notification != null) {
        String messageData = json.encode(message.data);
        await _notificationsPlugin.show(
          message.hashCode,
          message.notification.title,
          message.notification.body,
          notificationDetails,
          payload: messageData,
        );
      }
    } on Exception catch (e) {
      print("Local Notification exception: $e");
    }
  }

  void _handleMessage(RemoteMessage message) {
    String productId = message.data['productId'];
    String route = message.data['click_action'];
    if (route == "product_uploaded") {
      Provider.of<BoolLoader>(this.context, listen: false)
          .boolLoader(status: false);
      Provider.of<ProductInformation>(this.context, listen: false)
          .getproductInformation(
        authtoken: authToken,
        productid: productId,
      )
          .then((value) {
        if (value["status"] == 200) {
          Navigator.push(
            this.context,
            MaterialPageRoute(
              builder: (_) => SpecificProduct(),
            ),
          );
        }
        Provider.of<BoolLoader>(this.context, listen: false)
            .boolLoader(status: false);
      });
    }
  }
}
